package entities;

import java.io.IOException;

import client.ClientMissionHandler;
import guiClientControllers.ClientLoginScreenController;
import guiClientControllers.MainCustomerPageController;
import guiClientControllers.OutOfTimeController;
import javafx.application.Platform;
import javafx.stage.Stage;

/**
 * TimeMeasurementThread class is used to measure the time passed since the user
 * logged in.
 *
 * This class provides a thread that runs in the background and measures the
 * time passed since the user logged in. If the time passed exceeds a certain
 * limit, the thread closes the user's current window and redirects them to the
 * login screen.
 * 
 * @author Maayan
 */
public class TimeMeasurementThread extends Thread {

	/**
	 * A volatile boolean variable that can be accessed by multiple threads and used
	 * to stop the execution of the thread.
	 */
	public static volatile boolean stop = false;

	/**
	 * A getter method that returns the current value of the stop variable.
	 * 
	 * @return current value of stop variable
	 */
	public boolean isStop() {
		return stop;
	}

	/**
	 * A variable that stores the stage of the pop up screen.
	 */
	private Stage popUpStage;

	/**
	 * A final variable that stores the time limit in seconds.
	 */
	private final int SECOND = 120;

	/**
	 * A static variable that stores a reference to the current stage.
	 */
	private static Stage stage;

	/**
	 * A static variable that stores the start time of the thread in milliseconds.
	 */
	public static long startTime = System.currentTimeMillis();

	/**
	 * Constructor that takes in a stage and sets it to the static stage variable.
	 * 
	 * @param stage reference to the current stage
	 */
	public TimeMeasurementThread(Stage stage) {
		super();
		TimeMeasurementThread.stage = stage;
	}

	/**
	 * A getter method that returns the current stage.
	 * 
	 * @return current stage
	 */
	public static Stage getStage() {
		return stage;
	}

	/**
	 * A setter method that sets the current stage.
	 * 
	 * @param stage reference to the new stage
	 */
	public static void setStage(Stage stage) {
		TimeMeasurementThread.stage = stage;
	}

	/**
	 * A getter method that returns the start time of the thread in milliseconds.
	 * 
	 * @return start time of the thread
	 */
	public static long getStartTime() {
		return startTime;
	}

	/**
	 * A setter method that sets the start time of the thread in milliseconds.
	 * 
	 * @param startTime new start time of the thread
	 */
	public static void setStartTime(long startTime) {
		TimeMeasurementThread.startTime = startTime;
	}

	/**
	 * A method that runs the thread. It calculates the elapsed time and compares it
	 * to the predefined time limit. If the elapsed time exceeds the limit, the
	 * thread stops execution and the current stage is closed. If the stop variable
	 * is set to true, the thread also stops execution.
	 */
	@Override
	public void run() {
		startTime = System.currentTimeMillis();
		boolean flag = true;
		while (true && !stop) {

			long elapsedTime = System.currentTimeMillis() - startTime;
			System.out.println(elapsedTime);
			if (elapsedTime >= 1000 * SECOND - 1000 * (SECOND - 60)) {
				if (flag) {
					flag = false;
					Platform.runLater(() -> {
						final Stage primaryStage = new Stage();
						popUpStage = primaryStage;
						OutOfTimeController subController = new OutOfTimeController();
						try {
							subController.start(primaryStage);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} // connection successful->goto the next window
					});
				}
			}

			if (elapsedTime > 1000 * SECOND) { // 10 minutes in milliseconds

				ClientMissionHandler.closeWindowForTimer(MainCustomerPageController.getUsername());
				stop = true;
				Platform.runLater(() -> {
					popUpStage.hide();
					stage.hide();
					final Stage primaryStage = new Stage();
					ClientLoginScreenController subController = new ClientLoginScreenController();
					System.out.println("I am start time: " + startTime);
					try {
						subController.start(primaryStage);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} // connection successful->goto the next window
				});
			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		}

	}

	/**
	 * A setter method that sets the stop variable to a new value.
	 * 
	 * @param stop2
	 */
	public void setStop(boolean stop2) {
		TimeMeasurementThread.stop = stop2;
	}

}
