package guiClientControllers;

import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.io.IOException;

import client.ClientMissionHandler;
import entities.TimeMeasurementThread;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;

/**
* The ContactUsController class is responsible for handling the functionality of the contact us screen.
* The user can return to the main customer page by clicking the back button.
* 
* @author Dina
*/
public class ContactUsController implements EventHandler<WindowEvent> {

	/** The back button */
	@FXML
	private Button backBtn;

	/**
     * Displays the contact us screen and sets the title and icon.
     * 
     * @param primaryStage The stage on which the contact us screen will be displayed
     * @throws IOException If there is an error loading the FXML file
     */
	public void start(Stage primaryStage) throws IOException {
		// System.out.println("start");
		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/ContactUsWindow.fxml"));
		primaryStage.getIcons()
				.add(new Image(ContactUsController.class.getResourceAsStream("/pictures/ekrutIcon.png")));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Contact us");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);
		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.closeWindow(MainCustomerPageController.getUsername());
		});
		TimeMeasurementThread.stop=true;
	}

	/**
     * Handles the event when the back button is clicked by hiding the current window and displaying the main customer page.
     * 
     * @param event The ActionEvent that triggers this method
     * @throws IOException If there is an error loading the main customer page
     */
	@FXML
	void Back(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		MainCustomerPageController subController = new MainCustomerPageController();
		subController.start(primaryStage);
	}

	/**
     * Handles the event when the window is closed.
     * 
     * @param event The WindowEvent that triggers this method
     */
	@Override
	public void handle(WindowEvent event) {
		// TODO Auto-generated method stub

	}

}
