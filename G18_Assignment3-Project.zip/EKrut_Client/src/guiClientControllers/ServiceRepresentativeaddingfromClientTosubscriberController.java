package guiClientControllers;

import java.io.IOException;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import client.ClientMissionHandler;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * ServiceRepresentativeaddingfromClientTosubscriberController is a JavaFX controller class that 
 * handles the events and logic when a service representative wants to change a client to a subscriber.
 * 
 * @author Maayan
 */
public class ServiceRepresentativeaddingfromClientTosubscriberController implements EventHandler<WindowEvent> {

	@FXML
	private TextField usernameofcustomer;
	@FXML
	private Label statusLabel2;
	 @FXML
	private ImageView VIPimg;

	@FXML
	private Button changeToSubscriber;

	@FXML
	private Button back;
	@FXML
	private TextArea userLog;
	private static String firstName;
	private static String phone;

	/**
	* This method starts the service representative adding from client to subscriber screen by loading the fxml file and
	* setting the scene, title, and icon of the primary stage.
	* 
	* @param primaryStage The main stage where the scene is to be set.
	* @throws IOException if there is an error loading the fxml file.
	*/
	public void start(Stage primaryStage) throws IOException {
		Parent root = FXMLLoader.load(
				getClass().getResource("/guiClientScreens/ServiceRepresentativeaddingfromClientTosubscriberscreen.fxml"));
		primaryStage.getIcons().add(new Image(ServiceRepresentativeaddingfromClientTosubscriberController.class
				.getResourceAsStream("/pictures/ekrutIcon.png")));
		Scene scene = new Scene(root);
		primaryStage.setTitle("E-Krut Service Representative change customer to subscriber page");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);
		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.closeWindow(ServiceRepresentativeScreenController.getUsername());
		});
	}

	/**
	* The initialize method is called by the JavaFX framework when the associated FXML file is loaded.
	* It is used to set up the initial state of the user interface elements.
	* 
	* 
	*/
	@FXML
	public void initialize() {
		VIPimg.setVisible(false);
		userLog.setText("Phone number: " + phone + "\n" + "Account type: " + "service representative");

	}

	@FXML
	void Backtofirst(ActionEvent event) throws Exception {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		ServiceRepresentativeScreenController openScreen1 = new ServiceRepresentativeScreenController();
		openScreen1.start(primaryStage);
	}

	/**
	* The Backtofirst method is an event handler that is called when the associated button is clicked.
	* It is used to transition to the first screen.
	*
	* @param event The ActionEvent that triggered this method call.
	* @throws Exception if an error occurs while transitioning to the first screen.
	* @FXML
	*/
	@FXML
	void changeToSubscriber(ActionEvent event) throws IOException {
		ClientMissionHandler.fromCustomerToSubscriber(this.usernameofcustomer, this.statusLabel2,this.VIPimg);
	}

	/**
	* The handle method is an event handler that is called when the associated window is closed.
	* It is used to handle the closing event.
	*
	* @param arg0 The WindowEvent that triggered this method call.
	* 
	*/
	@Override
	public void handle(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	/**
	* The getFirstName method is used to get the first name of the subscriber.
	*
	* @return The first name of the subscriber
	*/
	public static String getFirstName() {
		return firstName;
	}

	/**
	* The getPhone method is used to get the phone number of the subscriber.
	*
	* @return The phone number of the subscriber
	*/
	public static String getPhone() {
		return phone;
	}

	/**
	* The getPhone method is used to get the phone number of the subscriber.
	*
	*/
	public static void setPhone(String phone) {
		ServiceRepresentativeaddingfromClientTosubscriberController.phone = phone;
	}

	/**
	* The setFirstName method is used to set the first name of the subscriber.
	*
	* @param firstName2 The first name of the subscriber
	*/
	public static void setFirstName(String firstName2) {
		ServiceRepresentativeaddingfromClientTosubscriberController.firstName = firstName2;

	}

}
