package guiClientControllers;

import java.io.IOException;

import client.ClientMissionHandler;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * UserScreenController class is used for controlling the UserScreen window.
 * @author Maayan
 */
public class UserScreenController implements EventHandler<WindowEvent> {
	/**
	 * The username of the current user.
	 */
	private static String username;
	/**
	 * Text area for displaying the user log.
	 */
	@FXML
	private TextArea userLog;

	/**
	 * Label for displaying a greeting message.
	 */
	@FXML
	private Label hello;

	/**
	 * Log out button.
	 */
	@FXML
	private Button logOut;

	/**
     * Method handle the event of clicking on the logOut button.
     * It hides the current window, opens the login screen, and sends a logout request to the server.
     * @param event  ActionEvent of clicking on the logOut button
     * @throws IOException
     */
	@FXML
	void logOut(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		ClientLoginScreenController subController = new ClientLoginScreenController();
		subController.start(primaryStage);
		ClientMissionHandler.logOut(username);
	}


	/**
    * Get the username of the current user.
    * @return username of the current user
    */
	public static String getUsername() {
		return username;
	}

	/**
    * The start method is used for displaying the UserScreen window.
    * It loads the FXML file, sets the title, icon, and scene of the primary stage,
    * sets the stage to be not resizable, and adds an event handler for the close request.
    * @param primaryStage the primary stage of the window
    * @throws IOException
    */
	public void start(Stage primaryStage) throws IOException {

		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/UserScreen.fxml"));
		primaryStage.getIcons()
				.add(new Image(UserScreenController.class.getResourceAsStream("/pictures/ekrutIcon.png")));

		Scene scene = new Scene(root);

		primaryStage.setTitle("E-Krut Service user page");

		primaryStage.setScene(scene);

		primaryStage.show();
		primaryStage.setResizable(false);
		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.closeWindow(UserScreenController.getUsername());
		});
	}

	/**
    * Set the username of the current user.
    * @param username the username to be set
    */
	public static void setUsername(String username) {
		UserScreenController.username = username;
	}

	/**
    * Handle method for window close request event.
    * It is currently empty, but can be used for adding functionality when the window is closed.
    * @param arg0 WindowEvent of the close request
    */
	@Override
	public void handle(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

}