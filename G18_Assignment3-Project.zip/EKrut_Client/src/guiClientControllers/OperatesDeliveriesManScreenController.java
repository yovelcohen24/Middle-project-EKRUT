package guiClientControllers;

import java.io.IOException;

import client.ClientMissionHandler;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * OperatesDeliveriesManScreenController class is the controller class for the deliveries manager screen,
 * it provides the functionality and events handling of the screen.
 *
 * @author Maayan
 */
public class OperatesDeliveriesManScreenController implements EventHandler<WindowEvent> {

	@FXML
	private TextArea userLog;

	@FXML
	private Button ChangingStatus;
	@FXML
	private Button ApproveDelivery;

    /**
    * variable to store the username of the deliveries manager.
    */
	private static String username;
    /**
    * variable to store the first name of the deliveries manager.
    */
	private static String firstName;
    /**
    * variable to store the region the deliveries manager is responsible for.
    */
	private static String region;
	  /**
	    * variable to store the phone number of the deliveries manager.
	    */
	private static String phone;
	   /**
	    * variable to store the facility the deliveries manager is working in.
	    */
	private static String facility;
	@FXML
    private ImageView OLpic;

    @FXML
    private ImageView EKpic;

    @FXML
    private Label configLbl;

	@FXML
	private Button logOut;

	@FXML
	public Label hello;

	/**
	* start method is used to initialize and display the deliveries manager screen.
	*
	* @param primaryStage the stage on which the screen is displayed.
	* @throws IOException if the FXML file for the screen cannot be loaded.
	*/
	public void start(Stage primaryStage) throws IOException {

		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/OperatesDeliveriesManScreen.fxml"));
		primaryStage.getIcons().add(
				new Image(OperatesDeliveriesManScreenController.class.getResourceAsStream("/pictures/ekrutIcon.png")));

		Scene scene = new Scene(root);
		primaryStage.setTitle("E-Krut Operates Deliverie page");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);
		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.closeWindow(OperatesDeliveriesManScreenController.getUsername());
		});
	}

	/**
	* ApproveDelivery method is used to handle the event of clicking on the 'Approve Delivery' button.
	* It hides the current window and opens the deliveries manager approve screen.
	*
	* @param event the event of clicking on the 'Approve Delivery' button
	* @throws IOException if the FXML file for the approve screen cannot be loaded.
	*/
	@FXML
	void ApproveDelivery(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		OperatesDeliveriesManApproveScreenController Approve = new OperatesDeliveriesManApproveScreenController();
		Approve.start(primaryStage);
	}

	/**
	* ChangingStatus method is used to handle the event of clicking on the 'Change Status' button.
	* It hides the current window and opens the deliveries manager change status screen.
	*
	* @param event the event of clicking on the 'Change Status' button
	* @throws IOException if the FXML file for the change status screen cannot be loaded.
	*/
	@FXML
	void ChangingStatus(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		OperatesDeliveriesManChangeStatusScreenController Change = new OperatesDeliveriesManChangeStatusScreenController();
		Change.start(primaryStage);
	}

	/**
	* logOut method is used to handle the event of clicking on the 'Log Out' button.
	* It hides the current window, opens the login screen and logs out the current user.
	*
	* @param event the event of clicking on the 'Log Out' button
	* @throws IOException if the FXML file for the login screen cannot be loaded.
	*/
	@FXML
	void logOut(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		ClientLoginScreenController subController = new ClientLoginScreenController();
		subController.start(primaryStage);
		ClientMissionHandler.logOut(username);
	}

	/**
	* getUsername method is used to get the current user's username.
	*
	* @return the current user's username
	*/
	public static String getUsername() {
		return username;
	}

	/**
	* setUsername method is used to set the current user's username.
	*
	* @param username the current user's username
	*/
	public static void setUsername(String username) {
		OperatesDeliveriesManScreenController.username = username;
	}

	/**
	* handle method is used to handle the window event of closing the window.
	*
	* @param arg0 the window event of closing the window.
	*/
	@Override
	public void handle(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	/**
	* This method is used to initialize the Operates Deliveries Man Screen when the FXML file is loaded.
	* It sets the facility label, images and buttons status according to the facility type of the user. 
	* Also, it sets the welcome message and user information in the text area.
	*
	*/
	@FXML
	public void initialize() {
		if (facility.equals("WAREHOUSE")) {
			configLbl.setText("OL");
			OLpic.setVisible(true);
			EKpic.setVisible(false);
			ChangingStatus.setDisable(false);
			 ApproveDelivery.setDisable(false);
		}
		else {
			configLbl.setText("EK");
			OLpic.setVisible(false);
			EKpic.setVisible(true);
			ChangingStatus.setDisable(true);
			ApproveDelivery.setDisable(true);
		}
		hello.setText("Welcome, " + firstName);
		userLog.setText("Phone number:" + phone + "\n" + "Account type:" + "DeliveryOperate" + "\n"
				+ "Responsible for an area:" + region);

	}

	/**
	    * Returns the first name.
	    * 
	    * @return the first name
	    */
	public static String getFirstName() {
		return firstName;
	}

    /**
    * Sets the first name.
    * 
    * @param firstName the new first name
    */
	public static void setFirstName(String firstName) {
		OperatesDeliveriesManScreenController.firstName = firstName;
	}

    /**
    * Returns the region.
    * 
    * @return the region
    */
	public static String getRegion() {
		return region;
	}

	   /**
	    * Sets the region.
	    * 
	    * @param region the new region
	    */
	public static void setRegion(String region) {
		OperatesDeliveriesManScreenController.region = region;
	}

	  /**
	    * Returns the phone.
	    * 
	    * @return the phone
	    */
	public static String getPhone() {
		return phone;
	}

    /**
    * Sets the phone.
    * 
    * @param phone the new phone
    */
	public static void setPhone(String phone) {
		OperatesDeliveriesManScreenController.phone = phone;
	}

    /**
    * Returns the facility.
    * 
    * @return the facility
    */
	public static String getFacility() {
		return facility;
	}

    /**
    * Sets the facility.
    * 
    * @param facility the new facility
    */
	public static void setFacility(String facility) {
		OperatesDeliveriesManScreenController.facility = facility;
	}

}
