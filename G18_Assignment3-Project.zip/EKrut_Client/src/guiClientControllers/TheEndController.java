package guiClientControllers;

import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.io.IOException;

import client.ClientMissionHandler;
import entities.TimeMeasurementThread;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;

/**
 * The class TheEndController is an implementation of EventHandler which handle the end of the order process.
 *
 * @author Eyal
 */
public class TheEndController implements EventHandler<WindowEvent> {

    /**
     * The variable pickupOrDelivery holds the user's choice of pickup or delivery.
     */
	private static String pickupOrDelivery;

    /**
     * The variable facility holds the user's choice of facility.
     */
	private static String facility;

    /**
     * The variable deliveryCity holds the user's choice of delivery city.
     */
	private static String deliveryCity;

    /**
     * The variable deliveryAddress holds the user's choice of delivery address.
     */
	private static String deliveryAddress;

    /**
     * The variable orderNum holds the order number.
     */
	private static Integer orderNum;

    /**
     * The backToMenu button allows the user to return to the menu.
     */
	@FXML
	private Button backToMenu;

    /**
     * The orderNumberLabel displays the order number.
     */
	@FXML
	private Label orderNumberLabel;

	/**
	* This method is used to initialize the TheEndController class.
	* It sets the text of the orderNumberLabel according to the user's choice of pickup or delivery,
	* and the configuration of the program.
	*
	* @throws IOException if there is an error reading the configuration file.
	*/
	@FXML
	public void initialize() throws IOException {
		if (pickupOrDelivery != null && pickupOrDelivery.equals("Pickup")
				&& MainCustomerPageController.getConfig().equals("OL")) {
			orderNumberLabel.setText("Order Number: " + orderNum);
		} else if (MainCustomerPageController.getConfig().equals("EK")) {
			orderNumberLabel.setText("EK-OP is now working on your order");
		}

	}

	/**
	* This method is used to start the TheEndController class, it loads the "TheEnd.fxml" file,
	* sets the icon, title, and scene of the primary stage, and sets the stage to close when the 
	* "X" button is clicked. It also starts the TimeMeasurementThread and adds an EventFilter 
	* to the scene that starts the time measurement when the mouse is pressed.
	*
	* @param primaryStage the primary stage of the program.
	* @throws IOException if there is an error loading the "TheEnd.fxml" file.
	*/
	public void start(Stage primaryStage) throws IOException {
		final Parent root = (Parent) FXMLLoader.load(this.getClass().getResource("/guiClientScreens/TheEnd.fxml"));
		primaryStage.getIcons().add(new Image(TheEndController.class.getResourceAsStream("/pictures/ekrutIcon.png")));

		final Scene scene = new Scene(root);
		primaryStage.setTitle("YAY!!WE GOT YOUR ORDER");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.closeWindow(MainCustomerPageController.getUsername());
		});
		TimeMeasurementThread.setStage(primaryStage);
		scene.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
		@Override
		public void handle(MouseEvent mouse) {
			if (mouse.getSource() != null) {
					TimeMeasurementThread.startTime = (System.currentTimeMillis());
				}
			}
		});
	}
	
	/**
    * Getter for the static variable orderNum.
    * @return the order number.
    */	
	public static Integer getOrderNum() {
		return orderNum;
	}

    /**
    * Setter for the static variable orderNum.
    * @param orderNum the order number to set.
    */
	public static void setOrderNum(Integer orderNum) {
		TheEndController.orderNum = orderNum;
	}
    
    /**
    * Getter for the static variable deliveryCity.
    * @return the delivery city.
    */
	public static String getDeliveryCity() {
		return deliveryCity;
	}

    /**
    * Setter for the static variable deliveryCity.
    * @param deliveryCity the delivery city to set.
    */
	public static void setDeliveryCity(String deliveryCity) {
		TheEndController.deliveryCity = deliveryCity;
	}

    /**
    * Getter for the static variable deliveryAddress.
    * @return the delivery address.
    */
	public static String getDeliveryAddress() {
		return deliveryAddress;
	}

    /**
    * Setter for the static variable deliveryAddress.
    * @param deliveryAddress the delivery address to set.
    */
	public static void setDeliveryAddress(String deliveryAddress) {
		TheEndController.deliveryAddress = deliveryAddress;
	}

    /**
    * Getter for the static variable pickupOrDelivery.
    * @return the choice of pickup or delivery.
    */
	public static String getPickupOrDelivery() {
		return pickupOrDelivery;
	}

	/**
    * Setter for the static variable pickupOrDelivery.
    * @param pickupOrDelivery the choice of pickup or delivery to set.
    */
	public static void setPickupOrDelivery(String pickupOrDelivery) {
		TheEndController.pickupOrDelivery = pickupOrDelivery;
	}
	
    /**
    * Getter for the static variable facility.
    * @return the facility.
    */
	public static String getFacility() {
		return facility;
	}

    /**
    * Setter for the static variable facility.
    * @param facility the facility to set.
    */
	public static void setFacility(String facility) {
		TheEndController.facility = facility;
	}

    /**
    * This method is called when the Back button is pressed. It hides the current window and opens a new MainCustomerPage window.
    *
    * @param event the ActionEvent that triggered the method.
    * @throws IOException if there is an error loading the MainCustomerPage.fxml file.
    */
	@FXML
	void Back(ActionEvent event) throws IOException {
		final Stage primaryStage = new Stage();
		((Node) event.getSource()).getScene().getWindow().hide();
		MainCustomerPageController main = new MainCustomerPageController();
		main.start(primaryStage);
	}

    /**
    * This method is called when a WindowEvent occurs. It's empty and can be overridden to add functionality.
    *
    * @param event the WindowEvent that triggered the method.
    */
	@Override
	public void handle(WindowEvent event) {
		// TODO Auto-generated method stub

	}

}
