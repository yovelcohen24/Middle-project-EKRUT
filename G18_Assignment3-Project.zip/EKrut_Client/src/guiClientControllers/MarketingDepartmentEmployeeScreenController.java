package guiClientControllers;

import java.io.IOException;

import client.ClientMissionHandler;
import common_entities.DeliveryInfo;
import common_entities.Saletable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Callback;

/**
 * 
 * 
 * This class is responsible for the Marketing Department Employee Screen.
 * It contains fields for username, firstName, region, phone, facility, configLbl, userLog, erorlable, runSale, logOut, salesTable, saleCode, productName, and description.
 * It also contains methods for handling the close request of the window and for initializing the screen.
 * 
 * @author Eyal
 */
public class MarketingDepartmentEmployeeScreenController  implements EventHandler<WindowEvent> {
	
	private static String username;
	private static String firstName;
	private static String region;
	private static String phone;
	private static String facility;
	@FXML
    private ImageView OLpic;

    @FXML
    private ImageView EKpic;

    @FXML
    private Label configLbl;
	
	@FXML
    private TextArea userLog;

    @FXML
    private Label erorlable;

    @FXML
    private Button runSale;

    @FXML
    private Button logOut;

    @FXML
    private TableView<Saletable> salesTable;

    @FXML
    private TableColumn<Saletable,Integer> saleCode;

    @FXML
    private TableColumn<Saletable, String> productName ;

    @FXML
    private TableColumn<Saletable, String> description;

    ObservableList<Saletable> dataToTable = FXCollections.observableArrayList();

	/**
	* @author Eyal
	* 
	* This method is responsible for starting the Marketing Department Employee Screen.
	* It creates a new stage, sets the scene, shows the primary stage, sets it to be not resizable, and adds a close request event to it.
	* @param primaryStage the stage on which the screen is displayed.
	* @throws IOException if the FXML file is not found.
	*/
    public void start(Stage primaryStage) throws IOException {

		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/MarketingDepartmentEmployeeScreen.fxml"));
		primaryStage.getIcons().add(
				new Image(OperatesDeliveriesManScreenController.class.getResourceAsStream("/pictures/ekrutIcon.png")));

		Scene scene = new Scene(root);
		primaryStage.setTitle("E-Krut Marketing Department Employee page");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);
		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.closeWindow(MarketingDepartmentEmployeeScreenController.getUsername());
		});
	}
    
	/**
	* The initialize method is automatically called by the JavaFX framework as soon as the FXML file is loaded.
	* It is used to perform initialization tasks, such as setting up table columns, connecting data to tables,
	* and setting the initial view of the screen.
	*/
    @FXML
	public void initialize() {

    	if (facility.equals("WAREHOUSE")) {
			configLbl.setText("OL");
			OLpic.setVisible(true);
			EKpic.setVisible(false);
			runSale.setDisable(false);
			salesTable.setDisable(false);
			
		}
		else {
			configLbl.setText("EK");
			OLpic.setVisible(false);
			EKpic.setVisible(true);
			runSale.setDisable(true);
			salesTable.setDisable(true);
		}
    	
    	userLog.setText("Phone number:" + phone + "\n" + "Account type:" + "Marketing Department Employee" + "\n"
				+ "Responsible for an area:" + region);
		salesTable.setEditable(false);
		salesTable.autosize();
		
		saleCode.setCellValueFactory((Callback) new PropertyValueFactory<DeliveryInfo, Integer>("saleCode"));
		productName.setCellValueFactory((Callback) new PropertyValueFactory<DeliveryInfo, String>("productName"));
		description.setCellValueFactory((Callback) new PropertyValueFactory<DeliveryInfo, String>("description"));
		salesTable.setItems(dataToTable);
		ClientMissionHandler.refreshSaleTable(region, dataToTable, erorlable);

	}
    
    /**
  	* @FXML
  	* The logOut method is used to log out the user from the application by hiding the current window and opening the login screen. 
  	* The method also calls the logOut method from the ClientMissionHandler class passing the current user's username as a parameter.
  	* 
  	* @param event The event that triggers the method. It is a mouse click on the logout button.
  	* @throws IOException
  	*/
    @FXML
    void logOut(ActionEvent event) throws IOException {
    	((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		ClientLoginScreenController subController = new ClientLoginScreenController();
		subController.start(primaryStage);
		ClientMissionHandler.logOut(username);
    }

	/**
	* This method is used to run a selected sale from the sales table to the subscribers 
	* in a specific region. 
	*
	* @param event This is a MouseEvent object that triggers the method when the runSale button is clicked.
	*
	* The method first checks if any sale is selected from the sales table. 
	* If a sale is selected, it sets the region of that sale to the region of the user 
	* running the sale and passes that sale object to the ClientMissionHandler.runSale method. 
	* This method then refreshes the sales table to update it with the new changes.
	* If no sale is selected, it sets the error label to an error message telling the user to select a sale first.
	*/
    @FXML
    void runSaletoSubscriber(MouseEvent event) {
    	Saletable selectedsales = salesTable.getSelectionModel().getSelectedItem();
		if (selectedsales != null) {
			selectedsales.setRegion(region);
			ClientMissionHandler.runSale(selectedsales, erorlable);
			ClientMissionHandler.refreshSaleTable(region, dataToTable, erorlable);

		} else {
			erorlable.setText("You must choose a user to approve!");

		}
    }
    
    /**
   	 * 
   	 * @return the username of the Marketing Department Employee user.
   	 */
    public static String getUsername() {
		return username;
	}

	/**
	 * 
	 * @param username - sets the username of the Marketing Department Employee user.
	 */
	public static void setUsername(String username) {
		MarketingDepartmentEmployeeScreenController.username = username;
	}

	/**
	 * 
	 * @return the first name of the Marketing Department Employee user.
	 */
	public static String getFirstName() {
		return firstName;
	}

	/**
	 * 
	 * @param firstName - sets the first name of the Marketing Department Employee user.
	 */
	public static void setFirstName(String firstName) {
		MarketingDepartmentEmployeeScreenController.firstName = firstName;
	}

	/**
	 * 
	 * @return the region that the Marketing Department Employee user is responsible for.
	 */
	public static String getRegion() {
		return region;
	}

	/**
	 * 
	 * @param region - sets the region that the Marketing Department Employee user is responsible for.
	 */
	public static void setRegion(String region) {
		MarketingDepartmentEmployeeScreenController.region = region;
	}

	/**
	 * 
	 * @return the phone number of the Marketing Department Employee user.
	 */
	public static String getPhone() {
		return phone;
	}

	/**
	 * 
	 * @param phone - sets the phone number of the Marketing Department Employee user.
	 */
	public static void setPhone(String phone) {
		MarketingDepartmentEmployeeScreenController.phone = phone;
	}

	/**
	* Handle the window event
	* @param event the window event to be handled
	*/
	@Override
	public void handle(WindowEvent event) {
		// TODO Auto-generated method stub
		
	}
	
	/**
	* Get the facility of the MarketingDepartmentEmployeeScreenController
	* @return the facility of the MarketingDepartmentEmployeeScreenController
	*/
	public static String getFacility() {
		return facility;
	}
	
	/**
	* Set the facility of the MarketingDepartmentEmployeeScreenController
	* @param facility the facility to set
	*/
	public static void setFacility(String facility) {
		MarketingDepartmentEmployeeScreenController.facility = facility;
	}

}