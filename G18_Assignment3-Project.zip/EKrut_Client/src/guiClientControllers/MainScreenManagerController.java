package guiClientControllers;

import java.io.IOException;
import java.util.ArrayList;

import client.ClientMissionHandler;
import common_entities.ProductInStock;
import common_enums.Region;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * 
 * 
 * Class representing the MainScreenManagerController.
 * This class contains fields and methods related to the main screen functionality. 
 * 
 * @author Nataly
 */
public class MainScreenManagerController implements EventHandler<WindowEvent> {
	/**
     * A boolean variable to check whether a popup message is appearing or not
     */
	public static Boolean isAppearPopUpMsg = false;
    /**
     * A boolean variable to check whether a popup message already appeared or not
     */
	public static Boolean alreadyAppearPopUpMsg = false;
    /**
     * A String variable to hold the firstName
     */
	private static String firstName;
    /**
     * A String variable to hold the role
     */
	private static String role;
	 /**
     * A Region variable to hold the region
     */
	private static Region region;
    /**
     * A String variable to hold the phone
     */
	private static String phone;
    /**
     * A String variable to hold the username
     */
	private static String username;
    /**
     * A String variable to hold the email
     */
	private static String email;
    /**
     * A String variable to hold the facility
     */
	private static String facility;

    /**
     *  A method to get the facility
     *  @return facility
     */
	public static String getFacility() {
		return facility;
	}

    /**
     * A method to set the facility
     * @param facility 
     */
	public static void setFacility(String facility) {
		MainScreenManagerController.facility = facility;
	}

    /**
     * A method to get the email
     * @return email
     */
	public static String getEmail() {
		return email;
	}

    /**
     * A method to set the email
     * @param email 
     */
	public static void setEmail(String email) {
		MainScreenManagerController.email = email;
	}

    /**
     * A method to get the username
     * @return username
     */
	public static String getUsername() {
		return username;
	}

	  /**
     * A method to set the username
     * @param username 
     */	
	public static void setUsername(String username) {
		MainScreenManagerController.username = username;
	}

	@FXML
	private ImageView EKpic;

	@FXML
	private ImageView OLpic;

	@FXML
	private Label configLbl;

	@FXML
	private Button editThresholdLevelBtn;

	@FXML
	private Circle notificatonCircle = new Circle();

	@FXML
	private Label notificatonLabel = new Label();

	@FXML
	private Button approveCustomerBtn;

	@FXML
	private Button logoutButton;

	@FXML
	private TextArea consoleUser;

	@FXML
	private Button ThresholdLevelBtn;

	@FXML
	private Button viewReportsBtn;

	@FXML
	private Label welcomeLabel;

	public static ArrayList<ProductInStock> products;

	/**
	* A method that handles the action of clicking on the back button
	* @param event the event that triggers the method
	* @throws IOException 
	*/
	@FXML
	void Back(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		MainScreenManagerController mainManagerScreen = new MainScreenManagerController();
		mainManagerScreen.start(primaryStage);
	}

	/**
	* @author Eyal
	* 
	* This class handles the event of clicking the "Approve" button for a customer.
	* It hides the current window and opens a new stage for the ApproveCustomerController.
	*/
	@FXML
	void clickApproveCustomer(MouseEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		ApproveCustomerController approveCustomerController = new ApproveCustomerController();
		approveCustomerController.start(primaryStage);
	}

	/**
	* @author Eyal
	* 
	* This class handles the event of clicking the "View Reports" button.
	* It hides the current window and opens a new stage for the ChooseReportScreenController,
	* setting the role to "RegionalManager" and the region to the specified region.
	*/
	@FXML
	void clickViewReports(MouseEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		ChooseReportScreenController.setRole("RegionalManager");
		ChooseReportScreenController.setRegion(region.toString());
		ChooseReportScreenController reportScreen = new ChooseReportScreenController();
		reportScreen.start(primaryStage);
	}

    /**
     * Returns the region of the current user
     * @return The region of the current user
     */
	public static Region getRegion() {
		return region;
	}

	   /**
     * Sets the region of the current user
     * @param region The region to set for the current user
     */
	public static void setRegion(String region) {
		MainScreenManagerController.region = Region.valueOf(region);
	}

    /**
     * Returns the first name of the current user
     * @return The first name of the current user
     */
	public String getFirstName() {
		return firstName;
	}

    /**
     * Sets the first name of the current user
     * @param firstName The first name to set for the current user
     */
	public static void setFirstName(String firstName) {
		MainScreenManagerController.firstName = firstName;
	}

	  /**
     * Returns the role of the current user
     * @return The role of the current user
     */
	public String getRole() {
		return role;
	}

    /**
     * Sets the role of the current user
     * @param role The role to set for the current user
     */
	public static void setRole(String role) {
		MainScreenManagerController.role = role;
	}

    /**
     * Returns the phone of the current user
     * @return The phone of the current user:
     */
	public static String getPhone() {
		return phone;
	}

	  /**
     * Sets the phone of the current user
     * @param phone The phone to set for the current user
     */
	public static void setPhone(String phone) {
		MainScreenManagerController.phone = phone;
	}
	
	   /**
	    * @author Eyal
	    * 
	    * This class handles the initialization of the Main Screen for the Manager.
	    * It sets the visibility of certain elements based on the facility and role of the user,
	    * sets the welcome label and console user label, and checks for trash hold notifications.
	    */
	@FXML
	public void initialize() throws IOException {
		if (facility.equals("WAREHOUSE")) {
			EKpic.setVisible(false);
			OLpic.setVisible(true);
			configLbl.setText("OL");
			setDisabality(false);
		} else {
			EKpic.setVisible(true);
			OLpic.setVisible(false);
			configLbl.setText("EK");
			setDisabality(true);
		}

		welcomeLabel.setText("Welcome, " + firstName);
		consoleUser.setText("Username: " + username + "\nPhone number: " + phone + "\n" + "Confirmed as " + role
				+ "\nRegion: " + region.toString());

		if (MainScreenManagerController.isAppearPopUpMsg == false) {
			ClientMissionHandler.CHECK_TRASH_HOLD(region.toString(), null, false);
			if (isAppearPopUpMsg)
				alreadyAppearPopUpMsg = false;
		}
		notificatonLabel.setVisible(isAppearPopUpMsg);
		notificatonCircle.setVisible(isAppearPopUpMsg);
	}

    /**
    * @author Eyal
    * 
    * This class starts the Main Screen for the Manager by loading the MainScreenManager.fxml file,
    * setting the title and scene of the primary stage, and setting the primary stage as not resizable.
    * It also sets an onCloseRequest event to close the window and send a notification to the server
    * and checks for inventory threshold notifications.
    */
	public void start(Stage primaryStage) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/MainScreenManager.fxml"));
		primaryStage.getIcons()
				.add(new Image(MainScreenManagerController.class.getResourceAsStream("/pictures/ekrutIcon.png")));
		Scene scene = new Scene(root);
		primaryStage.setTitle("E-Krut Manager page");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);
		if (!MainScreenManagerController.alreadyAppearPopUpMsg && isAppearPopUpMsg) {
			String str = products.toString().replace("[", "").replace("]", "").replace(", ", "");
			popUpMsgController.textToSet = "Email and SMS have been sent to the regional manager in region: "
					+ MainScreenManagerController.getRegion() + ".\n" + "SMS was sent to "
					+ MainScreenManagerController.getPhone() + "\nEmail was sent to "
					+ MainScreenManagerController.getEmail()
					+ "\nThe following products are below the threshold inventory level in your area:\n" + str;
			popUpMsgController popUp = new popUpMsgController();
			popUp.start(new Stage());
			MainScreenManagerController.alreadyAppearPopUpMsg = true;
		}
		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.closeWindow(username);
		});
	}
	
    /**
    * @author Eyal
    * 
    * This class handles the OnCloseRequest event for the Main Screen for the Manager.
    */
	@Override
	public void handle(WindowEvent event) {
		// TODO Auto-generated method stub

	}

    /**
    * @author Eyal
    * 
    * This class handles the event of clicking the "Logout" button for the Main Screen for the Manager.
    * It hides the current window and opens a new stage for the ClientLoginScreenController and sends a logout notification to the server.
    */
	@FXML
	void clickLogout(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		ClientLoginScreenController subController = new ClientLoginScreenController();
		MainScreenManagerController.isAppearPopUpMsg = false;
		subController.start(primaryStage);
		ClientMissionHandler.logOut(username);
	}

    /**
    * @author Eyal
    * 
    * This class handles the event of clicking the "Threshold Level" button for the Main Screen for the Manager.
    * It hides the current window and opens a new stage for the ThresHoldLevelController,
    * setting the region of the user.
    */	
	@FXML
	void clickThresholdLevel(MouseEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		ThresHoldLevelController.region = region.toString();
		ThresHoldLevelController thresHoldScreen = new ThresHoldLevelController();
		thresHoldScreen.start(primaryStage);
	}

    /**
    * @author Eyal
    * 
    * This class handles the event of clicking the "Edit Threshold Level" button for the Main Screen for the Manager.
    * It hides the current window and opens a new stage for the EditThresholdLevelController.
    */	
	@FXML
	void clickEditThresholdLevel(MouseEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		EditThresholdLevelController thresHoldScreen = new EditThresholdLevelController();
		thresHoldScreen.start(primaryStage);
	}
	
    /**
    * @author Eyal
    * 
    * This class is used to set the disable state of certain buttons on the Main Screen for the Manager.
    *
    * @param value boolean value that determines whether the buttons should be disabled or not
    */	
	void setDisabality(boolean value ) {
		editThresholdLevelBtn.setDisable(value);
		approveCustomerBtn.setDisable(value);
		viewReportsBtn.setDisable(value);
		ThresholdLevelBtn.setDisable(value);
	}
}
