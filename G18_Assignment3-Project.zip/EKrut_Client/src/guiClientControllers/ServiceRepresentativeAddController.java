
package guiClientControllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import client.ClientMissionHandler;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
* 
* ServiceRepresentativeAddController is a class that implements the EventHandler interface 
* and serves as the controller for the service representative add customer screen.
*
* The class contains the following fields:
*  private ComboBox month - A combobox for selecting the month of the credit card expiration date.
*  private ComboBox year - A combobox for selecting the year of the credit card expiration date.
*  private Label creditcard - A label displaying the text "credit card".
*  private Label expiration - A label displaying the text "expiration".
*  private Label cvv - A label displaying the text "CVV".
*  private TextArea userLog - A text area that displays information about the customer.
*  private Button back - A button that navigates the user back to the previous screen.
*  private TextField userName - A text field for entering the customer's name.
*  private TextField cardNumber1, cardNumber2, cardNumber3, cardNumber4 - Text fields for entering the credit card number.
*  private TextField CVV - A text field for entering the CVV code of the credit card.
*  private Label line1, line2, line3 - Labels for displaying validation errors.
*  private Button AddCustomer - A button that adds the customer to the system.
*  private Label statusLabel - A label that displays the status of the add customer operation.
*  private Button Find - A button that finds a customer in the system.
*  private Label statusLabelfind - A label that displays the status of the find customer operation.
* private static String firstName - A static variable that holds the customer's first name.
* private static String phone - A static variable that holds the customer's phone number.
*
* The class contains the following methods:
*  void clickOnAddBtn(MouseEvent event) - A method that adds the customer to the system when the AddCustomer button is clicked.
*  void clickOnFindBtn(MouseEvent event) - A method that finds the customer in the system when the Find button is clicked.
*  void clickOnBackBtn(MouseEvent event) - A method that navigates the user back to the previous screen when the back button is clicked.
* void handle(WindowEvent arg0) - A method that handles the onCloseRequest event.
* 
* @author Nataly
*/
public class ServiceRepresentativeAddController implements EventHandler<WindowEvent> {

	@FXML
	private ComboBox<String> month;

	@FXML
	private ComboBox<String> year;

	@FXML
	private Label creditcard;

	@FXML
	private Label expiration;

	@FXML
	private Label cvv;

	@FXML
	private TextArea userLog;

	@FXML
	private Button back;

	@FXML
	private TextField userName;

	@FXML
	private TextField cardNumber1;
	@FXML
	private TextField cardNumber2;
	@FXML
	private TextField cardNumber3;
	@FXML
	private TextField cardNumber4;

	@FXML
	private TextField CVV;
	@FXML
    private Label line1;
	@FXML
    private Label line2;
	@FXML
    private Label line3;

	@FXML
	private Button AddCustomer;
	@FXML
	private Label statusLabel;
	@FXML
	private Button Find;
	@FXML
	private Label statusLabelfind;
	private static String firstName;
	private static String phone;

	/**
	* void start(Stage primaryStage) - A method that runs when the class is started.
	* It loads the FXML file, sets the scene, title, icon of the primaryStage, 
	* sets the primaryStage to not resizable, and sets the OnCloseRequest event to close the window and sends a request to the server to log out the user.
	* It may throw IOException if there is an issue with loading the FXML file.
	*/
	public void start(Stage primaryStage) throws IOException {

		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/ServiceRepresentativeaddingScreen.fxml"));
		primaryStage.getIcons().add(
				new Image(ServiceRepresentativeScreenController.class.getResourceAsStream("/pictures/ekrutIcon.png")));

		Scene scene = new Scene(root);

		primaryStage.setTitle("E-Krut Service Representative page");

		primaryStage.setScene(scene);

		primaryStage.show();
		primaryStage.setResizable(false);
		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.closeWindow(ServiceRepresentativeScreenController.getUsername());
		});
	}

	/**
	*  void initialize() - A method that runs when the class is initialized.
	* It initializes the month and year comboboxes with a list of months and years. 
	* It also sets the visibility of some fields and labels to false, and sets the userLog text with the customer's phone number and account type
	*/
	@FXML
	public void initialize() {
		List<String> months = new ArrayList<String>(
				Arrays.asList("01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"));
		this.month.getItems().addAll(months);
		List<String> years = new ArrayList<String>(Arrays.asList("2023", "2024", "2025", "2026", "2027", "2028", "2029",
				"2030", "2031", "2032", "2033", "2034", "2035", "2036", "2037", "2038", "2039", "2040", "2041", "2042",
				"2043", "2044", "2045", "2046", "2047", "2048", "2049", "2050"));
		this.year.getItems().addAll(years);
		this.cardNumber1.setVisible(false);
		this.cardNumber2.setVisible(false);
		this.cardNumber3.setVisible(false);
		this.cardNumber4.setVisible(false);
		this.CVV.setVisible(false);
		this.creditcard.setVisible(false);
		this.expiration.setVisible(false);
		this.cvv.setVisible(false);
		this.year.setVisible(false);
		this.month.setVisible(false);
		this.line1.setVisible(false);
		this.line2.setVisible(false);
		this.line3.setVisible(false);
		this.AddCustomer.setVisible(false);
		userLog.setText("Phone number: " + phone + "\n" + "Account type: " + "service representative");
	}

	/**
	* @FXML void AddCustomer(ActionEvent event) - A method that is called when the AddCustomer button is clicked.
	* It calls the ClientMissionHandler.AddingCustomerNew method and passes the userName, cardNumber1, cardNumber2, cardNumber3, cardNumber4, year, month, CVV, statusLabel, creditcard, expiration, cvv, line1, line2 and line3 fields, and the AddCustomer button as arguments.
	* This method is used to add a new customer to the system.
	*/
	@FXML
	void AddCustomer(ActionEvent event) {
		ClientMissionHandler.AddingCustomerNew(this.userName, this.cardNumber1,this.cardNumber2,this.cardNumber3,this.cardNumber4, this.year, this.month, this.CVV,
				this.statusLabel, this.creditcard, this.expiration, this.cvv,this.line1,this.line2,this.line3,AddCustomer, this.Find);
	}

	/**
	* This method handles the event when the "Back" button is clicked, and takes the user back to the first screen.
	*
	* @param event The ActionEvent object that is generated when the "Back" button is clicked.
	* @throws Exception if there is an error when switching scenes.
	*/
	@FXML
	void Backtofirst(ActionEvent event) throws Exception {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		ServiceRepresentativeScreenController openScreen1 = new ServiceRepresentativeScreenController();
		openScreen1.start(primaryStage);
	}

	/**
	* This method handles the event when the "Find" button is clicked,
	* it finds the user by searching the userName in the system and displays the details on the screen.
	* @param event The ActionEvent object that is generated when the "Find" button is clicked.
	*/
	@FXML
	void findUser(ActionEvent event) {
		ClientMissionHandler.findUser(this.userName, this.statusLabelfind, this.cardNumber1,this.cardNumber2,this.cardNumber3,this.cardNumber4, this.year, this.month,
				this.CVV, this.creditcard, this.expiration, this.cvv, this.statusLabel,this.line1,this.line2,this.line3,AddCustomer,this.Find);

	}

	/**
	* Handle the WindowEvent.
	* @param arg0 The WindowEvent object that is generated when the window is closed.
	*/
	@Override
	public void handle(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	/**
	* Get the value of firstName.
	* @return the value of firstName
	*/
	public static String getFirstName() {
		return firstName;
	}

	/**
	* Set the value of firstName.
	* @param firstName new value of firstName
	*/
	public static void setFirstName(String firstName) {
		ServiceRepresentativeAddController.firstName = firstName;
	}

	/**
	* Get the value of phone.
	* @return the value of phone
	*/
	public static String getPhone() {
		return phone;
	}

	/**
	* Set the value of phone.
	* @param phone new value of phone
	*/
	public static void setPhone(String phone) {
		ServiceRepresentativeAddController.phone = phone;
	}

}
