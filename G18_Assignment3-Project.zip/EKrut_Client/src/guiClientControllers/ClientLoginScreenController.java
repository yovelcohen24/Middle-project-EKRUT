package guiClientControllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import client.ClientMissionHandler;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * 
 * 
 * 
 * This class is the controller for the ClientLoginScreen.fxml screen.
 * The class contains all the logic that is responsible for the interactions between the user and the system.
 * The class is responsible for handling the user's input of username and password, 
 * and sending the input to the server, in order to check if the user can login.
 * The class also contains the logic for the login button, which allows the user to login to the system.
 * The class also contains the start method, which is responsible for starting the login screen.
 * 
 * @author Eyal
 */
public class ClientLoginScreenController implements EventHandler<WindowEvent> {

	@FXML
	private TextField UsernameTxt;

	@FXML
	private Button userLogin;

	@FXML
	private PasswordField passwordTxt;

	@FXML
	private Label errorLabel;

    /**
    * Button for EKT login.
    */
    @FXML
    private Button ektlogin;

    /**
    * ComboBox for subscriber number.
    */
    @FXML
    private ComboBox<String> subscribernumber;
    /**
     * Label for displaying status.
     */
     @FXML
     private Label status;
    

	/**
	 * This method is responsible for handling the event of the user clicking on the login button.
	 * The method checks if the user is already logged in, if so, an error label is displayed.
	 * If the user is not logged in, the input of username and password is sent to the server, 
	 * in order to check if the user can login, and the user is redirected to the appropriate screen.
	 *
	 * @param event - the event of the user clicking on the login button
	 * @throws Exception - if the fxml file is not found
	 */
	@FXML
	void clickUserLogin(MouseEvent event) throws Exception {
		if(ClientMissionHandler.CHECK_LOGGED_IN(UsernameTxt.getText(), errorLabel))
			ClientMissionHandler.IDENTIFY_USER(event, UsernameTxt.getText(), passwordTxt.getText(), errorLabel);
	}
	 /**
	    * Handles click event for EKT login button.
	    * @param event the MouseEvent for the click event
	    * @throws Exception if an error occurs while connecting to the server or logging in
	    */
	    @FXML
	    void EKTlogin(MouseEvent event) throws Exception {
	    	if(ClientMissionHandler.CHECK_LOGGED_IN_BY_ID(subscribernumber.getValue(), status))
	    		ClientMissionHandler.EktLogin(event, subscribernumber, status);
	    }
	    /**
         * Initializes the client opening screen.
         * finds subscriber numbers, and adds them to the subscriber number ComboBox.
         * @throws Exception if an error occurs while  finding subscriber numbers
         */
         @FXML
         public void initialize() throws Exception {
             List<String> numberofsubscriber = new ArrayList<String>();
             numberofsubscriber =  ClientMissionHandler.FindSubscribernumber();
             if(numberofsubscriber!=null) {
             subscribernumber.getItems().addAll(numberofsubscriber);
             }
         }

	/**
	 * This method is responsible for starting the ClientLoginScreen.fxml screen.
	 * The method loads the fxml file, sets the title, icon, and other properties of the window.
	 * The method also contains the logic for handling the event of the user closing the window.
	 *
	 * @param primaryStage - the stage for the screen
	 * @throws IOException - if the fxml file is not found
	 */
	public void start(Stage primaryStage) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/ClientLoginScreen.fxml"));
		Scene scene = new Scene(root);
		primaryStage.getIcons().add(new Image(ClientLoginScreenController.class.getResourceAsStream("/pictures/ekrutIcon.png")));
		primaryStage.setTitle("E-Krut Login");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);

		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.DISCONNECT_FROM_SERVER();
			Platform.exit();
			System.exit(0);
		});
	}

	@Override
	public void handle(WindowEvent event) {
		// TODO Auto-generated method stub
	}
}