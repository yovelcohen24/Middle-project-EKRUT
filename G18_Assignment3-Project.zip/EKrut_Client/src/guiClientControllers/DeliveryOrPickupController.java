package guiClientControllers;

import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.io.IOException;

import client.ClientMissionHandler;
import entities.TimeMeasurementThread;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class DeliveryOrPickupController implements EventHandler<WindowEvent> {

	/** The number of clicks on the pickup checkbox */
	int numOfPickupClicks = 0;

	/** The number of clicks on the delivery checkbox */
	int numOfDeliveryClicks = 0;
	

	/** The image view for the configuration image */
    @FXML
    private ImageView configInageOnline;

    /** The combobox for the machine */
	@FXML
	private ComboBox<String> machineCombobox;

	/** The back button */
	@FXML
	private Button backBtn;

	/** The combobox for the city */
	@FXML
	private ComboBox<String> cityText;

	/** The checkbox for delivery */
	@FXML
	private CheckBox deliveryCheck;

	/** The label for the expected delivery date */
	@FXML
	private Label expectedDate;

	/** The payment button */
	@FXML
	private Button paymentButton;

	/** The checkbox for pickup */
	@FXML
	private CheckBox pickupCheck;

	/** The text field for the street address */
	@FXML
	private TextField streetText;

	/**
     * Initializes the delivery or pickup screen by setting the options for the machine and city comboboxes based on the region and disabling certain fields.
     */
	@FXML
	public void initialize() {
		if(MainCustomerPageController.getRegion().equals("NORTH"))
		{
			machineCombobox.getItems().addAll("KIRYAT_MOTZKIN", "TIRAT_HACARMEL");
			cityText.getItems().addAll("KIRYAT_MOTZKIN", "TIRAT_HACARMEL");
		}
		else if(MainCustomerPageController.getRegion().equals("SOUTH"))	
		{
			machineCombobox.getItems().addAll("EILAT",  "BEER_SHEVA");
			cityText.getItems().addAll("EILAT",  "BEER_SHEVA");
		}
		else if(MainCustomerPageController.getRegion().equals("UAE"))
		{
			machineCombobox.getItems().addAll("DUBAI","ABU_DHABI");
			cityText.getItems().addAll ("DUBAI","ABU_DHABI");
		}
		machineCombobox.setDisable(true);
		streetText.setDisable(true);
		cityText.setDisable(true);
	}

	/**
     * @author Nataly
     * The DeliveryOrPickupController class handles the logic for the DeliveryOrPickupWindow.fxml file.
     * This includes setting up the initial window, handling user input, and navigating to other screens.
     */
	public void start(Stage primaryStage) throws IOException {
		// System.out.println("start");
		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/DeliveryOrPickupWindow.fxml"));
		primaryStage.getIcons()
				.add(new Image(DeliveryOrPickupController.class.getResourceAsStream("/pictures/ekrutIcon.png")));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Delivery or Pickup");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);
		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.closeWindow(MainCustomerPageController.getUsername());
		});
		scene.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent mouse) {
				if (mouse.getSource() != null) {
					TimeMeasurementThread.startTime = (System.currentTimeMillis());
				}
			}
		});
		TimeMeasurementThread.setStage(primaryStage);
	}

	/**
     * Handles the action of clicking the back button, hides the current window and opens the ShoppingCart window.
     * 
     * @param event The event that triggered this method.
     * @throws IOException
     */
	@FXML
	void Back(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		ShoppingCartController cartScreen = new ShoppingCartController();
		cartScreen.start(primaryStage);
	}

	/**
     * Handles the action of clicking the Payment button. It checks whether the user has chosen delivery or pickup, 
     * and whether they have filled in all required fields. If everything is valid it sends a request to the server 
     * to retrieve payment data.
     * 
     * @param event The event that triggered this method.
     * @throws IOException
     */
	@FXML
	void clickPayment(ActionEvent event) throws IOException {
		if(!deliveryCheck.isSelected()&&!pickupCheck.isSelected())
		{
			expectedDate.setText("You must choose delivery or pickup");
			return;
		}
		if(pickupCheck.isSelected()&&machineCombobox.getValue()==null)
		{
			expectedDate.setText("You must choose a machine!");
			return;
		}
		if((deliveryCheck.isSelected())&&(cityText.getValue()==null||streetText.getText().equals("")))
		{
			expectedDate.setText("You must choose city and street!");
			return;
		}
		if(deliveryCheck.isSelected()&&!(streetText.getText().matches("^[a-zA-Z\\s]+([a-zA-Z\\s]+)+[0-9]$")||streetText.getText().matches("^[a-zA-Z\\s]+[0-9]$")||streetText.getText().matches("^([a-zA-Z\\s]+)+[0-9]$")||streetText.getText().matches("^[a-zA-Z\\s]+([a-zA-Z\\s]+)+[0-9]+[0-9]$")))
		{
			expectedDate.setText("You must type a valid street name!");
			return;
		}
		if (pickupCheck.isSelected()) {
			TheEndController.setPickupOrDelivery("Pickup");
			TheEndController.setFacility(machineCombobox.getValue());
		} else {
			TheEndController.setPickupOrDelivery("Delivery");
			TheEndController.setDeliveryCity(cityText.getValue());
			TheEndController.setDeliveryAddress(streetText.getText());
		}
		ClientMissionHandler.getPaymentData(event, MainCustomerPageController.getUsername());

	}

	/**
     * 
     * @author Elroi
     *
     * This method is called when the delivery checkbox is clicked.
     * It increments the numOfDeliveryClicks variable and disables/enables certain UI elements based on its value.
     * Specifically, it disables the pickupCheck checkbox, enables the streetText and cityText text fields, 
     * and disables the machineCombobox dropdown menu when the numOfDeliveryClicks is an odd number.
     * When the numOfDeliveryClicks is an even number, it enables the pickupCheck checkbox, disables the streetText and cityText text fields,
     * and enables the machineCombobox dropdown menu.
     */
	@FXML
	void clickDelivery(ActionEvent event) {
		numOfDeliveryClicks++;
		if (numOfDeliveryClicks % 2 == 1) {
			pickupCheck.setDisable(true);
			streetText.setDisable(false);
			cityText.setDisable(false);
		} else {
			pickupCheck.setDisable(false);
			streetText.setDisable(true);
			cityText.setDisable(true);
		}
		machineCombobox.setDisable(true);
	}

	/**
     * @author Elroi
     * 
     * The clickPickup method is used to handle the click event of the pickup button.
     * It increments the number of pickup clicks and enables/disables certain elements
     * based on the number of clicks.
     * 
     * @param event The ActionEvent associated with the button click
     */
	@FXML
	void clickPickup(ActionEvent event) {
		numOfPickupClicks++;
		if (numOfPickupClicks % 2 == 1) {
			deliveryCheck.setDisable(true);
			cityText.setDisable(true);
			streetText.setDisable(true);
			machineCombobox.setDisable(false);
		} else {
			deliveryCheck.setDisable(false);
			machineCombobox.setDisable(true);
		}

	}

	/**
     * @author Elroi
     * 
     * The handle method is used to handle a WindowEvent. This method is overridden
     * from the EventHandler interface.
     * 
     * @param event The WindowEvent to handle
     */
	@Override
	public void handle(WindowEvent event) {
		// TODO Auto-generated method stub

	}

}
