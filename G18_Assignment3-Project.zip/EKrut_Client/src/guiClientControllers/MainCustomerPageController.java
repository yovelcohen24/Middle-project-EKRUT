package guiClientControllers;

import java.io.IOException;

import client.ClientMissionHandler;
import entities.TimeMeasurementThread;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * 
 * The MainCustomerPageController class is used to control the Main Customer Page interface.
 * The class contains static fields to hold user information such as firstName, role, phone, username, config, facility, Region, email, subscriberFirstPurchase
 * and stage field.
 * The class implements the EventHandler interface to handle window events.
 * It contains FXML elements such as Label, ImageView, Button and TextArea to display user information and handle user interactions.
 * @author Eyal
 */
public class MainCustomerPageController implements EventHandler<WindowEvent>  {
	private static String firstName;
	private static String role;
	private static String phone;
	private static String username;
	private static String config;
	private static String facility;
	private static String Region;
	private static String email;
	private static String subscriberFirstPurchase;
	private Stage stage;


    @FXML
    private Label capital;

    @FXML
    private Button pickUp;
    
	@FXML
	private Label facilityLabel;

    @FXML
    private ImageView configImageEK;

    @FXML
    private ImageView configInageOnline;
    
	@FXML
	private Label configLabel;

	@FXML
	private Button contactUs;

	@FXML
	private Button createNewOrder;

	@FXML
	public Label hello;

	@FXML
	private Button logOut;

	@FXML
	private Button approveOrder;

	@FXML
	private TextArea userLog;

	/**
	* @author Eyal
	* The getSubscriberFirstPurchase() method is used to get the subscriberFirstPurchase value
	*
	* @return the subscriberFirstPurchase value
	*/
	public static String getSubscriberFirstPurchase() {
		return subscriberFirstPurchase;
	}

	/**
	* @author Eyal
	* The setSubscriberFirstPurchase() method is used to set the subscriberFirstPurchase value
	*
	* @param subscriberFirstPurchase the subscriberFirstPurchase value to set
	*/
	public static void setSubscriberFirstPurchase(String subscriberFirstPurchase) {
		MainCustomerPageController.subscriberFirstPurchase = subscriberFirstPurchase;
	}

	/**
	* @author Eyal
	* The getRegion() method is used to get the Region value
	*
	* @return the Region value
	*/
	public static String getRegion() {
		return Region;
	}

	/**
	* @author Eyal
	* The setRegion() method is used to set the Region value
	*
	* @param region the Region value to set
	*/
	public static void setRegion(String region) {
		Region = region;
	}

	/**
	* @author Eyal
	* The getEmail() method is used to get the email value
	*
	* @return the email value
	*/
	public static String getEmail() {
		return email;
	}

	/**
	* @author Eyal
	* The setEmail() method is used to set the email value
	*
	* @param email the email value to set
	*/
	public static void setEmail(String email) {
		MainCustomerPageController.email = email;
	}

	/**
	* @author Eyal
	* The getFacility() method is used to get the facility value
	*
	* @return the facility value
	*/
	public static String getFacility() {
		return facility;
	}

	/**
	 * @author Eyal
	 * The setFacility() method is used to set the facility value
	 *
	 * @param facility the facility value to set
	 */
	public static void setFacility(String facility) {
		MainCustomerPageController.facility = facility;
	}

	/**
	 * @author Eyal
	 * The getConfig() method is used to get the config value
	 *
	 * @return the config value
	 */
	public static String getConfig() {
		return config;
	}

	/**
	 * @author Eyal
	 * The setConfig() method is used to set the config value
	 *
	 * @param config the config value to set
	 */
	public static void setConfig(String config) {
		MainCustomerPageController.config = config;
	}

	/**
	 * @author Eyal
	 * The getFirstName() method is used to get the firstName value
	 *
	 * @return the firstName value
	 */
	public static String getFirstName() {
		return firstName;
	}

	/**
	* @author Eyal
	* The setFirstName() method is used to set the firstName value
	*
	* @param firstName the firstName value to set
	*/
	public static void setFirstName(String firstName) {
		MainCustomerPageController.firstName = firstName;
	}

	/**
	* @author Eyal
	* The getRole() method is used to get the role value
	*
	* @return the role value
	*/	
	public static String getRole() {
		return role;
	}

	/**
	* @author Eyal
	* The setRole() method is used to set the role value
	*
	* @param role the role value to set
	*/	
	public static void setRole(String role) {
		MainCustomerPageController.role = role;
	}

	/**
	* @author Eyal
	* The getPhone() method is used to get the phone value
	*
	* @return the phone value
	*/
	public static String getPhone() {
		return phone;
	}

	/**
	* @author Eyal
	* The setPhone() method is used to set the phone value
	*
	* @param phone the phone value to set
	*/
	public static void setPhone(String phone) {
		MainCustomerPageController.phone = phone;
	}

	/**
	* @author Eyal
	* The getUsername() method is used to get the username value
	*
	* @return the username value
	*/
	public static String getUsername() {
		return username;
	}

	/**
	* @author Eyal
	* The setUsername() method is used to set the username value
	*
	* @param username the username value to set
	*/
	public static void setUsername(String username) {
		MainCustomerPageController.username = username;
	}

	/**
	* @author Eyal
	* The initialize() method is used to initialize the GUI elements when the scene is loaded
	* it sets the visibility of the elements based on the value of the fields.
	*/
	@FXML
	public void initialize() {
		configInageOnline.setVisible(false);
		configImageEK.setVisible(false);
		hello.setText("Welcome, " + firstName);
		userLog.setText("Name: "+firstName+"\nPhone number: "+phone+"\nEmail: "+email+"\nAccount type: "+role+"\nRegion: "+Region);
		configLabel.setText(config);
		if (config.equals("EK"))
		{
			facilityLabel.setText(facility);
			approveOrder.setDisable(true);
			configImageEK.setVisible(true);
		}
					
		else {
			configInageOnline.setVisible(true);			
			facilityLabel.setText("Online");
			pickUp.setDisable(true);
		}
		
		capital.setText(""+firstName.toUpperCase().charAt(0));
	}

	/**
	* @author Eyal
	* The approveOrder() method is used to handle the approveOrder button click event.
	* When the button is clicked, the current window is closed and the ApproveReceivingOrderController is loaded.
	*
	* @param event the event of the button click
	* @throws IOException if the fxml file could not be loaded
	*/
	@FXML
	void approveOrder(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		ApproveReceivingOrderController subController = new ApproveReceivingOrderController();
		subController.start(primaryStage);
	}

	/**
	* @author Eyal
	* The start() method is used to handle the initialization of the MainCustomerPageController.
	* When the method is called, a new thread is created, the window is set up, and the fxml file is loaded.
	* Additionally, the method sets up the event filter for the mouse press event, and a close request event 
	* that calls the closeWindow method of the ClientMissionHandler class.
	*
	* @param primaryStage the stage to be set up
	* @throws IOException if the fxml file could not be loaded
	*/
	public void start(Stage primaryStage) throws IOException {
		// System.out.println("start");
        this.stage=primaryStage;
        TimeMeasurementThread.stop=false;
        Thread thread = new Thread(new TimeMeasurementThread(stage), "our timer");
		thread.start();
		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/MainCustomerPage.fxml"));
		primaryStage.getIcons()
				.add(new Image(MainCustomerPageController.class.getResourceAsStream("/pictures/ekrutIcon.png")));
		Scene scene = new Scene(root);
		primaryStage.setTitle("E-Krut customer page");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);
		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.closeWindow(username);
		});

		scene.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
		@Override
		public void handle(MouseEvent mouse) {
			if (mouse.getSource() != null) {
					TimeMeasurementThread.startTime = (System.currentTimeMillis());
				}
			}
		});

	}

	/**
	* @author Eyal
	* Handles the creation of a new order when the user clicks on the "Create New Order" button.
	* If the user is an EK customer, a local order will be created for the selected facility.
	* If the user is an online customer, a remote order will be created.
	* @param event the event that triggers the method call
	* @throws IOException
	*/
	@FXML
	void createNewOrder(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		if (config.equals("EK")) {
			ClientMissionHandler.CREATE_LOCAL_ORDER(facility, event);
		} else {
			ClientMissionHandler.CREATE_REMOTE_ORDER(event);
		}
	}

	/**
	* This method is responsible for handling the event when the user clicks on the "Contact Us" button.
	* The current window will be hidden and the Contact Us window will be shown.
	* 
	* @author Eyal
	* @param event the event that triggers this method.
	* @throws IOException in case the FXMLLoader fails to load the FXML file.
	*/
	@FXML
	void contactUs(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		ContactUsController showreportScreen = new ContactUsController();
		showreportScreen.start(primaryStage);
	}

	/**
	* This method is the logOut method of the MainCustomerPageController class.
	* This method is responsible for logging out the user and returning them to the login screen.
	* 
	* @author Eyal
	* @param event - an ActionEvent that represent the event of clicking on the logout button.
	* @throws IOException - if the FXML file for the login screen is not found.
	*/
	@FXML
	void logOut(ActionEvent event) throws IOException {
		TimeMeasurementThread.stop=true;
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		ClientLoginScreenController subController = new ClientLoginScreenController();
		subController.start(primaryStage);
		ClientMissionHandler.logOut(username);
	}
	
	/**
	* @author Eyal
	* handle method for the main customer page window
	* @param event - WindowEvent 
	*/
	@Override
	public void handle(WindowEvent event) {
		// TODO Auto-generated method stub

	}
	
	/**
	* 
	* @author Eyal
	* The clickPickup method is an event handler for the "pickUp" button.
	* It is responsible for handling the event of clicking on the "pickUp" button.
	* When the button is clicked, it hides the current window, creates a new stage,
	* and opens the PickupOrderController class.
	* 
	* @param event - ActionEvent 
	* @throws IOException
	*/
    @FXML
    void clickPickup(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		PickupOrderController sub = new PickupOrderController();
		sub.start(primaryStage);
    }

	


}
