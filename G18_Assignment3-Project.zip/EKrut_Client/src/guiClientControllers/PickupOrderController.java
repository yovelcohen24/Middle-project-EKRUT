package guiClientControllers;

import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Callback;

import java.io.IOException;

import client.ClientMissionHandler;
import common_entities.DeliveryInfo;
import common_entities.PickupInfo;
import entities.TimeMeasurementThread;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

/**
 * The PickupOrderController class is responsible for displaying the orders that are ready for pickup.
 * It contains an ObservableList dataToTable, which holds the data that is to be displayed in the table.
 *
 * @author Elroi
 */
public class PickupOrderController implements EventHandler<WindowEvent>{
	
		ObservableList<PickupInfo> dataToTable = FXCollections.observableArrayList();
		
	   @FXML
	    private Button backBtn;

	    @FXML
	    private Label errorLbl;

	    @FXML
	    private TableColumn<PickupInfo, Integer> orderNum;

	    @FXML
	    private Button pickupButton;

	    @FXML
	    private TableView<PickupInfo> pickupTable;

	    @FXML
	    private ImageView refresh;

	    @FXML
	    private TableColumn<PickupInfo, String> storeCol;
	    
		/**
		* The initialize method is called when the window is opened.
		* It sets the table to be non-editable, sets the column widths to fit the content, 
		* sets the cell value factories for the orderNum and Facility columns, 
		* sets the table's items to be the data in the dataToTable list, 
		* and calls the refreshPickup method from the ClientMissionHandler class to refresh the pickup table.
		* 
		*/
		public void initialize() {

			pickupTable.setEditable(false);
			pickupTable.autosize();
			orderNum.setCellValueFactory((Callback) new PropertyValueFactory<DeliveryInfo, String>("orderNum"));
			storeCol.setCellValueFactory((Callback) new PropertyValueFactory<DeliveryInfo, String>("Facility"));
			pickupTable.setItems(dataToTable);
			ClientMissionHandler.refreshPickup(MainCustomerPageController.getUsername(),MainCustomerPageController.getFacility(), dataToTable, errorLbl);

		}
		
		/**
		* This method is used to display the orderPickup screen on the primary stage.
		* The FXMLLoader is used to load the FXML file "guiClientScreens/orderPickup.fxml" and set it as the root node.
		* An icon is added to the primary stage by using the class OperatesDeliveriesManApproveScreenController to get the resource stream "/pictures/ekrutIcon.png".
		* A new Scene is created with the root node and set as the scene on the primary stage.
		* The title of the primary stage is set as "E-Krut Pick up Order" and it is set to be not resizable.
		* When the primary stage is closed, the method ClientMissionHandler.closeWindow is called with the MainCustomerPageController.getUsername as parameter.
		* TimeMeasurementThread.stop is set to true
		*
		* @param primaryStage the primary stage on which the orderPickup screen will be displayed.
		* @throws IOException if there is an error loading the FXML file.
		*/
		public void start(Stage primaryStage) throws IOException {

			Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/orderPickup.fxml"));
			primaryStage.getIcons().add(new Image(
					OperatesDeliveriesManApproveScreenController.class.getResourceAsStream("/pictures/ekrutIcon.png")));
			Scene scene = new Scene(root);
			primaryStage.setTitle("E-Krut Pick up Order");
			primaryStage.setScene(scene);
			primaryStage.show();
			primaryStage.setResizable(false);
			primaryStage.setOnCloseRequest(e -> {
				ClientMissionHandler.closeWindow(MainCustomerPageController.getUsername());
			});
			TimeMeasurementThread.stop=true;
		}

		/**
		* The Back method is used to handle the event when the "Back" button is clicked. 
		* It hides the current window and opens the main customer page by creating a new stage and calling the start method of MainCustomerPageController class.
		*
		* @param event the ActionEvent object that represents the button click event.
		* @throws IOException if there is an error loading the FXML file for the main customer page.
		*/
	    @FXML
	    void Back(ActionEvent event) throws IOException {
			((Node) event.getSource()).getScene().getWindow().hide();
			final Stage primaryStage = new Stage();
			MainCustomerPageController main = new MainCustomerPageController();
			main.start(primaryStage);
	    }

		/**
		* The clickOnRefresh method is used to handle the event when the "Refresh" button is clicked.
		* It calls the method ClientMissionHandler.refreshPickup with the parameters MainCustomerPageController.getUsername, MainCustomerPageController.getFacility, dataToTable and errorLbl.
		*
		* @param event the MouseEvent object that represents the button click event.
		*/
	    @FXML
	    void clickOnRefresh(MouseEvent event) {
	    	ClientMissionHandler.refreshPickup(MainCustomerPageController.getUsername(),MainCustomerPageController.getFacility(), dataToTable, errorLbl);
	    }


		/**
		* The clickPickup method is used to handle the event when the "Pickup" button is clicked.
		* It first checks if a pickup is selected in the pickupTable, if so it calls the method ClientMissionHandler.pickupOrder with the selected pickup and errorLbl as parameters.
		* Then it calls the method ClientMissionHandler.refreshPickup with the parameters MainCustomerPageController.getUsername, MainCustomerPageController.getFacility, dataToTable and errorLbl.
		* If no pickup is selected, it sets an error message on the errorLbl label
		*
		* @param event the ActionEvent object that represents the button click event.
		*/
	    @FXML
	    void clickPickup(ActionEvent event) {
			PickupInfo selectedPickup = pickupTable.getSelectionModel().getSelectedItem();
			if (selectedPickup != null) {
				ClientMissionHandler.pickupOrder(selectedPickup, errorLbl);
				ClientMissionHandler.refreshPickup(MainCustomerPageController.getUsername(),MainCustomerPageController.getFacility(), dataToTable, errorLbl);

			} 
			else {
				errorLbl.setTextFill(Color.RED);
				errorLbl.setText("You must choose an order to pickup!");
			}

	    }

		/**
		* handle method is responsible for handling the window event passed as an argument.
		* The method is being overridden from the parent class as indicated by the @Override annotation.
		* 
		* @param event - WindowEvent that needs to be handled.
		*/
	@Override
	public void handle(WindowEvent event) {
		// TODO Auto-generated method stub
		
	}

}
