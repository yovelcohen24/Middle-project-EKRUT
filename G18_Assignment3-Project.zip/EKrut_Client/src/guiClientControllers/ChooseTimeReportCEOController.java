package guiClientControllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import client.ClientMissionHandler;
import common_enums.Response;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * 
 * 
 * 
 *         This class is the controller for the ChooseTimeReportScreenCEO.fxml
 *         screen. The class contains all the logic that is responsible for the
 *         interactions between the user and the system. The class is
 *         responsible for handling the user's choice of month and year, and
 *         sending the chosen information to the server, in order to get the
 *         relevant report. The class also contains the logic for the back
 *         button, which allows the user to return to the main CEO screen. The
 *         class also contains the initialize method, that initiates the
 *         ComboBoxes with the months and years options.
 *         
 *         @author Eyal
 */
public class ChooseTimeReportCEOController {

	@FXML
	private Button backBtn;

	@FXML
	private Label errorLabel;

	@FXML
	private ComboBox<String> pickMonthComboBox;

	@FXML
	private ComboBox<String> pickYearComboBox;

	@FXML
	private Label selectMonthLabel;

	@FXML
	private Label selectYearLabel;

	@FXML
	private Button viewBtn;

	private static Response res;

	/**
	 * This method is responsible for handling the event of the user clicking on the
	 * back button. The method hides the current window and opens the main CEO
	 * screen.
	 *
	 * @param event - the event of the user clicking on the back button
	 * @throws IOException - if the fxml file is not found
	 */
	@FXML
	void clickOnBackBtn(MouseEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		MainCEOController ceoScreen = new MainCEOController();
		ceoScreen.start(primaryStage);
	}

	/**
	 * This method is responsible for handling the event of the user clicking on the
	 * view report button. The method checks if the user has chosen a month and
	 * year, if not, an error label is displayed. If the user has chosen a month and
	 * year, the chosen information is sent to the server, in order to get the
	 * relevant report, and the current window is closed, and the report screen is
	 * opened.
	 *
	 * @param event - the event of the user clicking on the view report button
	 */
	@FXML
	void clickOnViewReport(MouseEvent event) {
		if (pickMonthComboBox.getValue() == null || pickYearComboBox.getValue() == null) {
			errorLabel.setVisible(true);
			errorLabel.setText("Inorder to view report you must choose   YEAR, MONTH");
		} else {
			ViewDeliveriesReportScreenController.setMonth(pickMonthComboBox.getValue());
			ViewDeliveriesReportScreenController.setYear(pickYearComboBox.getValue());

			ArrayList<String> deliveryReportDetails = new ArrayList<String>(
					Arrays.asList(pickMonthComboBox.getValue(), pickYearComboBox.getValue()));
			ClientMissionHandler.GET_DELIVERIES_REPORT(event, errorLabel, deliveryReportDetails);
			if (res == Response.GET_MONTHLY_DELIVERIES_REPORT_SUCCESS) {
				errorLabel.setVisible(false);
				((Node) event.getSource()).getScene().getWindow().hide();
				Stage primaryStage = new Stage();
				ViewDeliveriesReportScreenController deliveryReport = new ViewDeliveriesReportScreenController();
				deliveryReport.start(primaryStage);
			}
		}
	}

	/**
	 * This method is responsible for initializing the ComboBoxes with the months
	 * and years options. The method also sets the error label to be invisible.
	 */
	public void initialize() {
		ArrayList<String> months = new ArrayList<String>(
				Arrays.asList("01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"));
		pickMonthComboBox.getItems().addAll(months);
		ArrayList<String> years = new ArrayList<String>(Arrays.asList("2018", "2019", "2020", "2021", "2022", "2023"));
		pickYearComboBox.getItems().addAll(years);
		errorLabel.setVisible(false);
	}

	/**
	 * This method is responsible for starting the ChooseTimeReportScreenCEO.fxml
	 * screen. The method loads the fxml file and sets the title, icon, and other
	 * properties of the window.
	 *
	 * @param primaryStage - the stage for the screen
	 * @throws IOException - if the fxml file is not found
	 */
	public void start(Stage primaryStage) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/ChooseTimeReportScreenCEO.fxml"));
		primaryStage.getIcons()
				.add(new Image(ChooseTimeReportCEOController.class.getResourceAsStream("/pictures/ekrutIcon.png")));
		Scene scene = new Scene(root);
		primaryStage.setTitle("E-Krut Reprts");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);
		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.closeWindow(MainCEOController.getUserName());
		});
	}

	public static Response getRes() {
		return res;
	}

	public static void setRes(Response res) {
		ChooseTimeReportCEOController.res = res;
	}

}
