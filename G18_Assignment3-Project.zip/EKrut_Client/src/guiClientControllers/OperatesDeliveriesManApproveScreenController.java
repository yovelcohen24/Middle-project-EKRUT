package guiClientControllers;

import java.io.IOException;

import client.ClientMissionHandler;
import common_entities.DeliveryInfo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Callback;

/**
 * 
 * 
 * OperatesDeliveriesManApproveScreenController class implements EventHandler
 * and is responsible for handling the approve delivery screen for the delivery manager.
 * It provides functionality for viewing, approving and rejecting deliveries.
 * 
 * @author Yovel
 */
public class OperatesDeliveriesManApproveScreenController implements EventHandler<WindowEvent> {
	@FXML
	private TextArea userLog;

	@FXML
	private Label errorLbl;

	@FXML
	private Button approve;

	@FXML
	private Button back;

	@FXML
	private TableView<DeliveryInfo> deliveryTable;

	@FXML
	private TableColumn<DeliveryInfo, Integer> numberOfDeliveryCol;

	@FXML
	private TableColumn<DeliveryInfo, String> phoneCol;

	@FXML
	private TableColumn<DeliveryInfo, String> emailCol;

	@FXML
	private TableColumn<DeliveryInfo, String> addressCol;

	@FXML
	private ImageView refreshImg;

    /**
    * The region of the delivery.
    */
	private static String region;
    /**
    * The first name of the customer who made the delivery.
    */
	private static String firstName;
    /**
    * The phone number of the customer who made the delivery.
    */
	private static String phone;
    /**
    * The data to be displayed in the delivery table.
    */
	ObservableList<DeliveryInfo> dataToTable = FXCollections.observableArrayList();

	/**
	* start method is responsible for setting up and displaying the approve delivery screen
	* for the delivery manager. It loads the FXML file, sets the scene and displays it on the 
	* primary stage. It also sets the icon, title and sets the stage to be non-resizable. 
	* Additionally, it sets an event handler for when the stage is closed, which is used 
	* to close the window for the corresponding user.
	* 
	* @param primaryStage the primary stage for the scene.
	* 
	* @throws IOException if the FXML file cannot be loaded.
	*/
	public void start(Stage primaryStage) throws IOException {

		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/OperatesDeliveriesManAprooveScreen.fxml"));
		primaryStage.getIcons().add(new Image(
				OperatesDeliveriesManApproveScreenController.class.getResourceAsStream("/pictures/ekrutIcon.png")));
		Scene scene = new Scene(root);
		primaryStage.setTitle("E-Krut Operates DeliveriesMan Approve page");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);
		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.closeWindow(OperatesDeliveriesManScreenController.getUsername());
		});
	}

	/**
	* clickOnApprove method is an event handler for when the approve button is clicked.
	* It gets the selected delivery from the delivery table, and if a delivery is selected,
	* it sends a request to approve the delivery and refresh the delivery table.
	* If no delivery is selected, it displays an error message.
	* 
	* @param event the event that triggered the event handler.
	* 
	* @throws IOException if an error occurs while refreshing the delivery table.
	*/	
	@FXML
	void clickOnApprove(MouseEvent event) throws IOException {
		DeliveryInfo selectedDelivery = deliveryTable.getSelectionModel().getSelectedItem();
		if (selectedDelivery != null) {
			ClientMissionHandler.approveDelivery(selectedDelivery, errorLbl);
			ClientMissionHandler.refreshDelivery(region, dataToTable, errorLbl);

		} else {
			errorLbl.setText("You must choose a user to approve!");

		}
	}

	/**
	* Backtofirst method is an event handler for when the back button is clicked.
	* It hides the current window and opens the OperatesDeliveriesManScreen.
	* 
	* @param event the event that triggered the event handler.
	* 
	* @throws IOException if an error occurs while opening the OperatesDeliveriesManScreen.
	*/	
	@FXML
	void Backtofirst(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		OperatesDeliveriesManScreenController openScreen1 = new OperatesDeliveriesManScreenController();
		openScreen1.start(primaryStage);
	}

	/**
 * getRegion method is used to get the region of the delivery.
 * 
 * @return the region of the delivery.
 */
	public static String getRegion() {
		return region;
	}

	/**
	* setRegion method is used to set the region of the delivery.
	* 
	* @param region2 the region of the delivery.
	*/	
	public static void setRegion(String region2) {
		OperatesDeliveriesManApproveScreenController.region = region2;

	}

	/**
	* getFirstName method is used to get the first name of the customer who made the delivery.
	* 
	* @return the first name of the customer who made the delivery.
	*/	
	public static String getFirstName() {
		return firstName;
	}

	/**
	* setFirstName method is used to set the first name of the customer who made the delivery.
	* 
	* @param firstName the first name of the customer who made the delivery.
	*/	
	public static void setFirstName(String firstName) {
		OperatesDeliveriesManApproveScreenController.firstName = firstName;
	}

	/**
	* initialize method is used to initialize the elements on the approve delivery screen.
	* It sets the user log, sets the delivery table to be non-editable, sets the columns for the delivery table,
	* and sets the items for the table to be the data in dataToTable.
	* It also calls a method to refresh the delivery table with deliveries from the specified region.
	*/	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@FXML
	public void initialize() {

		userLog.setText("Phone number:" + phone + "\n" + "Account type:" + "DeliveryOperate" + "\n"
				+ "Responsible for an area:" + region);
		deliveryTable.setEditable(false);
		deliveryTable.autosize();
		numberOfDeliveryCol
				.setCellValueFactory((Callback) new PropertyValueFactory<DeliveryInfo, Integer>("numberOfDelivery"));
		phoneCol.setCellValueFactory((Callback) new PropertyValueFactory<DeliveryInfo, String>("PhoneNumber"));
		emailCol.setCellValueFactory((Callback) new PropertyValueFactory<DeliveryInfo, String>("email"));
		addressCol.setCellValueFactory((Callback) new PropertyValueFactory<DeliveryInfo, String>("Address"));
		deliveryTable.setItems(dataToTable);
		ClientMissionHandler.refreshDelivery(region, dataToTable, errorLbl);

	}
	/**
	* getPhone method is used to get the phone number of the customer who made the delivery.
	* 
	* @return the phone number of the customer who made the delivery.
	*/
	public static String getPhone() {
		return phone;
	}

	/**
	* setPhone method is used to set the phone number of the customer who made the delivery.
	* 
	* @param phone the phone number of the customer who made the delivery.
	*/	
	public static void setPhone(String phone) {
		OperatesDeliveriesManApproveScreenController.phone = phone;
	}

	/**
	* clickOnRefresh method is an event handler for when the refresh button is clicked.
	* It calls a method to refresh the delivery table with deliveries from the specified region.
	* 
	* @param event the event that triggered the event handler.
	*/	
	@FXML
	void clickOnRefresh(MouseEvent event) {
		ClientMissionHandler.refreshDelivery(region, dataToTable, errorLbl);
	}

	/**
	* handle method is an overridden method from the EventHandler interface.
	* It is not used in this class.
	* 
	* @param arg0 the event that triggered the event handler.
	*/	
	@Override
	public void handle(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

}
