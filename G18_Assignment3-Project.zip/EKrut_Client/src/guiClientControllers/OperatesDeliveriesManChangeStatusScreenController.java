package guiClientControllers;

import java.io.IOException;

import client.ClientMissionHandler;
import common_entities.DeliveryInfo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Callback;

/**
 * 
 * 
 * OperatesDeliveriesManChangeStatusScreenController class implements EventHandler
 * and is responsible for handling the change status delivery screen for the delivery manager.
 * It provides functionality for changing the status of deliveries.
 * 
 * @author Dina
 */
public class OperatesDeliveriesManChangeStatusScreenController implements EventHandler<WindowEvent> {

	@FXML
	private Button changestatus;

	@FXML
	private ImageView refreshImg;

	@FXML
	private TableView<DeliveryInfo> deliveryTable;

	@FXML
	private TableColumn<DeliveryInfo, Integer> numberOfDeliveryCol;

	@FXML
	private TableColumn<DeliveryInfo, String> phoneCol;

	@FXML
	private TableColumn<DeliveryInfo, String> emailCol;

	@FXML
	private TableColumn<DeliveryInfo, String> addressCol;

    /**
    * The data to be displayed in the delivery table.
    */
	ObservableList<DeliveryInfo> dataToTable = FXCollections.observableArrayList();

	@FXML
	private TextArea userLog;

	@FXML
	private Label statusLabel1;

	@FXML
	private Button back;

    /**
    * The region of the delivery.
    */
	private static String region;
    /**
    * The first name of the customer who made the delivery.
    */
	private static String firstName;
	/**
	* The phone of the customer who made the delivery.
	*/
	private static String phone;

	/**
	* start method is used to start the change status delivery screen for the delivery manager.
	* It loads the fxml file for the change status delivery screen, sets the icons for the stage,
	* sets the title for the stage, sets the scene for the stage, shows the stage, and sets the 
	* stage to be non-resizable. It also sets an onCloseRequest event to close the window.
	*
	* @param primaryStage the stage on which the scene will be set
	* @throws IOException if an error occurs while loading the fxml file
	*/
	public void start(Stage primaryStage) throws IOException {

		Parent root = FXMLLoader
				.load(getClass().getResource("/guiClientScreens/OperatesDeliveriesManChangeStatusScreen.fxml"));
		primaryStage.getIcons().add(new Image(OperatesDeliveriesManChangeStatusScreenController.class
				.getResourceAsStream("/pictures/ekrutIcon.png")));

		Scene scene = new Scene(root);
		primaryStage.setTitle("E-Krut  Operates DeliveriesMan ChangeStatus page");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);
		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.closeWindow(OperatesDeliveriesManScreenController.getUsername());
		});
	}

	/**
	* Backtofirst method is an event handler for when the back button is clicked.
	* It hides the current window and opens the OperatesDeliveriesManScreen.
	* 
	* @param event the event that triggered the event handler.
	* 
	* @throws IOException if an error occurs while opening the OperatesDeliveriesManScreen.
	*/
	@FXML
	void Backtofirst(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		OperatesDeliveriesManScreenController openScreen1 = new OperatesDeliveriesManScreenController();
		openScreen1.start(primaryStage);
	}

	/**
	* changeStatus method is an event handler for when the change status button is clicked.
	* It gets the selected delivery and if a delivery is selected, it calls a method to change the status of the delivery,
	* and calls a method to refresh the delivery table with deliveries from the specified region.
	* If a delivery is not selected, it sets an error message on the status label.
	* 
	* @param event the event that triggered the event handler.
	* @throws IOException if an error occurs while changing the status of the delivery.
	*/
	@FXML
	void changeStatus(MouseEvent event) throws IOException {
		DeliveryInfo selectedDelivery = deliveryTable.getSelectionModel().getSelectedItem();
		if (selectedDelivery != null) {
			ClientMissionHandler.changeStatus(selectedDelivery, statusLabel1);
			ClientMissionHandler.refreshDeliverytostatus(region, dataToTable, statusLabel1);

		} else {
			statusLabel1.setText("You must choose a user to approve!");
		}
	}

	/**
	* handle method is an overridden method from the EventHandler interface.
	* It is not used in this class.
	* 
	* @param arg0 the event that triggered the event handler.
	*/
	@Override
	public void handle(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	/**
	* getRegion method is used to get the region of the delivery.
	* 
	* @return the region of the delivery.
	*/
	public static String getRegion() {
		return region;
	}

	/**
	* setRegion method is used to set the region of the delivery.
	* 
	* @param region2 the region of the delivery.
	*/
	public static void setRegion(String region2) {
		OperatesDeliveriesManChangeStatusScreenController.region = region2;

	}

	/**
	* getFirstName method is used to get the first name of the customer who made the delivery.
	* 
	* @return the first name of the customer who made the delivery.
	*/
	public static String getFirstName() {
		return firstName;
	}

	/**
	* setFirstName method is used to set the first name of the customer who made the delivery.
	* 
	* @param firstName the first name of the customer who made the delivery.
	*/
	public static void setFirstName(String firstName) {
		OperatesDeliveriesManChangeStatusScreenController.firstName = firstName;
	}

	/**
	* initialize method is used to initialize the change status delivery screen for the delivery manager.
	* It sets the text for the user log, sets the delivery table to be non-editable and auto-sizing,
	* sets the cell value factories for the delivery table columns, sets the items for the delivery table,
	* and calls a method to refresh the delivery table with deliveries from the specified region.
	*
	*/
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@FXML
	public void initialize() {

		userLog.setText("Phone number:" + phone + "\n" + "Account type:" + "DeliveryOperate" + "\n"
				+ "Responsible for an area:" + region);
		deliveryTable.setEditable(false);
		deliveryTable.autosize();
		numberOfDeliveryCol
				.setCellValueFactory((Callback) new PropertyValueFactory<DeliveryInfo, Integer>("numberOfDelivery"));
		phoneCol.setCellValueFactory((Callback) new PropertyValueFactory<DeliveryInfo, String>("PhoneNumber"));
		emailCol.setCellValueFactory((Callback) new PropertyValueFactory<DeliveryInfo, String>("email"));
		addressCol.setCellValueFactory((Callback) new PropertyValueFactory<DeliveryInfo, String>("Address"));
		deliveryTable.setItems(dataToTable);
		ClientMissionHandler.refreshDeliverytostatus(region, dataToTable, statusLabel1);
	}

	/**
	* getPhone method is used to get the phone number of the customer who made the delivery.
	* 
	* @return the phone number of the customer who made the delivery.
	*/
	public static String getPhone() {
		return phone;
	}

	/**
	* setPhone method is used to set the phone number of the customer who made the delivery.
	* 
	* @param phone the phone number of the customer who made the delivery.
	*/
	public static void setPhone(String phone) {
		OperatesDeliveriesManChangeStatusScreenController.phone = phone;
	}

	/**
	* clickOnRefresH method is an event handler for when the refresh button is clicked.
	* It calls a method to refresh the delivery table with deliveries from the specified region.
	*
	* @param event the event that triggered the event handler.
	*/
	@FXML
	void clickOnRefresH(MouseEvent event) {
		ClientMissionHandler.refreshDeliverytostatus(region, dataToTable, statusLabel1);
	}

}
