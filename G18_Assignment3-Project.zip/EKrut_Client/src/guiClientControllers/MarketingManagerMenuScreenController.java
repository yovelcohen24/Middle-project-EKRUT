package guiClientControllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import client.ClientMissionHandler;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * 
 *
 * MarketingManagerMenuScreenController is the controller class for the marketing manager
 * 
 * @author Yovel
 */
public class MarketingManagerMenuScreenController  implements EventHandler<WindowEvent> {
	
    @FXML
    private ComboBox<String> startingTime;
    
    @FXML
    private ComboBox<String> endingTime;

    /**
     * The TextArea that displays the user's activity log
     */
    @FXML
    private TextArea userLog;

    /**
     * The Label that displays the status of sales
     */ 
    @FXML
    private Label statusSale;

    /**
     * The initiate button for initiating sales
     */
    @FXML
    private Button initiatebut;

    /**
     * The log out button for logging out of the application
     */
    @FXML
    private Button logOut;

    /**
     * The ComboBox for selecting the area for sales
     */
    @FXML
    private ComboBox<String> areacombo;

    /**
     * The ComboBox for selecting the template for sales
     */
    @FXML
    private ComboBox<String> templatecombo;

    /**
     * The username of the user
     */
    private static String username;
    /**
     * The first name of the user
     */
	private static String firstName;
    /**
     * The phone of the user
     */
	private static String phone;
    /**
     * The facility of the user
     */
	private static String facility;
    /**
     * The ImageView for displaying OLpic
     */
	@FXML
    private ImageView OLpic;

    /**
     * The ImageView for displaying EKpic
     */
    @FXML
    private ImageView EKpic;

    /**
     * The label for displaying configLbl
     */
    @FXML
    private Label configLbl;
	
	
	
	/**
	* The start method is used to initialize and display the marketing manager menu screen.
	* @param primaryStage the primary stage of the application
	* @throws IOException when the specified fxml file is not found
	*/
	 public void start(Stage primaryStage) throws IOException {

			Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/MarketingManagerMenuScreen.fxml"));
			primaryStage.getIcons().add(
					new Image(OperatesDeliveriesManScreenController.class.getResourceAsStream("/pictures/ekrutIcon.png")));

			Scene scene = new Scene(root);
			primaryStage.setTitle("E-Krut Marketing Manager page");
			primaryStage.setScene(scene);
			primaryStage.show();
			primaryStage.setResizable(false);
			primaryStage.setOnCloseRequest(e -> {
				ClientMissionHandler.closeWindow(MarketingManagerMenuScreenController.getUsername());
			});
		}
	 
		/**
		* The initialize method is used to initialize the elements in the marketing manager menu screen.
		* It sets the visibility of OLpic and EKpic based on the facility of the user, and sets the
		* availability of the initiate button, areacombo and templatecombo accordingly. 
		* It also fills the areacombo and templatecombo with the appropriate values and sets the text
		* of the userLog TextArea with the phone number and account type of the user.
		*/
	 @FXML
		public void initialize() {
			
		 if (facility.equals("WAREHOUSE")) {
				configLbl.setText("OL");
				OLpic.setVisible(true);
				EKpic.setVisible(false);
				initiatebut.setDisable(false);
				areacombo.setDisable(false);
				templatecombo.setDisable(false);
			}
			else {
				configLbl.setText("EK");
				OLpic.setVisible(false);
				EKpic.setVisible(true);
				initiatebut.setDisable(true);
				areacombo.setDisable(true);
				templatecombo.setDisable(true);
			}
		 
		 
		 List<String> area = new ArrayList<String>(
					Arrays.asList("NORTH", "SOUTH", "UAE"));
			this.areacombo.getItems().addAll(area);
			List<String> template = new ArrayList<String>(Arrays.asList("Get 30% for Bisli and Bamba", "1+1 for all products", "2+1  for all products","Get 20% for all products","Get 10% for all products","Get 40% for all products","Get 30% for all products","Get 50% for all products","Get 5% for kinder bueno","Get 20% for ALL DRINKS!","Get 10% for all types of chocolate!","Get 15% for all salty snacks","Get 20% for movie pack(Bamba,Bueno,Cola)","Get 15% for Teami,Snyders&Water"));
			
			this.templatecombo.getItems().addAll(template);
			
			userLog.setText("Phone number: " + phone + "\n" + "Account type: " + "Marketing Manager");
			endingTime.getItems().addAll("1:00","2:00","3:00","4:00","5:00","6:00","7:00","8:00","9:00","10:00","11:00","12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00","24:00");
	        startingTime.getItems().addAll("1:00","2:00","3:00","4:00","5:00","6:00","7:00","8:00","9:00","10:00","11:00","12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00","24:00");
		}
	 
	    /**
	    * This method returns the username of the user
	    * @return the username of the user
	    */
    public static String getUsername() {
		return username;
	}

    /**
    * This method sets the username of the user
    * @param username the new username for the user
    */
	public static void setUsername(String username) {
		MarketingManagerMenuScreenController.username = username;
	}

    /**
    * This method returns the first name of the user
    * @return the first name of the user
    */
	public static String getFirstName() {
		return firstName;
	}

    /**
    * This method sets the first name of the user
    * @param firstName the new first name for the user
    */
	public static void setFirstName(String firstName) {
		MarketingManagerMenuScreenController.firstName = firstName;
	}

    /**
    * This method returns the phone number of the user
    * @return the phone number of the user
    */
	public static String getPhone() {
		return phone;
	}

    /**
    * This method sets the phone number of the user
    * @param phone the new phone number for the user
    */
	public static void setPhone(String phone) {
		MarketingManagerMenuScreenController.phone = phone;
	}

    /**
    * This method is called when the initiate button is clicked.
    * It calls the initiateActivation method in the ClientMissionHandler class, passing in the values of areacombo, templatecombo, and statusSale
    * @param event the ActionEvent that triggered this method call
    */
	@FXML
    void initiateActivationSales(ActionEvent event) {
		if(areacombo.getValue()==null || templatecombo.getValue()==null || startingTime.getValue()==null || endingTime.getValue()==null)
		{
			statusSale.setText("You must choose Area,\nTemplate, starting time and\nending time");
			return;
		}
		String[]starting=startingTime.getValue().split(":");
		int startingSaleTime=Integer.parseInt(starting[0]);
		String[]ending=endingTime.getValue().split(":");
		int endingSaleTime=Integer.parseInt(ending[0]);
		if(startingSaleTime>=endingSaleTime)
		{
			statusSale.setText("Please choose a starting time\nthat is less than the\nending time");
		}
		else {
			ClientMissionHandler.initiateActivation(areacombo,templatecombo,statusSale, startingSaleTime, endingSaleTime);
		}
    }

    /**
    * This method is called when the log out button is clicked.
    * It closes the current window, opens the login screen, and calls the logOut method in the ClientMissionHandler class, passing in the username of the user
    * @param event the ActionEvent that triggered this method call
    * @throws IOException when the fxml file for the login screen is not found
    */
    @FXML
    void logOut(ActionEvent event) throws IOException {
    	((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		ClientLoginScreenController subController = new ClientLoginScreenController();
		subController.start(primaryStage);
		ClientMissionHandler.logOut(username);
    }

    /**
    * This method is called when a window event occurs.
    * @param event the WindowEvent that triggered this method call
    */
	@Override
	public void handle(WindowEvent event) {
		// TODO Auto-generated method stub
		
	}
    /**
    * This method returns the facility of the user
    * @return the facility of the user
    */
	public static String getFacility() {
		return facility;
	}
	
	  /**
	    * This method sets the facility of the user
	    * @param facility the new facility of the user
	    */
	public static void setFacility(String facility) {
		MarketingManagerMenuScreenController.facility = facility;
	}

}
