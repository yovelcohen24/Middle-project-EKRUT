package guiClientControllers;

import client.ClientController;
import javafx.application.Application;
import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
* ClientUI is the main class that extends the javafx Application class and serves as the entry point of the application.
* This class initializes the necessary fields and launches the application.
*
* @author Eyal
*/
public class ClientUI extends Application {
    /**
     * A static variable of type ClientController that is used to control the client.
     */
	public static ClientController chat;
    /**
     * A static variable of type String that holds the configuration of the application.
     */
	public static String config;
    /**
     * A static variable of type String that holds the facility of the application.
     */
	public static String facility;

    /**
     * The main method that is executed when the program starts.
     * It checks the number of arguments passed in and sets the config and facility accordingly.
     * Then, it launches the application.
     *
     * @param args the command line arguments passed in when the program starts.
     * @throws Exception any exception that may occur while launching the application.
     */
	public static void main(final String[] args) throws Exception {
		if (args.length==1) {
			config="EK";
			facility=args[0];	
		}
		else {
			config="OL";
			facility="WAREHOUSE";	
		}
	
		launch(args);
	}

    /**
     * A method that is called when the application is launched.
     * It creates a new instance of ClientOpeningScreenController and sets the primary stage's icon.
     * Then, it calls the start method of the ClientOpeningScreenController.
     *
     * @param primaryStage the primary stage of the application.
     * @throws Exception any exception that may occur while setting up the stage.
     */	
	public void start(final Stage primaryStage) throws Exception {
		ClientOpeningScreenController cl = new ClientOpeningScreenController();
		primaryStage.getIcons().add(new Image(ClientUI.class.getResourceAsStream("/pictures/ekrutIcon.png")));
		cl.start(primaryStage);
	}

}
