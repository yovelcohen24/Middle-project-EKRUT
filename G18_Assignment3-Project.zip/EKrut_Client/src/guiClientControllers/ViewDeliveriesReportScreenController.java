package guiClientControllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import client.ClientMissionHandler;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
* This class contains the fields and methods used to display the deliveries report screen.
*
* @author Dina
*/
public class ViewDeliveriesReportScreenController {

    private static String month;
    private static String year;
    private static HashMap<String, ArrayList<String>> information;

    /**
    * Gets the information for the report
    * @return the information for the report
    */
    public static HashMap<String, ArrayList<String>> getInformation() {
        return information;
    }

    /**
    * Sets the information for the report
    * @param information the information to set
    */
    public static void setInformation(HashMap<String, ArrayList<String>> information) {
        ViewDeliveriesReportScreenController.information = information;
    }

    /**
    * Gets the month for the report
    * @return the month for the report
    */
    public static String getMonth() {
        return month;
    }

    /**
    * Sets the month for the report
    * @param month the month to set
    */
    public static void setMonth(String month) {
        ViewDeliveriesReportScreenController.month = month;
    }

    /**
    * Gets the year for the report
    * @return the year for the report
    */
    public static String getYear() {
        return year;
    }

    /**
    * Sets the year for the report
    * @param year the year to set
    */
    public static void setYear(String year) {
        ViewDeliveriesReportScreenController.year = year;
    }

    @FXML
    private Label avgDeliveries;

    @FXML
    private Button backBtn;

    @FXML
    private Label bestSeller;

    @FXML
    private Label bestTime;

    @FXML
    private PieChart deliveriesPie;

    @FXML
    private Label infoLabel;

    @FXML
    private Label ordersReportLabl;

    @FXML
    private Label totalDeliveriesNumber;

    /**
    * Method that handles the event of clicking the back button on the report screen.
    * It hides the current screen and opens the ChooseTimeReportCEOController screen.
    *
    * @param event the event of clicking the back button
    * @throws IOException if the FXML file for the next screen cannot be loaded
    */
	@FXML
	void clickOnBackBtn(MouseEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		ChooseTimeReportCEOController chooseScreen = new ChooseTimeReportCEOController();
		chooseScreen.start(primaryStage);
	}

    /**
    * Initializes the report screen by setting the data for the pie chart, labels, and best time and best seller.
    */
	public void initialize() {
		ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();
		pieChartData.add(new PieChart.Data("UAE", Integer.valueOf(information.get("UAE").get(0))));
		pieChartData.add(new PieChart.Data("NORTH", Integer.valueOf(information.get("NORTH").get(0))));
		pieChartData.add(new PieChart.Data("SOUTH", Integer.valueOf(information.get("SOUTH").get(0))));
		deliveriesPie.setData(pieChartData);
		infoLabel.setText(month + "/" + year);
		bestTime.setText(information.get("UAE").get(1));
		bestSeller.setText(information.get("UAE").get(2));
		totalDeliveriesNumber.setText(information.get("totalDeliveries").get(0));
		avgDeliveries.setText(information.get("AvgDeliveries").get(0));
	}

    /**
    * This method is used to display the ViewDeliveryReportScreen.fxml
    *
    * @param primaryStage the main stage where the scene will be displayed
    */
	public void start(Stage primaryStage) {
		Parent root;
		try {
			root = FXMLLoader.load(getClass().getResource("/guiClientScreens/ViewDeliveryReportScreen.fxml"));
			Scene scene = new Scene(root);
			primaryStage.getIcons().add(new Image(
					ViewDeliveriesReportScreenController.class.getResourceAsStream("/pictures/ekrutIcon.png")));
			primaryStage.setTitle("E-Krut View Reports");
			primaryStage.setScene(scene);
			primaryStage.show();
			primaryStage.setResizable(false);
			primaryStage.setOnCloseRequest(e -> {
				ClientMissionHandler.closeWindow(MainCEOController.getUserName());
			});
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}