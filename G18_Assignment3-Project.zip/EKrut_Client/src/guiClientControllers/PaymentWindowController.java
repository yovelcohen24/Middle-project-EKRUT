package guiClientControllers;


import java.io.IOException;
import java.io.Serializable;

import client.ClientMissionHandler;
import common_enums.Response;
import entities.TimeMeasurementThread;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * The PaymentWindowController class is responsible for handling the payment window of the application.
 * It contains the methods to get and set the credit card, CVV, expiration date and ID of the user.
 * It also contains the methods to handle the events of the payment window, such as pay button and back button.
 * 
 * @author Eyal
 */
@SuppressWarnings("serial")
public class PaymentWindowController implements EventHandler<WindowEvent>, Serializable{
	private static String creditCard;
	private static String cvv;
	private static String expirationDate;
	private static String id;
	
    /**
    * The monthly bill label that shows the amount to pay.
    */
    @FXML
    private Label monthlyBillLabel;

    /**
    * The pay later button that allows the user to pay later.
    */
    @FXML
    private Button payLaterButton;

    /**
    * The error label that shows error messages.
    */
    @FXML
    private Label errorlbl;

    /**
    * The back button that allows the user to go back to the previous window.
    */
	@FXML
    private Button backBtn;

    /**
    * The credit card text field where the user enters the credit card number.
    */
    @FXML
    private TextField cardText;

    /**
     * The CVV text field where the user enters the CVV.
     */
    @FXML
    private TextField cvvText;

    /**
     * The expiration date text field where the user enters the expiration date of the credit card.
     */
    @FXML
    private TextField dateText;

    /**
     * The ID text field where the user enters the ID of the credit card.
     */
    @FXML
    private TextField idText;

    /**
     * The pay button that allows the user to pay.
     */
    @FXML
    private Button payButton;
    
    /**
    * The initialize method is responsible for initializing the payment window,
    * it sets the credit card, expiration date, CVV and ID in the corresponding text fields,
    * and sets the monthly bill label.
    * If the user is a subscriber, it sets the monthly bill label to show the user that this bill will be added to the monthly bill,
    * otherwise, it sets the pay later button to be invisible.
    * 
    */
    @FXML
 	public void initialize() {
     	cardText.setText(creditCard);
     	dateText.setText(expirationDate);
     	cvvText.setText(cvv);
     	idText.setText(id);
     	
     	if(MainCustomerPageController.getRole().equals("subscriber"))
     	{
     		monthlyBillLabel.setText("In order to add this bill\nto the monthly bill ");
     	}
     	else
     	{
     		payLaterButton.setVisible(false);
     	}
 	}
    
    /**
    * The start method is responsible for creating the payment window and displaying it to the user.
    * It loads the FXML file of the payment window and sets the title, scene and icon of the primary stage.
    * It also sets the stage to close the window when the user closes it, and adds an event filter to measure the time the user spends on the window.
    *
    * @param primaryStage, root, scene
    * @throws IOException
    */
    public void start(Stage primaryStage) throws IOException {
    	final Parent root = (Parent) FXMLLoader.load(this.getClass().getResource("/guiClientScreens/PaymentWindow.fxml"));
	      primaryStage.getIcons().add(new Image(PaymentWindowController.class.getResourceAsStream("/pictures/ekrutIcon.png")));

    	final Scene scene = new Scene(root);
		primaryStage.setTitle("Payment window");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setOnCloseRequest(e->{ClientMissionHandler.closeWindow(MainCustomerPageController.getUsername());});
		TimeMeasurementThread.setStage(primaryStage);
		scene.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
		@Override
		public void handle(MouseEvent mouse) {
			if (mouse.getSource() != null) {
					TimeMeasurementThread.startTime = (System.currentTimeMillis());
				}
			}
		});
	}
    
    /**
    * Returns the credit card number.
    * 
    * @return the credit card number
    */
    public static String getCreditCard() {
		return creditCard;
	}

    /**
    * Sets the credit card number.
    * 
    * @param creditCard the new credit card number
    */
	public static void setCreditCard(String creditCard) {
		PaymentWindowController.creditCard = creditCard;
	}

    /**
    * Returns the CVV.
    * 
    * @return the CVV
    */
	public static String getCvv() {
		return cvv;
	}

    /**
    * Sets the CVV.
    * 
    * @param cvv the new CVV
    */
	public static void setCvv(String cvv) {
		PaymentWindowController.cvv = cvv;
	}

    /**
    * Returns the expiration date.
    * 
    * @return the expiration date
    */
	public static String getExpirationDate() {
		return expirationDate;
	}
    /**
    * Sets the expiration date.
    * 
    * @param expirationDate the new expiration date
    */
	public static void setExpirationDate(String expirationDate) {
		PaymentWindowController.expirationDate = expirationDate;
	}

	/**
    * Returns the ID.
    * 
    * @return the ID
    */
	public static String getId() {
		return id;
	}

    /**
    * Sets the ID.
    * 
    * @param id the new ID
    */
	public static void setId(String id) {
		PaymentWindowController.id = id;
	}

    /**
    * The Back method is responsible for handling the event of the back button.
    * It hides the current window, and depending on the value of the config variable in the MainCustomerPageController class,
    * it either opens the DeliveryOrPickup window or the ShoppingCart window.
    *
    * @param event, primaryStage, dop, cart
    * @throws IOException
    */
    @FXML
    void Back(ActionEvent event) throws IOException {
    	final Stage primaryStage = new Stage();
    	((Node) event.getSource()).getScene().getWindow().hide();
    	if(MainCustomerPageController.getConfig().equals("OL"))
    	{
    		DeliveryOrPickupController dop=new DeliveryOrPickupController();
    		dop.start(primaryStage);
    	}
    	else
    	{	
    		ShoppingCartController cart=new ShoppingCartController();
    		cart.start(primaryStage);
    	}
    		
    }


    /**
    * The clickPay method is responsible for handling the event of the pay button.
    * It calls the updateOrder method from the ClientMissionHandler class to update the order,
    * and the updateStock method from the ClientMissionHandler class to update the stock.
    * If the user is a subscriber and it is his first purchase, it sets the subscriberFirstPurchase variable in the MainCustomerPageController to 1.
    * 
    * @param event, errorlbl
    * @throws IOException
    */
    @FXML
    void clickPay(ActionEvent event) throws IOException {
    //	System.out.println("click pay"+TheEndController.getPickupOrDelivery());
    	ClientMissionHandler.updateorder(event, ShoppingCartController.getShoppingCart(),errorlbl);
    	ClientMissionHandler.updateStock(event, ShoppingCartController.getShoppingCart(),errorlbl);
    	if(MainCustomerPageController.getRole().equals("subscriber")&&MainCustomerPageController.getSubscriberFirstPurchase().equals("0"))
    	{
    		MainCustomerPageController.setSubscriberFirstPurchase("1");
    	}
    }
    
    /**
    * The clickPayLater method is responsible for handling the event of the pay later button.
    * It calls the updateOrder method from the ClientMissionHandler class to update the order,
    * and the updateStock method from the ClientMissionHandler class to update the stock.
    * If the stock update is successful, it calls the addMonthlyBill method from the ClientMissionHandler class to add the total cost to the user's monthly bill.
    * If the user is a subscriber and it is his first purchase, it sets the subscriberFirstPurchase variable in the MainCustomerPageController to 1.
    * 
    * @param event, errorlbl
    * @throws IOException
    */
    @FXML
    void clickPayLater(ActionEvent event) throws IOException {
    	ClientMissionHandler.updateorder(event, ShoppingCartController.getShoppingCart(),errorlbl);
    	if(ClientMissionHandler.updateStock(event, ShoppingCartController.getShoppingCart(),errorlbl).equals(Response.STOCK_UPDATE_SUCCESS));
    		ClientMissionHandler.addMonthlyBill(MainCustomerPageController.getUsername(),ShoppingCartController.getTotal(),errorlbl);
    	if(MainCustomerPageController.getRole().equals("subscriber")&&MainCustomerPageController.getSubscriberFirstPurchase().equals("0"))
    	{
    		MainCustomerPageController.setSubscriberFirstPurchase("1");
    	}
    }

    /**
    * This method handles the event of the window closing.
    * It calls the closeWindow method from the ClientMissionHandler class to close the window.
    * 
    * @param event
    */
	@Override
	public void handle(WindowEvent event) {
		// TODO Auto-generated method stub
		
	}

}
