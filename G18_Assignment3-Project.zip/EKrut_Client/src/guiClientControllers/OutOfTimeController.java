package guiClientControllers;

import java.io.IOException;

import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
* 
*
* OutOfTimeController is a class that implements the EventHandler interface 
* and serves as a controller for a out of time screen.
*
*
* The class contains the following methods:
* public void start(Stage primaryStage) - A method that runs when the class is started.
* It loads the FXML file, sets the scene and title of the primaryStage, 
* sets the primaryStage to not resizable, and sets the OnCloseRequest event to this class.
* It may throw IOException if there is an issue with loading the FXML file.
* @author Eyal
*/

public class OutOfTimeController implements EventHandler<WindowEvent>{
	
	public void start(Stage primaryStage) throws IOException {

		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/OutOfTime.fxml"));
		primaryStage.getIcons().add(
				new Image(popUpMsgController.class.getResourceAsStream("/pictures/ekrutIcon.png")));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Nock Nock");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);
		primaryStage.setOnCloseRequest(this);
	}
	@Override
	public void handle(WindowEvent event) {
		// TODO Auto-generated method stub
		
	}

}
