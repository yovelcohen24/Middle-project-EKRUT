package guiClientControllers;

import java.io.IOException;

import client.ClientMissionHandler;
import common_entities.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Callback;
/**
 * ApproveCustomerController is the controller class for the approve customer screen.
 *
 * This class handles the functionality of the approve customer screen, including displaying a list of requested customers,
 * approving a selected customer, and navigating back to the main manager screen.
 * @author Maayan
 */
public class ApproveCustomerController implements EventHandler<WindowEvent> {
	ObservableList<User> dataToTable = FXCollections.observableArrayList();

	@FXML
	private Label errorLbl;

	@FXML
	private TableView<User> customerTable;

	@FXML
	private TableColumn<User, String> emailCol;

	@FXML
	private TableColumn<User, String> facilityCol;

	@FXML
	private TableColumn<User, String> firstNameCol;

	@FXML
	private TableColumn<User, String> lastNameCol;

	@FXML
	private TableColumn<User, String> userNameCol;

	@FXML
	private Button approveBtn;

	@FXML
	private Button backBtn;

	/**
	* Method that is called when the approve button is clicked.
	*
	* The method gets the selected user from the customer table and sends a request to the server to approve this customer.
	* If a customer is not selected, an error message is displayed.
	* @param event the event when the approve button is clicked
	* @throws IOException if an error occurs during the process
	* @author Maayan
	*/
	@FXML
	void clickOnApproveBtn(MouseEvent event) throws IOException {
		User selectedUser = customerTable.getSelectionModel().getSelectedItem();
		if (selectedUser != null) {
			ClientMissionHandler.APPROVE_CUSTOMERS(selectedUser);
			errorLbl.setVisible(false);
			ClientMissionHandler.GET_REQUESTED_CUSTOMERS(dataToTable);
		} else {	
			if (customerTable.getItems().size() == 0) {
				errorLbl.setText("There are no users to be approved. Try the refresh button.");
				errorLbl.setVisible(true);
			}
			else {
				errorLbl.setText("You must choose a user to approve!");
				errorLbl.setVisible(true);
			}
		}
	}

	/**
	* Method that is called when the back button is clicked.
	*
	* The method hides the current window and opens the main screen for managers.
	* @param event the event when the back button is clicked
	* @throws IOException if an error occurs during the process
	* @author Maayan
	*/
	@FXML
	void clickOnBackBtn(MouseEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		MainScreenManagerController mainManagerScreen = new MainScreenManagerController();
		mainManagerScreen.start(primaryStage);
	}

	/**
	 * Handles a mouse click event on the "Refresh" button.
	 *
	 * @author Maayan
	 * @param event the mouse event that triggered the method call
	 * @throws IOException if an error occurs while processing the request
	 */
	@FXML
	void clickRefresh(MouseEvent event) throws IOException {
		ClientMissionHandler.GET_REQUESTED_CUSTOMERS(dataToTable);
	}
	
	/**
	 * Starts a new JavaFX application window for approving customers.
	 *
	 * @author Maayan
	 * @param primaryStage the primary stage of the JavaFX application
	 * @throws IOException if an error occurs while loading the FXML layout file
	 */
	public void start(Stage primaryStage) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/ApproveCustomerScreen.fxml"));
		Scene scene = new Scene(root);
		primaryStage.getIcons()
				.add(new Image(ApproveCustomerController.class.getResourceAsStream("/pictures/ekrutIcon.png")));
		primaryStage.setTitle("E-Krut Reprts");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);
		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.closeWindow(MainScreenManagerController.getUsername());
		});
	}

	
	/**
	 * Initializes the approve customer screen by loading the customer data and populating the table.
	 * @author Maayan
	 * @throws IOException if an error occurs while loading the customer data
	 */
	@FXML
	public void initialize() throws IOException {
		errorLbl.setVisible(false);
		ClientMissionHandler.GET_REQUESTED_CUSTOMERS(dataToTable, MainScreenManagerController.getRegion().toString());
		customerTable.setEditable(false);
		customerTable.autosize();
		userNameCol.setCellValueFactory((Callback) new PropertyValueFactory<User, String>("username"));
		firstNameCol.setCellValueFactory((Callback) new PropertyValueFactory<User, String>("FirstName"));
		lastNameCol.setCellValueFactory((Callback) new PropertyValueFactory<User, String>("LastName"));
		emailCol.setCellValueFactory((Callback) new PropertyValueFactory<User, String>("email"));
		facilityCol.setCellValueFactory((Callback) new PropertyValueFactory<User, String>("storeName"));
		customerTable.setItems(dataToTable);
		errorLbl.setVisible(false);
	}

	@Override
	public void handle(WindowEvent event) {

	}
}
