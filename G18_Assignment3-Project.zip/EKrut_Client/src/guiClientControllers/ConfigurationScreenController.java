package guiClientControllers;

import java.io.IOException;

import client.ClientMissionHandler;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * The ConfigurationScreenController class is responsible for handling the functionality of the configuration screen.
 * The user can select whether to make a local or remote order and choose the machine location for local orders.
 * 
 * @author Maayan
 */
public class ConfigurationScreenController implements EventHandler<WindowEvent> {

	@FXML
	private Label error;

	@FXML
	private Button backBtn;

	@FXML
	private Button letsGoButton;

	@FXML
	private CheckBox localOrder;

	@FXML
	private ComboBox<String> machineCombobox;

	@FXML
	private CheckBox remoteOrder;

	int numOfLocalClicks = 0;

	int numOfRemoteClicks = 0;

	/**
     * Displays the configuration screen and sets the title and icon.
     * 
     * @param primaryStage The stage on which the configuration screen will be displayed
     * @throws IOException If there is an error loading the FXML file
     */
	public void start(Stage primaryStage) throws IOException {
		// System.out.println("start");
		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/configurationScreen.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("E-Krut customer page");
		primaryStage.getIcons()
				.add(new Image(ConfigurationScreenController.class.getResourceAsStream("/pictures/ekrutIcon.png")));
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);

	}

	/**
     * Initializes the configuration screen by adding the machine locations to the machine combobox and disabling it.
     */
	@FXML
	public void initialize() {
		machineCombobox.getItems().addAll("KIRYAT_MOTZKIN", "EILAT", "TIRAT_HACARMEL", "TZFAT", "TEL_AVIV",
				"BEER_SHEVA", "RAMAT_GAN");
		machineCombobox.setDisable(true);
	}
	
	/**
     * Handles the event when the back button is clicked by hiding the current window and displaying the main customer page.
     * 
     * @param event The ActionEvent that triggers this method
     * @throws IOException If there is an error loading the main customer page
     */
	@FXML
	void Back(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		MainCustomerPageController mainCustomerPageController = new MainCustomerPageController();
		mainCustomerPageController.start(primaryStage);
	}

	/**
	    * Handles the event when the local order button is clicked by disabling the remote order button and enabling the machine combobox.
	    * 
	    *
	    * @param event The ActionEvent that triggers this method
	    */
	@FXML
	void chooseLocalOrder(ActionEvent event) {
		numOfLocalClicks++;
		if (numOfLocalClicks % 2 == 1) {
			remoteOrder.setDisable(true);
			machineCombobox.setDisable(false);
		} else {
			remoteOrder.setDisable(false);
			machineCombobox.setDisable(true);
		}

	}

	/**
     * Handles the event when the remote order button is clicked by disabling the local order button and disabling the machine combobox.
     * 
     * @param event The ActionEvent that triggers this method
     */
	@FXML
	void chooseRemoteOrder(ActionEvent event) {
		numOfRemoteClicks++;
		if (numOfRemoteClicks % 2 == 1) {
			localOrder.setDisable(true);

		} else {
			localOrder.setDisable(false);
		}
		machineCombobox.setDisable(true);
	}

	/**
     * Handles the event when the 'lets go' button is clicked by creating the appropriate order and displaying any error messages.
     * 
     * @param event The ActionEvent that triggers this method
     * @throws IOException If there is an error creating the order
     */
	@FXML
	void clickLetsGo(ActionEvent event) throws IOException {
		if (localOrder.isSelected()) {
			String store = machineCombobox.getValue();
			if (machineCombobox.getSelectionModel().isEmpty()) {
				error.setText("**Please choose machine");
			} else {
				error.setText("");
				ClientMissionHandler.CREATE_LOCAL_ORDER(store, event);
			}
		} else {
			ClientMissionHandler.CREATE_REMOTE_ORDER(event);
		}

	}

	/**
     * Handles the event when the window is closed.
     *
     * @param event The WindowEvent that triggers this method
     */
	@Override
	public void handle(WindowEvent event) {
		// TODO Auto-generated method stub

	}

}