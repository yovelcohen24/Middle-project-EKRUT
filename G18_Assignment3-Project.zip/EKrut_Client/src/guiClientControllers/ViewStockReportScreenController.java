package guiClientControllers;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import client.ClientMissionHandler;
import common_enums.Facility;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.StackedBarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
* ViewStockReportScreenController is a class that handles the events for the Stock Report screen.
*
* @author Eyal
*/
public class ViewStockReportScreenController implements EventHandler<WindowEvent> {
    /**
    * @return the information
    */
	public static HashMap<String, Integer> getInformation() {
		return information;
	}

    /**
    * @param information the information to set
    */
	@SuppressWarnings("unchecked")
	public static void setInformation(Object information) {
		ViewStockReportScreenController.information = (HashMap<String, Integer>) information;
	}

    /**
    * @return the facility
    */
	private static String Date;

	public static Facility getFacility() {
		return facility;
	}

    /**
    * @param facility the facility to set
    */
	public static void setFacility(Facility facility) {
		ViewStockReportScreenController.facility = facility;
	}

	private static Facility facility;
	private static HashMap<String, Integer> information;
	private static HashMap<String, String> extraInformation;

    /**
    * @return the extraInformation
    */
	public static HashMap<String, String> getExtraInformation() {
		return extraInformation;
	}

    /**
    * @param extraInformation the extraInformation to set
    */
	public static void setExtraInformation(HashMap<String, String> extraInformation) {
		ViewStockReportScreenController.extraInformation = extraInformation;
	}

	@FXML
	private Button backBtn;

	@FXML
	private StackedBarChart<String, Integer> stockChart;

	@FXML
	private Label infoLabel;

    @FXML
    private Label marketLabel;
	
	@FXML
	private Label expiredDate;

	@FXML
	private NumberAxis numberOfTimesWentTreshold;

	@FXML
	private CategoryAxis productsName;

	   @FXML
	    private StackedBarChart<String, Integer> tresholdChart;

		/**
		* This method is called when the back button is pressed.
		* It hides the current window and opens the Choose Report screen.
		*
		* @param event the event that triggered this method
		* @throws IOException
		*/
	@FXML
	void Back(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		ChooseReportScreenController chooseReportScreen = new ChooseReportScreenController();
		chooseReportScreen.start(primaryStage);
	}

	/**
	* This method is called when the View Stock Report screen is first loaded.
	* It initializes the charts and labels on the screen with the data from the information and extraInformation maps.
	*/
	public void initialize() {
		int considerMarket = 0;
		String considerMarketProductName = null;
		for (Map.Entry<String, Integer> currentSet : information.entrySet()) {
			XYChart.Series<String, Integer> series = new XYChart.Series<>();
			if (currentSet.getValue() > considerMarket) {
				considerMarket = currentSet.getValue();
				considerMarketProductName = currentSet.getKey();
			}
				
			series.setName(currentSet.getKey());
			series.getData().add(new XYChart.Data<String, Integer>(currentSet.getKey(), currentSet.getValue()));
			stockChart.getData().add(series);
		}

		for (Map.Entry<String, String> currentSet : extraInformation.entrySet()) {
			if (!currentSet.getKey().equals("NearestExpDate")) {
				XYChart.Series<String, Integer> series = new XYChart.Series<>();
				series.setName(currentSet.getKey());
				int num = Integer.parseInt(currentSet.getValue());
				series.getData().add(
						new XYChart.Data<String, Integer>(currentSet.getKey(),num));
				tresholdChart.getData().add(series);
			}
		}
		expiredDate.setText(extraInformation.get("NearestExpDate"));
		infoLabel.setText(facility + ", " + Date);
		marketLabel.setText(considerMarketProductName);
	}

	/**
	* @return the date
	*/
	public static String getDate() {
		return Date;
	}

	/**
	* @param date the date to set
	*/
	public static void setDate(String date) {
		Date = date;
	}

	/**
	* This method starts the stage for the View Stock Report screen.
	* It loads the FXML file for the View Stock Report screen and sets it as the scene for the primary stage.
	* It also sets the title and icon for the primary stage and makes the stage non-resizable.
	* It also sets an event handler for when the stage is closed, which calls a method to close the window for the current user.
	*/
	public void start(Stage primaryStage) {
		Parent root;
		try {
			root = FXMLLoader.load(getClass().getResource("/guiClientScreens/ViewStockReportScreen.fxml"));
			primaryStage.getIcons().add(
					new Image(ViewStockReportScreenController.class.getResourceAsStream("/pictures/ekrutIcon.png")));

			Scene scene = new Scene(root);
			primaryStage.setTitle("E-Krut Reports");
			primaryStage.setScene(scene);
			primaryStage.show();
			primaryStage.setResizable(false);
			primaryStage.setOnCloseRequest(e -> {
				if (ChooseReportScreenController.getRole().equals("CEO")) {
					ClientMissionHandler.closeWindow(MainCEOController.getUserName());
				} else {
					ClientMissionHandler.closeWindow(MainScreenManagerController.getUsername());
					MainScreenManagerController.isAppearPopUpMsg = false;
				}
			});
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	* This method handles the window event.
	* It is overridden from the EventHandler interface.
	* The specific implementation of this method is not provided in the given code snippet.
	*/
	@Override
	public void handle(WindowEvent event) {
		// TODO Auto-generated method stub

	}

}
