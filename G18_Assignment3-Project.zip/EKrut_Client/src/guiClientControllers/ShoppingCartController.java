package guiClientControllers;

import java.io.IOException;

import client.ClientMissionHandler;
import common_entities.ProductInCart;
import entities.TimeMeasurementThread;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Callback;

/**
 * 
 * This class is responsible for handling the shopping cart window, including displaying the products in the cart, 
 * calculating the total price and handling the cancel and confirm order buttons.
 * 
 * @author Yovel
 */
public class ShoppingCartController implements EventHandler<WindowEvent> {

	/**
    * A list of products in the cart.
    */
	private static ObservableList<ProductInCart> shoppingCart = FXCollections.observableArrayList();
	/**
	    * The total price of products in the cart.
	    */
	private static double total;
	/**
	    * The last window.
	    */
	private static Stage lastWindow;

    /**
    * The error label to display error messages
    */
    @FXML
    private Label errorlbl;
    
	/**
     * The label that displays the total price of the products in the cart.
     */
	@FXML
	private Label totalPriceLabel;

	/**
	    * The column of the table that displays the amount of each product in the cart.
	    */
	@FXML
	private TableColumn<ProductInCart, Integer> amountColumn;

	/**
	    * The button that cancels the order.
	    */
	@FXML
	private Button cancelOrder;

	/**
	    * The button that confirms the order.
	    */
	@FXML
	private Button confirmOrder;

	/**
	    * The table that displays the products in the cart.
	    */
	@FXML
	private TableView<ProductInCart> ordersTable;

	/**
	    * The column of the table that displays the price of each product in the cart.
	    */
	@FXML
	private TableColumn<ProductInCart, Double> priceColumn;

	/**
	    * The column of the table that displays the name of each product in the cart.
	    */
	@FXML
	private TableColumn<ProductInCart, String> productColumn;

	/**
	    * The column of the table that displays the total price of each product in the cart.
	    */
	@FXML
	private TableColumn<ProductInCart, Double> totalPriceColumn;

	/**
	    * The button that goes back to the last window.
	    */
	@FXML
	private Button goBackButton;

	/**
	* Initializes the shopping cart window.
	* This method sets up the table that displays the products in the cart,
	* sets the cell value factories for each column of the table,
	* and displays the total price of the products in the cart.
	*/
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@FXML
	public void initialize() {
		ordersTable.setItems(shoppingCart);
		productColumn.setCellValueFactory((Callback) new PropertyValueFactory<ProductInCart, String>("Product"));
		amountColumn.setCellValueFactory((Callback) new PropertyValueFactory<ProductInCart, Integer>("Amount"));
		priceColumn.setCellValueFactory((Callback) new PropertyValueFactory<ProductInCart, Double>("Price"));
		totalPriceColumn.setCellValueFactory((Callback) new PropertyValueFactory<ProductInCart, Double>("TotalPrice"));
		ordersTable.getColumns().setAll(productColumn, amountColumn, priceColumn, totalPriceColumn);
		totalPriceLabel.setText("Total price: " + total + " NIS");

	}

	/**
	* Start the Shopping Cart window.
	* This method loads the fxml file of the shopping cart window,
	* sets the window's icon, title, scene and shows the window,
	* and adds an event filter for the mouse pressed event to start the time measurement.
	*/
	public void start(Stage primaryStage) throws IOException {
		final Parent root = (Parent) FXMLLoader.load(this.getClass().getResource("/guiClientScreens/ShoppingCart.fxml"));
		primaryStage.getIcons()
				.add(new Image(ShoppingCartController.class.getResourceAsStream("/pictures/ekrutIcon.png")));

		final Scene scene = new Scene(root);
		primaryStage.setTitle("Shopping Cart");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.closeWindow(MainCustomerPageController.getUsername());
		});
		scene.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
		@Override
		public void handle(MouseEvent mouse) {
			if (mouse.getSource() != null) {
					TimeMeasurementThread.startTime = (System.currentTimeMillis());
				}
			}
		});
		TimeMeasurementThread.setStage(primaryStage);
	}

	/**
	* Returns the last window.
	* @return the last window
	*/
	public static Stage getLastWindow() {
		return lastWindow;
	}

	/**
	* Sets the last window.
	* @param lastWindow the new last window to set
	*/
	public static void setLastWindow(Stage lastWindow) {
		ShoppingCartController.lastWindow = lastWindow;
	}

	/**
	* Handles the event of clicking the cancel order button.
	* This method hides the current window, opens a new Main Customer Page window and start it.
	* @param event the ActionEvent generated by clicking the cancel order button
	*/
	@FXML
	void clickCancelOrder(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		MainCustomerPageController main = new MainCustomerPageController();
		main.start(primaryStage);
	}

	/**
	* Handles the event of clicking the confirm order button.
	* This method checks if the shopping cart is empty, if it's not it get the payment data or opens the Delivery or Pickup window.
	* If the shopping cart is empty it displays an error message.
	* @param event the ActionEvent generated by clicking the confirm order button
	*/
	@FXML
	void clickConfirmOrder(ActionEvent event) throws IOException {
		if(!shoppingCart.isEmpty())
		{
			if (MainCustomerPageController.getConfig().equals("EK")) {
				ClientMissionHandler.getPaymentData(event, MainCustomerPageController.getUsername());
			} else {
				((Node) event.getSource()).getScene().getWindow().hide();
				final Stage primaryStage = new Stage();
				DeliveryOrPickupController dop = new DeliveryOrPickupController();
				dop.start(primaryStage);
			}
		}
		else
		{
			errorlbl.setText("You have to add products to the cart in order to confirm the order\nPress I want to go back and add products to the cart");
		}

	}

	/**
	* Handles the event of clicking the go back button.
	* This method hides the current window and shows the last window.
	* @param event the ActionEvent generated by clicking the go back button
	*/
	@FXML
	void clickGoBack(ActionEvent event) {
		((Node) event.getSource()).getScene().getWindow().hide();
		lastWindow.show();
	}

	/**
	* Returns the current shopping cart.
	* @return the current shopping cart
	*/
	public static ObservableList<ProductInCart> getShoppingCart() {
		return shoppingCart;
	}

	/**
	* Sets the current shopping cart.
	* @param shoppingCart1 the new shopping cart to set
	*/
	public static void setShoppingCart(ObservableList<ProductInCart> shoppingCart1) {
		shoppingCart = shoppingCart1;
	}


	/**
	* Returns the current total price of the products in the cart.
	* @return the current total price of the products in the cart
	*/
	public static double getTotal() {
		return total;
	}


	/**
	* Sets the current total price of the products in the cart.
	* @param total the new total price to set
	*/
	public static void setTotal(double total) {
		int temp;
		total=total*100;
		temp=(int)total;
		total=temp/100.0;
		ShoppingCartController.total = total;
	}


	/**
	* Handle a window event.
	* This method is empty and has no functionality.
	* @param event the WindowEvent generated by the window
	*/
	@Override
	public void handle(WindowEvent event) {
		// TODO Auto-generated method stub

	}

}
