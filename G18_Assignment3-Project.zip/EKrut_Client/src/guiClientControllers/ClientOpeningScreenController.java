package guiClientControllers;

import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;


import client.ClientMissionHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
* 
* 
* Class representing the controller for the client opening screen.
* Implements EventHandler
* @author Eyal
*/
public class ClientOpeningScreenController implements EventHandler<WindowEvent> {

    /**
    * TextField for the IP address.
    */
    @FXML
    private TextField IpTxt;

    /**
    * TextField for the port number.
    */
    @FXML
    private TextField PortTxt;

    /**
    * Button for logging in.
    */
    @FXML
    private Button loginButton;
    

    /**
    * Label for displaying status.
    */
    @FXML
    private Label status;
    
    /**
    * MouseEvent for event1.
    */
    @FXML
    private MouseEvent event1;

    /**
    * Handles click event for login button.
    * Hides the current window and calls the CONNECT_TO_SERVER method from ClientMissionHandler.
    *
    * @param event the MouseEvent for the click event
    * @throws Exception if an error occurs while connecting to the server
    */
    @FXML
    void clickLogin(MouseEvent event) throws Exception {
        ((Node) event.getSource()).getScene().getWindow().hide();
        ClientMissionHandler.CONNECT_TO_SERVER(event, IpTxt.getText(), PortTxt.getText());
    }

   

    /**
    * Starts the client opening screen.
    *
    * @param primaryStage the primary stage for the screen
    * @throws Exception if an error occurs while loading the FXML or setting up the scene
    */
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/ClientOpeningScreen.fxml"));
        primaryStage.getIcons()
                .add(new Image(ClientOpeningScreenController.class.getResourceAsStream("/pictures/ekrutIcon.png")));
        Scene scene = new Scene(root);
        primaryStage.setTitle("E-Krut Connect To Server");
        primaryStage.setScene(scene);
        primaryStage.show();
        primaryStage.setResizable(false);
        /**
         * Sets an event handler for when the primary stage is closed.
         * Exits the platform and system when the stage is closed.
         */
         primaryStage.setOnCloseRequest(e -> {
             Platform.exit();
             System.exit(0);
         });
    }
         

         /**
         * Handles a WindowEvent.
         * Currently empty, as no additional functionality is implemented.
         *
         * @param event the WindowEvent to handle
         */
         @Override
         public void handle(WindowEvent event) {
             // TODO Auto-generated method stub
         }
     }
