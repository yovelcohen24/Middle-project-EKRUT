package guiClientControllers;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import client.ClientMissionHandler;
import common_entities.ProductInCart;
import common_entities.ProductInStock;
import common_entities.Sale;
import entities.TimeMeasurementThread;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * The Class ShoppingWindowController.
 * This class handle the ShoppingWindow and the interactions with it.
 * It contains the logic for displaying products, prices and handling user interactions.
 * 
 * @author Maayan
 */
public class ShoppingWindowController implements EventHandler<WindowEvent> {

	private static ProductInStock[] products;
	private static String facility;
	private static double[] originalPrices = { 11.25, 20.0, 9.0, 5.0, 11.25, 12.0, 8.0, 20.0, 11.25, 11.25, 8.0, 10.0 };
	private static double[] prices = { 11.25, 20.0, 9.0, 5.0, 11.25, 12.0, 8.0, 20.0, 11.25, 11.25, 8.0, 10.0 };
	private static List<Sale> sales = new ArrayList<>();

	@FXML
	private ComboBox<String> saleCombobox;

	@FXML
	private ImageView bambaImage;
	
    @FXML
    private ImageView bisliImage;
    
    @FXML
    private ImageView buenoImage;
    
    @FXML
    private ImageView colaImage;

    @FXML
    private ImageView kifkefImage;
    
    @FXML
    private ImageView snydersImage;
    
    @FXML
    private ImageView spriteImage;
    
    @FXML
    private ImageView teamiImage;
    
    @FXML
    private ImageView teaImage;
    
    @FXML
    private ImageView mnmImage;
    
    @FXML
    private ImageView waterImage;
    
    @FXML
    private ImageView chocolateImage;


	@FXML
	private Button AddProducts;

	@FXML
	private Button ShoppingCart;

	@FXML
	private Button backBtn;

	@FXML
	private Spinner<Integer> BisliAdd;

	@FXML
	private Spinner<Integer> bambaAdd;

	@FXML
	private Spinner<Integer> buenoAdd;

	@FXML
	private Spinner<Integer> chocolateAdd;

	@FXML
	private Spinner<Integer> colaAdd;

	@FXML
	private Spinner<Integer> kifkefAdd;

	@FXML
	private Spinner<Integer> mnmAdd;

	@FXML
	private Spinner<Integer> snydersAdd;

	@FXML
	private Spinner<Integer> spriteAdd;

	@FXML
	private Spinner<Integer> teaAdd;

	@FXML
	private Spinner<Integer> teamiAdd;

	@FXML
	private Spinner<Integer> waterAdd;

	@FXML
	private Label bambaPrice;

	@FXML
	private Label bisliPrice;

	@FXML
	private Label buenoPrice;

	@FXML
	private Label chocolatePrice;

	@FXML
	private Label colaPrice;

	@FXML
	private Label kifkefPrice;

	@FXML
	private Label mNmPrice;

	@FXML
	private Label snydersPrice;

	@FXML
	private Label sprytePrice;

	@FXML
	private Label teaPrice;

	@FXML
	private Label teamiPrice;

	@FXML
	private Label waterPrice;

	@FXML
	private Label saleLabel;
	
	@FXML
    private ImageView bambaOutOfStock;

    @FXML
    private ImageView bisliOutOfStock;

    
    @FXML
    private ImageView chocolateOutOfStock;

  
    @FXML
    private ImageView cokeOutOfStock;

  

    @FXML
    private ImageView fuzeTeeOutOfStock;

 
    @FXML
    private ImageView kifkefOutOfStock;

  
    @FXML
    private ImageView kinderOutOfStock;

  

    @FXML
    private ImageView mnmOutOfStock;

   

    @FXML
    private ImageView snydersOutOfStock;

  

    @FXML
    private ImageView spriteOutOfStock;


    @FXML
    private ImageView teamiOutOfStock;


    @FXML
    private ImageView waterOutOfStock;
    
	/**
	* This method receives a product and returns an image for that product
	* @param product The product which image is needed
	* @return Image object that corresponds to the product
	*/
	private Image recieveImageForProduct(ProductInStock product) {
		Image image = new Image(new ByteArrayInputStream(product.getFile()));
		return image;
	}


	/**
	* This method is called when the fxml file is loaded.
	* It initializes the GUI elements and sets their values.
	* This method sets the images of the products, the prices and the amount of each product.
	* It also sets the spinner values for each product and sets the visibility of the out of stock image.
	* It also sets the available sales for the customer.
	*/
	@FXML
	public void initialize() {
		Image prodImage = null;
		saleCombobox.getItems().addAll("No sale,thanks!");
		if (MainCustomerPageController.getRole().equals("subscriber")
				&& MainCustomerPageController.getSubscriberFirstPurchase().equals("0")) {
			saleCombobox.getItems().add("Get 20% discount for all products (first purchase)");
		}
		if (MainCustomerPageController.getRole().equals("subscriber")) {
			ClientMissionHandler.getSales(MainCustomerPageController.getRegion());
			for (int i = 0; i < sales.size(); i++) {
				saleCombobox.getItems().add(sales.get(i).getDescription());
			}
		} else {
			saleCombobox.setVisible(false);
			saleLabel.setVisible(false);

		}

		SpinnerValueFactory<Integer> bisliValueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,
				products[0].getAmount(), 0, 1);
		bisliValueFactory.setValue(0);
		BisliAdd.setValueFactory(bisliValueFactory);
		prodImage = recieveImageForProduct(products[0]);
		bisliImage.setImage(prodImage);
		if(products[0].getAmount()>0)
		{
			bisliOutOfStock.setVisible(false);
		}
		else
			BisliAdd.setDisable(true);

		SpinnerValueFactory<Integer> bambaValueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,
				products[6].getAmount(), 0, 1);
		bambaValueFactory.setValue(0);
		bambaAdd.setValueFactory(bambaValueFactory);
		prodImage = recieveImageForProduct(products[6]);
		bambaImage.setImage(prodImage);
		if(products[6].getAmount()>0)
		{
			bambaOutOfStock.setVisible(false);			
		}
		else
			bambaAdd.setDisable(true);
			

		SpinnerValueFactory<Integer> buenoValueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,
				products[9].getAmount(), 0, 1);
		buenoValueFactory.setValue(0);
		buenoAdd.setValueFactory(buenoValueFactory);
		prodImage = recieveImageForProduct(products[9]);
		buenoImage.setImage(prodImage);
		if(products[9].getAmount()>0)
		{
			kinderOutOfStock.setVisible(false);
		}
		else
			buenoAdd.setDisable(true);
			

		SpinnerValueFactory<Integer> chocolateValueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,
				products[1].getAmount(), 0, 1);
		chocolateValueFactory.setValue(0);
		chocolateAdd.setValueFactory(chocolateValueFactory);
		prodImage = recieveImageForProduct(products[1]);
		chocolateImage.setImage(prodImage);
		if(products[1].getAmount()>0)
		{
			chocolateOutOfStock.setVisible(false);
		}
		else
			chocolateAdd.setDisable(true);
			
			

		SpinnerValueFactory<Integer> colaValueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,
				products[2].getAmount(), 0, 1);
		colaValueFactory.setValue(0);
		colaAdd.setValueFactory(colaValueFactory);
		prodImage = recieveImageForProduct(products[2]);
		colaImage.setImage(prodImage);
		if(products[2].getAmount()>0)
		{
			cokeOutOfStock.setVisible(false);
		}
		else
			colaAdd.setDisable(true);
			

		SpinnerValueFactory<Integer> kifkefValueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,
				products[8].getAmount(), 0, 1);
		kifkefValueFactory.setValue(0);
		kifkefAdd.setValueFactory(kifkefValueFactory);
		prodImage = recieveImageForProduct(products[8]);
		kifkefImage.setImage(prodImage);
		if(products[8].getAmount()>0)
		{
			kifkefOutOfStock.setVisible(false);
		}
		else
			kifkefAdd.setDisable(true);
			
			

		SpinnerValueFactory<Integer> mnmfValueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,
				products[10].getAmount(), 0, 1);
		mnmfValueFactory.setValue(0);
		mnmAdd.setValueFactory(mnmfValueFactory);
		prodImage = recieveImageForProduct(products[10]);
		mnmImage.setImage(prodImage);
		if(products[10].getAmount()>0)
		{
			mnmOutOfStock.setVisible(false);
		}
		else
			mnmAdd.setDisable(true);
			

		SpinnerValueFactory<Integer> snydersValueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,
				products[3].getAmount(), 0, 1);
		snydersValueFactory.setValue(0);
		snydersAdd.setValueFactory(snydersValueFactory);
		prodImage = recieveImageForProduct(products[3]);
		snydersImage.setImage(prodImage);
		if(products[3].getAmount()>0)
			snydersOutOfStock.setVisible(false);
		else
			snydersAdd.setDisable(true);

		SpinnerValueFactory<Integer> spriteValueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,
				products[4].getAmount(), 0, 1);
		spriteValueFactory.setValue(0);
		spriteAdd.setValueFactory(spriteValueFactory);
		prodImage = recieveImageForProduct(products[4]);
		spriteImage.setImage(prodImage);
		if(products[4].getAmount()>0)
			spriteOutOfStock.setVisible(false);
		else
			spriteAdd.setDisable(true);

		SpinnerValueFactory<Integer> teaValueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,
				products[7].getAmount(), 0, 1);
		teaValueFactory.setValue(0);
		teaAdd.setValueFactory(teaValueFactory);
		prodImage = recieveImageForProduct(products[7]);
		teaImage.setImage(prodImage);
		if(products[7].getAmount()>0)
			fuzeTeeOutOfStock.setVisible(false);
		else
			teaImage.setDisable(true);

		SpinnerValueFactory<Integer> teamiValueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,
				products[11].getAmount(), 0, 1);
		teamiValueFactory.setValue(0);
		teamiAdd.setValueFactory(teamiValueFactory);
		prodImage = recieveImageForProduct(products[11]);
		teamiImage.setImage(prodImage);
		if(products[11].getAmount()>0)
			teamiOutOfStock.setVisible(false);
		else
			teamiAdd.setDisable(true);

		SpinnerValueFactory<Integer> waterValueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,
				products[5].getAmount(), 0, 1);
		waterValueFactory.setValue(0);
		waterAdd.setValueFactory(waterValueFactory);
		prodImage = recieveImageForProduct(products[5]);
		waterImage.setImage(prodImage);
		if(products[5].getAmount()>0)
			waterOutOfStock.setVisible(false);
		else
			waterAdd.setDisable(true);
	}

	
	@FXML
	void Back(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		MainCustomerPageController configPage = new MainCustomerPageController();
		configPage.start(primaryStage);
	}

	public void start(Stage primaryStage) throws IOException {
		System.out.println("start shopping");
		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/ShoppingWindow.fxml"));
		primaryStage.getIcons()
				.add(new Image(ShoppingWindowController.class.getResourceAsStream("/pictures/ekrutIcon.png")));

		Scene scene = new Scene(root);
		primaryStage.setTitle("Shopping window");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);
		ShoppingCartController.setLastWindow(primaryStage);
		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.closeWindow(MainCustomerPageController.getUsername());
		});
		scene.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent mouse) {
				if (mouse.getSource() != null) {
					TimeMeasurementThread.startTime = (System.currentTimeMillis());
				}
			}
		});
		TimeMeasurementThread.setStage(primaryStage);
	}

	/**
	* 
	* @return the products in stock
	*/
	public static ProductInStock[] getProducts() {
		return products;
	}

	/**
	* 
	* @param products the products in stock
	*/
	public static void setProducts(ProductInStock[] products) {
		ShoppingWindowController.products = products;
	}

	/**
	* 
	* @return the facility
	*/
	public static String getFacility() {
		return facility;
	}

	/**
	* 
	* @param facility the facility
	*/
	public static void setFacility(String facility) {
		ShoppingWindowController.facility = facility;
	}

	/**
	* 
	* @return the sales
	*/
	public static List<Sale> getSales() {
		return sales;
	}

	/**
	* 
	* @param sales the sales 
	*/
	public static void setSales(List<Sale> sales) {
		ShoppingWindowController.sales = sales;
	}

	/**
	* This is an event handler method that will be triggered when the user closes the shopping window.
	* The method is empty and does not contain any logic at the moment.
	* This method can be used to add logic that should be executed when the user closes the window,
	* such as saving data or releasing resources.
	*
	* @param event an event object that contains information about the window close event
	*/
	@Override
	public void handle(WindowEvent event) {
		// TODO Auto-generated method stub

	}

	/**
	* The clickShoppingCart method is an event handler for the "Shopping Cart" button in the Shopping Window.
	* It adds all selected products to the shopping cart, along with their quantities and prices.
	* The method also calculates the total price of all the products in the shopping cart.
	* If there is a sale selected, it will apply the sale's discount to the total price.
	* @param event the action event that triggered the method
	* @throws IOException if there is an error with the input or output of the method
	*/
	@FXML
	void clickShoppingCart(ActionEvent event) throws IOException {
		double total = 0;
		ObservableList<ProductInCart> shoppingCart = FXCollections.observableArrayList();
		if (BisliAdd.getValue() > 0) {
			shoppingCart.add(new ProductInCart("Bisli", BisliAdd.getValue(), prices[0]));
			total += (BisliAdd.getValue() * prices[0]);
		}
		if (bambaAdd.getValue() > 0) {
			shoppingCart.add(new ProductInCart("Bamba", bambaAdd.getValue(), prices[1]));
			total += (bambaAdd.getValue() * prices[1]);
		}
		if (buenoAdd.getValue() > 0) {
			shoppingCart.add(new ProductInCart("Kinder Bueno", buenoAdd.getValue(), prices[2]));
			total += (buenoAdd.getValue() * prices[2]);
		}
		if (chocolateAdd.getValue() > 0) {
			shoppingCart.add(new ProductInCart("Chocolate", chocolateAdd.getValue(), prices[3]));
			total += (chocolateAdd.getValue() * prices[3]);
		}
		if (colaAdd.getValue() > 0) {
			shoppingCart.add(new ProductInCart("Coke", colaAdd.getValue(), prices[4]));
			total += (colaAdd.getValue() * prices[4]);
		}
		if (kifkefAdd.getValue() > 0) {
			shoppingCart.add(new ProductInCart("Kifkef", kifkefAdd.getValue(), prices[5]));
			total += (kifkefAdd.getValue() * prices[5]);
		}
		if (mnmAdd.getValue() > 0) {
			shoppingCart.add(new ProductInCart("M&M", mnmAdd.getValue(), prices[6]));
			total += (mnmAdd.getValue() * prices[6]);
		}
		if (snydersAdd.getValue() > 0) {
			shoppingCart.add(new ProductInCart("Snyders", snydersAdd.getValue(), prices[7]));
			total += (snydersAdd.getValue() * prices[7]);
		}
		if (spriteAdd.getValue() > 0) {
			shoppingCart.add(new ProductInCart("Sprite", spriteAdd.getValue(), prices[8]));
			total += (spriteAdd.getValue() * prices[8]);
		}
		if (teaAdd.getValue() > 0) {
			shoppingCart.add(new ProductInCart("fuzeTea", teaAdd.getValue(), prices[9]));
			total += (teaAdd.getValue() * prices[9]);
		}
		if (teamiAdd.getValue() > 0) {
			shoppingCart.add(new ProductInCart("Teami", teamiAdd.getValue(), prices[10]));
			total += (teamiAdd.getValue() * prices[10]);
		}
		if (waterAdd.getValue() > 0) {
			shoppingCart.add(new ProductInCart("Water", waterAdd.getValue(), prices[11]));
			total += (waterAdd.getValue() * prices[11]);
		}
		
		if(saleCombobox.getValue() == null)
		{
			int i=0;
			total=0.0;
			for(ProductInCart product:shoppingCart)
			{		
				product.setPrice(originalPrices[i]);
				product.setTotalPrice(originalPrices[i]*product.getAmount());
				i++;
				total+=product.getTotalPrice();
			}
		}

		else if (saleCombobox.getValue() != null && (saleCombobox.getValue().equals("1+1 for all products"))) {
			for (int i = 0; i < 12; i++) {
				changePriceInIndex(i, originalPrices[i]);
			}
			Collections.sort(shoppingCart);
			int totalAmount = 0;
			double amountOfProductsToPay;
			total = 0.0;
			for (ProductInCart product : shoppingCart) {
				totalAmount += product.getAmount();
			}
			amountOfProductsToPay = (double) (totalAmount % 2 + Math.floor(totalAmount / 2));
			for (int i = 0; amountOfProductsToPay > 0; i++) {
				if (shoppingCart.get(i).getAmount() < amountOfProductsToPay) {
					total += shoppingCart.get(i).getAmount() * shoppingCart.get(i).getPrice();
				} else {
					total += amountOfProductsToPay * shoppingCart.get(i).getPrice();
				}
				amountOfProductsToPay -= shoppingCart.get(i).getAmount();
			}
		}

		else if (saleCombobox.getValue() != null && saleCombobox.getValue().equals("2+1 for all products")) {
			for (int i = 0; i < 12; i++) {
				changePriceInIndex(i, originalPrices[i]);
			}
			Collections.sort(shoppingCart);
			int totalAmount = 0;
			double amountOfProductsToPay;
			total = 0.0;
			for (ProductInCart product : shoppingCart) {
				totalAmount += product.getAmount();
			}
			if (totalAmount % 3 == 0)
				amountOfProductsToPay = (double) (2 * Math.floor(totalAmount / 3));
			else if (totalAmount % 3 == 1)
				amountOfProductsToPay = (double) (2 * Math.floor(totalAmount / 3) + 1);
			else
				amountOfProductsToPay = (double) (2 * Math.floor(totalAmount / 3) + 2);
			for (int i = 0; amountOfProductsToPay > 0; i++) {
				if (shoppingCart.get(i).getAmount() < amountOfProductsToPay) {
					total += shoppingCart.get(i).getAmount() * shoppingCart.get(i).getPrice();
				} else {
					total += amountOfProductsToPay * shoppingCart.get(i).getPrice();
				}
				amountOfProductsToPay -= shoppingCart.get(i).getAmount();
			}
		}
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		ShoppingCartController cartScreen = new ShoppingCartController();
		ShoppingCartController.setShoppingCart(shoppingCart);

		ShoppingCartController.setTotal(total);
		cartScreen.start(primaryStage);
	}

	/**
	* This method changes the price of a product in the prices array at a specific index
	* @param i - the index of the product in the prices array
	* @param price - the new price of the product
	*/
	private void changePriceInIndex(int i, double price) {
		prices[i] = price;
	}

	/**
	* This method handles the refreshSale event when the user selects an option from the saleCombobox.
	* @param event the ActionEvent that triggered the method
	*/
	@FXML
	void refreshSale(ActionEvent event) {

		if (saleCombobox.getValue().equals("Get 20% discount for all products (first purchase)")) {
			for (int i = 0; i < 12; i++) {
				changePriceInIndex(i, originalPrices[i] * 0.8);
			}
		} else if (saleCombobox.getValue()==null||saleCombobox.getValue().equals("No sale,thanks!")
				|| saleCombobox.getValue().equals("1+1 for all products")
				|| saleCombobox.getValue().equals("2+1 for all products")) {
			for (int i = 0; i < 12; i++) {
				changePriceInIndex(i, originalPrices[i]);
			}
		} else {
			for (int i = 0; i < sales.size(); i++) {
				if (saleCombobox.getValue().equals(sales.get(i).getDescription())) {
					for (int j = 0; j < 12; j++) {
						changePriceInIndex(j, originalPrices[j]);
					}
					for (int j = 0; j < sales.get(i).getIndices().length; j++)
						changePriceInIndex(sales.get(i).getIndices()[j],
								(1 - sales.get(i).getDiscount()) * originalPrices[sales.get(i).getIndices()[j]]);
				}
			}
		}

		String price0 = String.format("%.02f", prices[0]);
		String price1 = String.format("%.02f", prices[1]);
		String price2 = String.format("%.02f", prices[2]);
		String price3 = String.format("%.02f", prices[3]);
		String price4 = String.format("%.02f", prices[4]);
		String price5 = String.format("%.02f", prices[5]);
		String price6 = String.format("%.02f", prices[6]);
		String price7 = String.format("%.02f", prices[7]);
		String price8 = String.format("%.02f", prices[8]);
		String price9 = String.format("%.02f", prices[9]);
		String price10 = String.format("%.02f", prices[10]);
		String price11 = String.format("%.02f", prices[11]);

		bisliPrice.setText(price0 + "NIS");
		bambaPrice.setText(price1 + "NIS");
		buenoPrice.setText(price2 + "NIS");
		chocolatePrice.setText(price3 + "NIS");
		colaPrice.setText(price4 + "NIS");
		kifkefPrice.setText(price5 + "NIS");
		mNmPrice.setText(price6 + "NIS");
		snydersPrice.setText(price7 + "NIS");
		sprytePrice.setText(price8 + "NIS");
		teaPrice.setText(price9 + "NIS");
		teamiPrice.setText(price10 + "NIS");
		waterPrice.setText(price11 +"NIS");
	}

}