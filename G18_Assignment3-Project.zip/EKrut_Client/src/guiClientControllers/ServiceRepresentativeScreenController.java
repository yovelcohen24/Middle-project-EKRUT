
package guiClientControllers;

import java.io.IOException;

import client.ClientMissionHandler;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
* The ServiceRepresentativeScreenController class is the controller for the service representative screen.
* It handles the events and updates the user interface elements on the screen.
*
* @author Yovel
*/
public class ServiceRepresentativeScreenController implements EventHandler<WindowEvent> {
	  // Static variables to store the user's information
	private static String username;
	private static String firstName;
	private static String phone;
	private static String facility;
	 // ImageViews for the OLpic and EKpic
	@FXML
    private ImageView OLpic;

    @FXML
    private ImageView EKpic;

    @FXML
    private Label configLbl;
	@FXML
	public Label hello;

	@FXML
	private TextArea userLog;

	@FXML
	private Button AddingCustomer;

	@FXML
	private Button CustomerIntoSubscriber;

	@FXML
	private Button logOut;

    /**
    * The setFirstName method is used to set the first name of the subscriber.
    *
    * @param firstName The first name of the subscriber
    */
	public static void setFirstName(String firstName) {
		ServiceRepresentativeScreenController.firstName = firstName;
	}

    /**
    * The setPhone method is used to set the phone number of the subscriber.
    *
    * @param phone The phone number of the subscriber
    */
	public static void setPhone(String phone) {
		ServiceRepresentativeScreenController.phone = phone;
	}

	/**
	* The initialize method is called by the JavaFX framework when the associated FXML file is loaded.
	* It is used to set up the initial state of the user interface elements.
	* 
	* 
	*/
	@FXML
	public void initialize() {

		hello.setText("Welcome, " + firstName);
		userLog.setText("Phone number: " + phone + "\n" + "Account type: " + "service representative");
		if (facility.equals("WAREHOUSE")) {
			configLbl.setText("OL");
			OLpic.setVisible(true);
			EKpic.setVisible(false);
			AddingCustomer.setDisable(false);
			CustomerIntoSubscriber.setDisable(false);
		}
		else {
			configLbl.setText("EK");
			OLpic.setVisible(false);
			EKpic.setVisible(true);
			AddingCustomer.setDisable(true);
			CustomerIntoSubscriber.setDisable(true);
		}

	}

	/**
	* The start method is used to display the service representative screen.
	*
	* @param primaryStage the stage on which the scene will be set
	* @throws IOException if an error occurs while loading the FXML file
	*/
	public void start(Stage primaryStage) throws IOException {

		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/ServiceRepresentativeScreen.fxml"));
		primaryStage.getIcons().add(
				new Image(ServiceRepresentativeScreenController.class.getResourceAsStream("/pictures/ekrutIcon.png")));

		Scene scene = new Scene(root);

		primaryStage.setTitle("E-Krut Service Representative page");

		primaryStage.setScene(scene);

		primaryStage.show();
		primaryStage.setResizable(false);
		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.closeWindow(ServiceRepresentativeScreenController.getUsername());
		});
	}

	/**
	* This method is used for adding a customer when the "Add Customer" button is clicked.
	* It hides the current window and opens the new window for adding a customer.
	*
	* @param event the event that triggers this method, usually the "Add Customer" button click
	* @throws IOException if there is an error loading the new window for adding a customer
	*/
	@FXML
	void AddingCustomer(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		ServiceRepresentativeAddController add = new ServiceRepresentativeAddController();
		add.start(primaryStage);
	}

	/**
	* This method is used for converting a customer into a subscriber when the "Convert to Subscriber" button is clicked.
	* It hides the current window and opens the new window for converting a customer into a subscriber.
	*
	* @param event the event that triggers this method, usually the "Convert to Subscriber" button click
	* @throws IOException if there is an error loading the new window for converting a customer into a subscriber
	*/
	@FXML
	void CustomerIntoSubscriber(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		ServiceRepresentativeaddingfromClientTosubscriberController screen = new ServiceRepresentativeaddingfromClientTosubscriberController();
		screen.start(primaryStage);
	}

	/**
	* This method is used for logging out of the application when the "Log Out" button is clicked.
	* It hides the current window and opens the new window for logging in.
	* it also call logOut method from ClientMissionHandler class and passing the current username
	*
	* @param event the event that triggers this method, usually the "Log Out" button click
	* @throws IOException if there is an error loading the new window for logging in
	*/
	@FXML
	void logOut(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		ClientLoginScreenController subController = new ClientLoginScreenController();
		subController.start(primaryStage);
		ClientMissionHandler.logOut(username);
	}

	/**
	* Returns the current username.
	* @return the current username
	*/
	public static String getUsername() {
		return username;
	}

	/**
	* Sets the current username.
	* @param username the new username to set
	*/
	public static void setUsername(String username) {
		ServiceRepresentativeScreenController.username = username;
	}

	/**
	    * Handle the window event
	    * @param arg0 
	    */
	@Override
	public void handle(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}
	
	/**
	    * Return current Facility
	    * @return current Facility
	    */
	public static String getFacility() {
		return facility;
	}


	/**
    * sets the current Facility
    * @param facility the Facility to set
    */
	public static void setFacility(String facility) {
		ServiceRepresentativeScreenController.facility = facility;
	}

}
