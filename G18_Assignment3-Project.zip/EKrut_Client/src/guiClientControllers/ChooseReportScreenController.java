package guiClientControllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import client.ClientMissionHandler;
import common_class.Util;
import common_enums.Region;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * The class ChooseReportScreenController is an implementation of the EventHandler interface for the purpose of handling events related to the report generation screen.
 * This class is responsible for the report generation screen in the application, where the user can choose different report types, months and years, and facilities.
 * The class contains the following fields:
 *  - role: static field that holds the role of the user.
 *  - region: static field that holds the region of the user.
 * The class contains the following methods:
 *  - getRegion(): static method that returns the region of the user.
 *  - setRegion(String region): static method that sets the region of the user.
 *  - getRole(): static method that returns the role of the user.
 *  - setRole(String role): static method that sets the role of the user.
 *  - clickOnResetBtn(MouseEvent event): method that handles the event of clicking on the reset button.
 *  - clickOnChooseFacilityBtn(MouseEvent event): method that handles the event of clicking on the choose facility button.
 *  - clickOnBackBtn(MouseEvent event): method that handles the event of clicking on the back button.
 *  - clickOnViewReport(MouseEvent event): method that handles the event of clicking on the view report button.
 * 
 * @author Eyal
 *
 */
public class ChooseReportScreenController implements EventHandler<WindowEvent> {
    private static String role;
    private static String region;
    
    /**
     * Returns the region of the user.
     * @return the region of the user
     */
    public static String getRegion() {
        return region;
    }
    
    /**
     * Sets the region of the user.
     * @param region the region of the user
     */
    public static void setRegion(String region) {
        ChooseReportScreenController.region = region;
    }
    
    /**
     * Returns the role of the user.
     * @return the role of the user
     */
    public static String getRole() {
        return role;
    }
    
    /**
     * Sets the role of the user.
     * @param role the role of the user
     */
    public static void setRole(String role) {
        ChooseReportScreenController.role = role;
    }
    /**
     * @author Eyal
     * This class is the controller of the report screen.
     * It contains FXML elements and methods for selecting and viewing reports.
     * 
     * @FXML private ComboBox<String> pickRegionComboBox;
     * The combo box for selecting a region to view reports for.
     * 
     * @FXML private Label selectFacilityLabel;
     * The label for the facility selection element.
     * 
     * @FXML private Label selectMonthLabel;
     * The label for the month selection element.
     * 
     * @FXML private Label selectYearLabel;
     * The label for the year selection element.
     * 
     * @FXML private Button backBtn;
     * The button for returning to the previous screen.
     * 
     * @FXML private Label errorLabel;
     * The label for displaying error messages.
     * 
     * @FXML private ImageView resetBtn;
     * The button for resetting the report selection.
     * 
     * @FXML private ComboBox<String> pickFacilityComboBox;
     * The combo box for selecting a facility to view reports for.
     * 
     * @FXML private ComboBox<String> pickMonthComboBox;
     * The combo box for selecting a month to view reports for.
     * 
     * @FXML private ComboBox<String> pickReportTypeComboBox;
     * The combo box for selecting the type of report to view.
     * 
     * @FXML private ComboBox<String> pickYearComboBox;
     * The combo box for selecting a year to view reports for.
     * 
     * @FXML private Button viewBtn;
     * The button for viewing the selected report.
     * 
     * @FXML private Button chooseFacilityBtn;
     * The button for choosing a facility to view reports for.
     * 
     * @FXML void clickOnResetBtn(MouseEvent event)
     * Method for handling the reset button being clicked.
     * 
     * @FXML void clickOnChooseFacilityBtn(MouseEvent event)
     * Method for handling the choose facility button being clicked.
     * 
     * @FXML void clickOnBackBtn(MouseEvent event)
     * Method for handling the back button being clicked.
     * 
     * @FXML void clickOnViewReport(MouseEvent event)
     * Method for handling the view report button being clicked.
     */
	@FXML
	private ComboBox<String> pickRegionComboBox;

	@FXML
	private Label selectFacilityLabel;

	@FXML
	private Label selectMonthLabel;

	@FXML
	private Label selectYearLabel;

	@FXML
	private Button backBtn;

	@FXML
	private Label errorLabel;

	@FXML
	private ImageView resetBtn;

	@FXML
	private ComboBox<String> pickFacilityComboBox;

	@FXML
	private ComboBox<String> pickMonthComboBox;

	@FXML
	private ComboBox<String> pickReportTypeComboBox;

	@FXML
	private ComboBox<String> pickYearComboBox;

	@FXML
	private Button viewBtn;

	@FXML
	private Button chooseFacilityBtn;

	@FXML
	void clickOnResetBtn(MouseEvent event) {
		changeDiasbility(false);
		setVisiblePickFacilityInClient(false);
		resetBtn.setVisible(false);
	}

	@FXML
	void clickOnChooseFacilityBtn(MouseEvent event) {
		ArrayList<String> stockReportDetails = new ArrayList<String>(Arrays.asList(pickMonthComboBox.getValue(),
				pickYearComboBox.getValue(), pickFacilityComboBox.getValue()));
		ClientMissionHandler.GET_STOCK_REPORT(event, errorLabel, stockReportDetails);
	}

	@FXML
	void clickOnBackBtn(MouseEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		if (role.equals("CEO")) {
			MainCEOController ceoScreen = new MainCEOController();
			ceoScreen.start(primaryStage);
		} else {
			MainScreenManagerController mainManagerScreen = new MainScreenManagerController();
			mainManagerScreen.start(primaryStage);
		}
	}

	@FXML
	void clickOnViewReport(MouseEvent event) {
		errorLabel.setVisible(false);
		if (pickMonthComboBox.getValue() == null || pickYearComboBox.getValue() == null) {
			errorLabel.setVisible(true);
			errorLabel.setText("Inorder to view report you must choose YEAR, MONTH");
		} else if (pickReportTypeComboBox.getValue() == null) {
			errorLabel.setVisible(true);
			errorLabel.setText("You MUST choose a type of report!");
		} else {
			switch (pickReportTypeComboBox.getValue()) {
			case "Orders reports": {
				resetBtn.setVisible(false);
				if (role.equals("CEO")) {
					ArrayList<String> orderReportDetails = new ArrayList<String>(Arrays.asList(
							pickMonthComboBox.getValue(), pickYearComboBox.getValue(), pickRegionComboBox.getValue()));
					ClientMissionHandler.GET_ORDERS_REPORT(event, errorLabel, orderReportDetails);
				} else {
					ArrayList<String> orderReportDetails = new ArrayList<String>(
							Arrays.asList(pickMonthComboBox.getValue(), pickYearComboBox.getValue(), region));
					ClientMissionHandler.GET_ORDERS_REPORT(event, errorLabel, orderReportDetails);
				}
				break;
			}
			case "Stock reports": {
				changeDiasbility(true);
				resetBtn.setVisible(true);
				if (role.equals("CEO")) {
					setVisiblePickFacilityInClient(true);
					pickFacilityComboBox.getItems().clear();
					pickFacilityComboBox.getItems()
							.addAll(Util.getFacilitiesInTheRegion(Region.valueOf(pickRegionComboBox.getValue())));
					pickFacilityComboBox.setPromptText("Facility");
				} else {
					setVisiblePickFacilityInClient(true);
					pickFacilityComboBox.getItems().clear();
					pickFacilityComboBox.getItems().addAll(Util.getFacilitiesInTheRegion(Region.valueOf(region)));
					pickFacilityComboBox.setPromptText("Facility");
				}
				break;
			}
			case "Customer reports":
				resetBtn.setVisible(false);
				if (role.equals("CEO")) {
					ArrayList<String> customerReportDetails = new ArrayList<String>(Arrays.asList(
							pickMonthComboBox.getValue(), pickYearComboBox.getValue(), pickRegionComboBox.getValue()));
					ClientMissionHandler.GET_CUSTOMER_REPORT(event, errorLabel, customerReportDetails);
				} else {
					ArrayList<String> customerReportDetails = new ArrayList<String>(
							Arrays.asList(pickMonthComboBox.getValue(), pickYearComboBox.getValue(), region));
					ClientMissionHandler.GET_CUSTOMER_REPORT(event, errorLabel, customerReportDetails);
				}
				break;
			}
		}
	}

	/**
	 * 
	 * @author Eyal
	 * 
	 * This class is responsible for initializing and handling the Choose Report Screen.
	 * The class contains several methods, including:
	 * 
	 *  initialize()
	 * This method is used to initialize the ComboBoxes on the Choose Report Screen, 
	 * populate them with data, and set the visibility of certain elements depending on the user's role. 
	 * The ComboBoxes include: pickMonthComboBox, pickYearComboBox, pickReportTypeComboBox, and pickRegionComboBox.
	 * The visibility of pickFacilityComboBox, selectFacilityLabel, and chooseFacilityBtn can also be set using this method.
	 * 
	 *  setVisiblePickFacilityInClient(boolean value)
	 * This method sets the visibility of pickFacilityComboBox, selectFacilityLabel, and chooseFacilityBtn. 
	 * The value passed in the parameter determines whether the elements will be visible or not.
	 * 
	 *  start(Stage primaryStage)
	 * This method is used to start the Choose Report Screen. It loads the FXML file and 
	 * sets the scene and title of the primary stage. The method also sets the primary stage to be non-resizable and 
	 * adds an event handler for when the window is closed.
	 * 
	 *  handle(WindowEvent event)
	 * This method is an event handler for when the window is closed. It is currently empty.
	 * 
	 *  changeDiasbility(boolean value)
	 * This method is used to change the disable property of certain elements 
	 * on the Choose Report Screen. The elements that can be disabled include: pickMonthComboBox, pickYearComboBox, 
	 * pickReportTypeComboBox, and pickRegionComboBox.
	 * 
	 */

	public void initialize() {
		resetBtn.setVisible(false);
		ArrayList<String> months = new ArrayList<String>(
				Arrays.asList("01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"));
		pickMonthComboBox.getItems().addAll(months);
		ArrayList<String> years = new ArrayList<String>(Arrays.asList("2018", "2019", "2020", "2021", "2022","2023"));
		pickYearComboBox.getItems().addAll(years);
		ArrayList<String> reportsType = new ArrayList<String>(
				Arrays.asList("Orders reports", "Stock reports", "Customer reports"));
		pickReportTypeComboBox.getItems().addAll(reportsType);
		if (role.equals("CEO")) {
			pickRegionComboBox.setDisable(false);
			ArrayList<String> regions = new ArrayList<String>(Arrays.asList("NORTH", "SOUTH", "UAE"));
			pickRegionComboBox.getItems().addAll(regions);
		} else {
			pickRegionComboBox.setDisable(true);
			pickRegionComboBox.setPromptText(region);
		}
		errorLabel.setVisible(false);
		setVisiblePickFacilityInClient(false);

	}

	private void setVisiblePickFacilityInClient(boolean value) {
		pickFacilityComboBox.setVisible(value);
		selectFacilityLabel.setVisible(value);
		chooseFacilityBtn.setVisible(value);
	}

	public void start(Stage primaryStage) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/ChooseReportScreen.fxml"));
		primaryStage.getIcons()
				.add(new Image(ChooseReportScreenController.class.getResourceAsStream("/pictures/ekrutIcon.png")));
		Scene scene = new Scene(root);
		primaryStage.setTitle("E-Krut Reprts");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);
		primaryStage.setOnCloseRequest(e -> {
			if (role.equals("CEO")) {
				ClientMissionHandler.closeWindow(MainCEOController.getUserName());
			} else {
				ClientMissionHandler.closeWindow(MainScreenManagerController.getUsername());
				MainScreenManagerController.isAppearPopUpMsg = false;
			}
		});
	}

	@Override
	public void handle(WindowEvent event) {
		// TODO Auto-generated method stub
	}

	private void changeDiasbility(boolean value) {
		pickMonthComboBox.setDisable(value);
		pickYearComboBox.setDisable(value);
		pickReportTypeComboBox.setDisable(value);
		if (role.equals("CEO"))
			pickRegionComboBox.setDisable(value);
	}
}
