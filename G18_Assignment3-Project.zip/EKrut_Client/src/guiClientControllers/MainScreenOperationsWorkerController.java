package guiClientControllers;

import java.io.IOException;

import client.ClientMissionHandler;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * 
 * 
 * This class is the controller class for the Main Screen of the Operations Worker.
 * It is responsible for handling the events and operations related to the Main Screen,
 * such as the initialization of the screen, the event handling of the buttons, and storing the user's information.
 * 
 * @author Eyal
 */
public class MainScreenOperationsWorkerController implements EventHandler<WindowEvent> {
	 // Static variables to store the user's information
	private static String username;
	private static String phone;
	private static String email;
	private static String facility;

	  // Getters and Setters for the user's information
	public static String getFacility() {
		return facility;
	}

	public static void setFacility(String facility) {
		MainScreenOperationsWorkerController.facility = facility;
	}

	 // Variables for the GUI elements
    @FXML
    private Label configLbl;

    @FXML
    private ImageView EKpic;

    @FXML
    private ImageView OLpic;
	
	@FXML
	private TextArea consoleUser;

	@FXML
	private Button logoutButton;

	@FXML
	private Button updateInventoryBtn;

	@FXML
	private Label welcomeLabel;

	  // Getters and Setters for the user's information
	public static String getUsername() {
		return username;
	}

	public static void setUsername(String username) {
		MainScreenOperationsWorkerController.username = username;
	}

	public static String getPhone() {
		return phone;
	}

	public static void setPhone(String phone) {
		MainScreenOperationsWorkerController.phone = phone;
	}

	public static String getEmail() {
		return email;
	}

	public static void setEmail(String email) {
		MainScreenOperationsWorkerController.email = email;
	}

	/**
	* @author Eyal
	* 
	* This class handles the event of clicking the "Logout" button for the Main Screen for the Operations Worker.
	* It hides the current window, opens a new stage for the ClientLoginScreenController,
	* and logs out the user by calling the logOut method of the ClientMissionHandler class.
	*/
	@FXML
	void clickLogout(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		ClientLoginScreenController subController = new ClientLoginScreenController();
		subController.start(primaryStage);
		ClientMissionHandler.logOut(username);
	}

	/**
	* @author Eyal
	* 
	* This class handles the event of clicking the "Update Inventory" button for the Main Screen for the Operations Worker.
	* It hides the current window and opens a new stage for the UpdateInventoryController.
	*/
	@FXML
	void clickUpdateInventoryBtn(MouseEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		UpdateInventoryController updateInventoryController = new UpdateInventoryController();
		updateInventoryController.start(primaryStage);
	}

	/**
	* @author Eyal
	* 
	* This class is responsible for starting and displaying the Main Screen for the Operations Worker.
	* It loads the FXML file for the Main Screen, sets the icon, title, and scene for the stage,
	* and sets the stage to be non-resizable. It also sets the event handler for the close request of the stage
	* to call the closeWindow method of the ClientMissionHandler class and passing the current user's username as a parameter.
	*/
	public void start(Stage primaryStage) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/MainScreenOperationsWorker.fxml"));
		primaryStage.getIcons()
				.add(new Image(MainScreenManagerController.class.getResourceAsStream("/pictures/ekrutIcon.png")));
		Scene scene = new Scene(root);
		primaryStage.setTitle("E-Krut Main Operations Worker Screen");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);
		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.closeWindow(MainScreenOperationsWorkerController.getUsername());
		});
	}

	/**
	* @author Eyal
	* 
	* This class is responsible for handling the close request of the window for the Main Screen for the Operations Worker.
	*/
	@Override
	public void handle(WindowEvent event) {
		// TODO Auto-generated method stub
	}

	/**
	* @author Eyal
	* 
	* This class is responsible for initializing the Main Screen for the Operations Worker.
	* It sets the text for the configLbl, sets the visibility of the OLpic and EKpic, and disables the updateInventoryBtn
	* if the facility is a warehouse. It also sets the text for the welcomeLabel and consoleUser.
	*/
	@FXML
	public void initialize() throws IOException {
		if (facility.equals("WAREHOUSE")) {
			configLbl.setText("OL");
			OLpic.setVisible(true);
			EKpic.setVisible(false);
			updateInventoryBtn.setDisable(true);
		}
		else {
			configLbl.setText("EK");
			OLpic.setVisible(false);
			EKpic.setVisible(true);
		}
		welcomeLabel.setText("Welcome, " + MainScreenOperationsWorkerController.getUsername());
		consoleUser.setText("Username: " + username + "\nPhone number: " + phone + "\n"
				+ "Confirmed as Operations Worker\nFacility: " + facility);
	}

}
