package guiClientControllers;

import java.io.IOException;
import java.util.ArrayList;

import client.ClientMissionHandler;
import common_class.Util;
import common_enums.Response;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * 
 * 
 * 
 * This class is the controller of the EditThresholdLevelScreen.fxml. It handles the events of the buttons, 
 * ComboBox, TextField, and the labels in the Edit Threshold Level screen. It allows the manager to update 
 * the threshold level of a specific facility in the region.
 * 
 * @author Dina
 */
public class EditThresholdLevelController implements EventHandler<WindowEvent> {

	/**
	 * The update button that the manager clicks on to submit the new threshold level.
	 */
	@FXML
	private Button UpdateBtn;

	/**
	 * The back button that the manager clicks on to return to the main manager screen.
	 */
	@FXML
	private Button backBtn;

	/**
	 * The ComboBox that the manager uses to choose the facility that they want to update the threshold level for.
	 */
	@FXML
	private ComboBox<String> chooseFacility;

	/**
	 * The error label that displays any error messages.
	 */
	@FXML
	private Label errorLbl;

	/**
	 * The label that displays the current threshold level of the chosen facility.
	 */	
	@FXML
	private Label treshholdLabl;

	/**
	 * The label that displays the current threshold level of the chosen facility.
	 */
	@FXML
	private Button selectBtn;
	
	/**
	 * The error label that displays any error messages.
	 */
	@FXML
	private Label errorLbl2;
	
	/**
	 * The text field that the manager enters the new threshold level in.
	 */
	@FXML
	private TextField text;
	
	/**
	 * The current threshold level of the chosen facility.
	 */
	public static int treshold;
	
	/**
	 * The response from the server.
	 */
	public static Response res;

	/**
	 * This method is called when the back button is clicked. It hides the current screen and opens the main manager screen.
	 * @param event - the event of clicking the back button.
	 * @throws IOException
	 */
	@FXML
	void clickOnBackBtn(MouseEvent event) throws IOException {
		ClientMissionHandler.CHECK_TRASH_HOLD(MainScreenManagerController.getRegion().toString(), null, true);
		((Node) event.getSource()).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		MainScreenManagerController mainManagerScreen = new MainScreenManagerController();
		mainManagerScreen.start(primaryStage);
	}

	/**
	 * This method is called when the update button is clicked. It updates the threshold level of the chosen facility with the entered value.
	 * @param event - the event of clicking the update button.
	 */
	@FXML
	void clickOnUpdateProductsBtn(MouseEvent event) {
		try {
			int number = Integer.parseInt(text.getText());
			ArrayList<String> data = new ArrayList<>();
			data.add(chooseFacility.getValue());
			data.add(String.valueOf(number));
			ClientMissionHandler.updateAValueTreshold(data);
			if (res.equals(Response.UPDATE_MINIMUM_THRESHOLD_INVENTORY_VALUE_SUCCESS)) {
				errorLbl.setVisible(true);
				errorLbl.setTextFill(Color.GREEN);
				errorLbl.setText("SUCCESS");
			}
		} catch (NumberFormatException e) {
			errorLbl.setVisible(true);
			errorLbl.setTextFill(Color.RED);
			errorLbl.setText("Please enter a number!");
		}

	}

	/**
	* @author Dina
	* The initialize() method is used to set the initial visibility of certain elements and populate the chooseFacility ComboBox with the facilities in the region.
	* 
	* @throws IOException if an I/O error occurs while retrieving the facilities.
	*/
	@FXML
	public void initialize() throws IOException {
		errorLbl.setVisible(false);
		errorLbl2.setVisible(false);
		treshholdLabl.setVisible(false);
		UpdateBtn.setVisible(false);
		text.setVisible(false);
		chooseFacility.getItems().addAll(Util.getFacilitiesInTheRegion(MainScreenManagerController.getRegion()));
	}

	/**
	* @author Dina
	* The start() method is used to set up the EditThresholdLevelScreen GUI and display it to the user.
	* It loads the EditThresholdLevelScreen.fxml file, sets the stage's title and icon, creates a new Scene with the root node, sets the scene on the stage, sets the stage to not be resizable,
	* and adds an event handler for the close request to close the connection with the server.
	*
	* @param primaryStage the stage on which the scene is set
	* @throws IOException if an I/O error occurs while loading the fxml file
	*/
	public void start(Stage primaryStage) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/EditThresholdLevelScreen.fxml"));
		primaryStage.getIcons()
				.add(new Image(MainScreenManagerController.class.getResourceAsStream("/pictures/ekrutIcon.png")));
		Scene scene = new Scene(root);
		primaryStage.setTitle("E-Krut Edit Threshold Level Screen");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);
		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.closeWindow(MainScreenManagerController.getUsername());
		});
	}

	/**
	* @author Dina
	* The handle method is used to handle the close request event on the primary stage
	* 
	* @param event the WindowEvent to handle
	*/
	@Override
	public void handle(WindowEvent event) {

	}

	/**
	* @author Dina
	* The clickOnSelectBtn() method is used to handle the event of clicking on the Select button.
	* It checks if a facility has been selected, and if not, displays an error message. If a facility has been selected, it calls the ClientMissionHandler.checkAValueTreshold() method
	* with the selected facility, makes the treshholdLabl, UpdateBtn and text visible, and sets the text of the text field to the current treshold value.
	*
	* @param event the MouseEvent of clicking on the Select button
	*/
	@FXML
	void clickOnSelectBtn(MouseEvent event) {
		if (chooseFacility.getValue() == null) {
			errorLbl2.setText("Plese choose a facility");
			errorLbl2.setVisible(true);
		} else {
			errorLbl2.setVisible(false);
			ClientMissionHandler.checkAValueTreshold(chooseFacility.getValue());
			treshholdLabl.setVisible(true);
			UpdateBtn.setVisible(true);
			text.setVisible(true);
			text.setText("" + treshold);
		}
	}

}
