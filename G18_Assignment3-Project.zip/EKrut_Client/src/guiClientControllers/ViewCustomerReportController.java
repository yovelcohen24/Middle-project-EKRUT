package guiClientControllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import java.util.TreeMap;

import client.ClientMissionHandler;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.StackedBarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
* ViewCustomerReportController class is used for controlling the ViewCustomerReport window.
* It holds the data needed for displaying the customer report, and the methods for displaying the data on the window.
* @author Eyal
*/
public class ViewCustomerReportController {

    /**
    * The date of the customer report.
    */
	private static String Date;

    /**
    * The region of the customer report.
    */
	private static String region;

    /**
    * The information of the customer report.
    */
	private static ArrayList<Integer> information;

    /**
    * The number of cancel order of the customer report.
    */
	private static String numOfCancelOrder;

    /**
    * The best customer of the customer report.
    */
	private static String bestCustomer;

    /**
    * The best vending machine of the customer report.
    */
	private static String bestEkrut;

    /**
    * The best config of the customer report.
    */
	private static String config;

    /**
    * Get the number of cancel order of the customer report.
    * @return the number of cancel order of the customer report
    */
    public static String getNumOfCancelOrder() {
		return numOfCancelOrder;
	}

    /**
    * Set the number of cancel order of the customer report.
    * @param numOfCancelOrder the number of cancel order to be set
    */
    public static void setNumOfCancelOrder(String numOfCancelOrder) {
		ViewCustomerReportController.numOfCancelOrder = numOfCancelOrder;
	}

    /**
    * Get the best customer of the customer report.
    * @return the best customer of the customer report
    */
    public static String getBestCustomer() {
		return bestCustomer;
	}

	/**
	* Sets the best customer.
	* 
	* @param bestCustomer the new best customer
	*/
	public static void setBestCustomer(String bestCustomer) {
		ViewCustomerReportController.bestCustomer = bestCustomer;
	}

	/**
	* Returns the best ekrut.
	* 
	* @return the best ekrut
	*/
	public static String getBestEkrut() {
		return bestEkrut;
	}

	/**
	* Sets the best ekrut.
	* 
	* @param bestEkrut the new best ekrut
	*/
	public static void setBestEkrut(String bestEkrut) {
		ViewCustomerReportController.bestEkrut = bestEkrut;
	}

	/**
	* Returns the config.
	* 
	* @return the config
	*/
	public static String getConfig() {
		return config;
	}

	/**
	* Sets the config.
	* 
	* @param config the new config
	*/
	public static void setConfig(String config) {
		ViewCustomerReportController.config = config;
	}


	/**
	* Returns the information.
	* 
	* @return the information
	*/
	public static ArrayList<Integer> getInformation() {
		return information;
	}

	/**
	* Sets the information.
	* 
	* @param information the new information
	*/
	public static void setInformation(ArrayList<Integer> information) {
		ViewCustomerReportController.information = information;
	}

	/**
	* Returns the date.
	* 
	* @return the date
	*/
	public static String getDate() {
		return Date;
	}

	/**
	* Sets the date.
	* 
	* @param date the new date
	*/
	public static void setDate(String date) {
		Date = date;
	}

	/**
	* Returns the region.
	* 
	* @return the region
	*/
	public static String getRegion() {
		return region;
	}

	/**
	* Sets the region.
	* 
	* @param region the new region
	*/
	public static void setRegion(String region) {
		ViewCustomerReportController.region = region;
	}

	@FXML
	private Label bestConfig;

	@FXML
	private Label numberOfCancelOrder;

	@FXML
	private Label nameOfBestCustomer;

	@FXML
	private Label nameOfBestVendingMachine;

	@FXML
	private CategoryAxis activityLevel;

	@FXML
	private Button backBtn;

	@FXML
	private StackedBarChart<String, Integer> customerGraph;

	@FXML
	private Label infoLabel;

	@FXML
	private NumberAxis numOfClients;

	@FXML
	private Label helpLabel1;

	@FXML
	private Label helpLabel2;

	/**
    * Method called when the help button is not clicked.
    * It will set the visibility of the labels to false.
    * @param event the mouse event that triggered the method call
    */
	@FXML
	void notOnHelp(MouseEvent event) {
		setVisiableLabels(false);
	}

	/**
    * Method called when the help button is clicked.
    * It will set the visibility of the labels to true.
    * @param event the mouse event that triggered the method call
    */
	@FXML
	void onHelp(MouseEvent event) {
		setVisiableLabels(true);
	}

	/**
    * Method called when the back button is clicked.
    * It will hide the current window and open a new window for the ChooseReportScreen.
    * @param event the action event that triggered the method call
    * @throws IOException if an I/O error occurs
    */
	@FXML
	void Back(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		ChooseReportScreenController chooseReportScreen = new ChooseReportScreenController();
		chooseReportScreen.start(primaryStage);
	}

	/**
	* This class contains the start method that displays the View Customer Report Screen.
	*/
	public void start(Stage primaryStage) {
		Parent root;
		try {
			root = FXMLLoader.load(getClass().getResource("/guiClientScreens/ViewCustomerReportScreen.fxml"));
			Scene scene = new Scene(root);
			primaryStage.getIcons()
					.add(new Image(ViewCustomerReportController.class.getResourceAsStream("/pictures/ekrutIcon.png")));

			primaryStage.setTitle("E-Krut View Reports");
			primaryStage.setScene(scene);
			primaryStage.show();
			primaryStage.setResizable(false);
			primaryStage.setOnCloseRequest(e -> {
				if (ChooseReportScreenController.getRole().equals("CEO")) {
					ClientMissionHandler.closeWindow(MainCEOController.getUserName());
				} else {
					ClientMissionHandler.closeWindow(MainScreenManagerController.getUsername());
					MainScreenManagerController.isAppearPopUpMsg = false;
				}
			});
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	* This class contains the method that sets the visibility of the help labels.
	*/
	private void setVisiableLabels(boolean value) {
		helpLabel1.setVisible(value);
		helpLabel2.setVisible(value);
	}

	/**
	* This class contains the initialize method that sets the visibility of the help labels, and 
	* processes the data to display on the report screen.
	*/
	public void initialize() {
		setVisiableLabels(false);
		ArrayList<Integer> data = new ArrayList<>();
		ArrayList<Boolean> boolData = new ArrayList<>();
		for (int index = 0; index < information.size(); index++) {
			data.add(information.get(index));
			boolData.add(false);
		}
		Collections.sort(data);

		int startGraph = data.get(0); // minVal
		int maxVal = data.get(data.size() - 1);
		int delta = (int) Math.round(((double) (maxVal - startGraph) / data.size()));
		TreeMap<Integer, ArrayList<Integer>> map = new TreeMap<>();
		for (int i = 0; i < data.size(); i++) {
			map.put(startGraph + delta * i, new ArrayList<>());
			for (int index = 0; index < data.size(); index++) {
				if (i != 0) {
					if ((data.get(index) >= (startGraph + (i - 1) * delta))
							&& (data.get(index) <= (startGraph + i * delta) && !boolData.get(index))) {
						map.get(startGraph + delta * i).add(data.get(index));
						boolData.set(index, true);
					}
				} else { // (i==0)
					if ((data.get(index) <= startGraph) && !boolData.get(index)) {
						map.get(startGraph).add(data.get(index));
						boolData.set(index, true);
					}
				}
			}
		}
		int i = 0;
		maxVal = map.get(startGraph).size();
		for (Map.Entry<Integer, ArrayList<Integer>> currentSet : map.entrySet()) {
			int last = (i == 0) ? 0 : startGraph + (i - 1) * delta;
			maxVal = Math.max(maxVal, currentSet.getValue().size());
			XYChart.Series<String, Integer> serie = new XYChart.Series<>();
			serie.setName("Activity level " + (++i));
			serie.getData()
					.add(new Data<String, Integer>(last + "-" + currentSet.getKey(), currentSet.getValue().size()));
			customerGraph.getData().add(serie);
		}
		numOfClients.setAutoRanging(false);
		numOfClients.setUpperBound(maxVal + 1);
		infoLabel.setText(region + ", " + Date);
		nameOfBestVendingMachine.setText(bestEkrut);
		nameOfBestCustomer.setText(bestCustomer);
		numberOfCancelOrder.setText(numOfCancelOrder);
		bestConfig.setText(config);

	}

}