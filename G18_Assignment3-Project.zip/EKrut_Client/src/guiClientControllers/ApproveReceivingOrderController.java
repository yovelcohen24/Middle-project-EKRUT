package guiClientControllers;

import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Callback;

import java.io.IOException;

import client.ClientMissionHandler;
import common_entities.DeliveryInfo;
import entities.TimeMeasurementThread;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

/**
 * 
 * The ApproveReceivingOrderController class is responsible for handling events in the approve receiving order screen.
 * The class contains several private fields such as TableColumns, Buttons, a TableView and a Label.
 * The class also contains several FXML methods that handle the events of the buttons and the refresh of the TableView.
 * The initialize method is responsible for initializing the TableView, setting it to be uneditable, and setting the cell value factories for each column.
 * The start method is responsible for loading the FXML file and setting the scene for the primary stage.
 * 
 * @author Eyal
 * The handle method is not used in this class and is left blank.
 */
public class ApproveReceivingOrderController implements EventHandler<WindowEvent>{

		ObservableList<DeliveryInfo> dataToTable = FXCollections.observableArrayList();
	
	   @FXML
	    private TableColumn<DeliveryInfo, String> addressCol;

	    @FXML
	    private Button approve;

	    @FXML
	    private Button backBtn;

	    @FXML
	    private TableView<DeliveryInfo> deliveryTable;

	    @FXML
	    private TableColumn<DeliveryInfo, String> emailCol;

	    @FXML
	    private Label errorLbl;

	    @FXML
	    private TableColumn<DeliveryInfo, String> numberOfDeliveryCol;

	    @FXML
	    private TableColumn<DeliveryInfo, String> phoneCol;
	    
	    /**
	    * The Back method is used to handle the event of the back button, it hides the current window and opens the MainCustomerPage.
	    * 
	    * @param event - the event of the button click
	    * @throws IOException - if the FXML file cannot be loaded
	    */
	    @FXML
	    void Back(ActionEvent event) throws IOException {
			((Node) event.getSource()).getScene().getWindow().hide();
			final Stage primaryStage = new Stage();
			MainCustomerPageController main = new MainCustomerPageController();
			main.start(primaryStage);
	    }
	    
	    /**
	    * The clickOnApprove method is used to handle the event of the approve button, it approves the selected delivery and refreshes the TableView.
	    * 
	    * @param event - the event of the button click
	    * @throws IOException - if the FXML file cannot be loaded
	    */
	    @FXML
	    void clickOnApprove(MouseEvent event) throws IOException {
			DeliveryInfo selectedDelivery = deliveryTable.getSelectionModel().getSelectedItem();
			if (selectedDelivery != null) {
				ClientMissionHandler.approveDeliveryFromClientSide(selectedDelivery, errorLbl);
				ClientMissionHandler.refreshDeliveryApproval(MainCustomerPageController.getUsername(), dataToTable, errorLbl);

			} else {
				errorLbl.setTextFill(Color.RED);
				errorLbl.setText("You must choose a delivery to approve!");
			}
	    }
	    
	    /**
	    * The clickOnRefresh method is used to handle the event of the refresh button, it refreshes the TableView.
	    * 
	    * @param event - the event of the button click
	    */
	    @FXML
	    void clickOnRefresh(MouseEvent event) {
	    	ClientMissionHandler.refreshDeliveryApproval(MainCustomerPageController.getUsername(), dataToTable, errorLbl);
	    }
	    
	    /**
	    * The initialize method is used to initialize the TableView and set the cell value factories for each column.
	    * It also sets the TableView to be uneditable and sets the items of the TableView to be the dataToTable list.
	    * Additionally, it calls the refreshDeliveryApproval method to fill the TableView with data.
	    */
		public void initialize() {

			deliveryTable.setEditable(false);
			deliveryTable.autosize();
			numberOfDeliveryCol
					.setCellValueFactory((Callback) new PropertyValueFactory<DeliveryInfo, String>("numberOfDelivery"));
			phoneCol.setCellValueFactory((Callback) new PropertyValueFactory<DeliveryInfo, String>("PhoneNumber"));
			emailCol.setCellValueFactory((Callback) new PropertyValueFactory<DeliveryInfo, String>("email"));
			addressCol.setCellValueFactory((Callback) new PropertyValueFactory<DeliveryInfo, String>("Address"));
			deliveryTable.setItems(dataToTable);
			ClientMissionHandler.refreshDeliveryApproval(MainCustomerPageController.getUsername(), dataToTable, errorLbl);

		}
    
		/**
	    * The start method is used to load the FXML file and set the scene for the primary stage.
	    * It also sets the title of the stage and disables resizing.
	    * Additionally, it sets the onCloseRequest event to call the closeWindow method when the stage is closed.
	    * 
	    * @param primaryStage - the main stage of the scene
	    * @throws IOException - if the FXML file cannot be loaded
	    */
		public void start(Stage primaryStage) throws IOException {

			Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/approveGettingOrder.fxml"));
			primaryStage.getIcons().add(new Image(
					OperatesDeliveriesManApproveScreenController.class.getResourceAsStream("/pictures/ekrutIcon.png")));
			Scene scene = new Scene(root);
			primaryStage.setTitle("E-Krut Approve Receiving Order");
			primaryStage.setScene(scene);
			primaryStage.show();
			primaryStage.setResizable(false);
			primaryStage.setOnCloseRequest(e-> {
				ClientMissionHandler.closeWindow(MainCustomerPageController.getUsername());
			});
			TimeMeasurementThread.stop=true;
		}

		/**
	    * The handle method is not used in this class and is left blank.
	    * 
	    * @param event - the window event that is being handled
	    */
		@Override
		public void handle(WindowEvent event) {
			// TODO Auto-generated method stub
			
		}
}

