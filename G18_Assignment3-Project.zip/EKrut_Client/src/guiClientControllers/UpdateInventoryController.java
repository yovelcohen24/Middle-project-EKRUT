package guiClientControllers;

import java.io.IOException;
import java.util.ArrayList;

import client.ClientMissionHandler;
import common_class.Util;
import common_entities.ProductInStock;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Callback;

/**
 * 
 * 
 * 
 * UpdateInventoryController class handles the update inventory feature of the
 * application. It implements the EventHandler interface for handling window
 * events. The class has several fields for storing data to be displayed in the
 * table, as well as fields for storing manager's email and phone number. It
 * also contains several methods for getting and setting the manager's email and
 * phone number, and methods annotated with @FXML for handling button clicks and
 * updating the table.
 * 
 * @author Yovel
 */
public class UpdateInventoryController implements EventHandler<WindowEvent> {
	ObservableList<ProductInStock> dataToTable = FXCollections.observableArrayList();
	ArrayList<ProductInStock> popUpArr = new ArrayList<ProductInStock>();
	private static String emailManager;
	private static String phoneNumberManager;

	/**
	 * Getter method for manager's email
	 * 
	 * @return emailManager
	 */
	public static String getEmailManager() {
		return emailManager;
	}

	/**
	 * Setter method for manager's email
	 * 
	 * @param emailManager
	 */
	public static void setEmailManager(String emailManager) {
		UpdateInventoryController.emailManager = emailManager;
	}

	/**
	 * Getter method for manager's phone number
	 * 
	 * @return phoneNumberManager
	 */
	public static String getPhoneNumberManager() {
		return phoneNumberManager;
	}

	/**
	 * Setter method for manager's phone number
	 * 
	 * @param phoneNumberManager
	 */
	public static void setPhoneNumberManager(String phoneNumberManager) {
		UpdateInventoryController.phoneNumberManager = phoneNumberManager;
	}

	/**
	 * FXML annotation for the Facility column in the table
	 */
	@FXML
	private TableColumn<ProductInStock, String> Facility;

	/**
	 * FXML annotation for the ProductName column in the table
	 */
	@FXML
	private TableColumn<ProductInStock, String> ProductName;

	/**
	 * FXML annotation for the Quantity column in the table
	 */
	@FXML
	private TableColumn<ProductInStock, String> Quantity;

	/**
	 * FXML annotation for the inventory table
	 */
	@FXML
	private TableView<ProductInStock> inventoryTable;

	/**
	 * FXML annotation for the Update button
	 */
	@FXML
	private Button UpdateBtn;

	/**
	 * FXML annotation for the Back button
	 */
	@FXML
	private Button backBtn;

	/**
	 * FXML annotation for the error label
	 */
	@FXML
	private Label errorLbl;

	/**
	 * Method handle the event of clicking on the Back button. It hides the current
	 * window and opens the MainScreenOperationsWorker window.
	 * 
	 * @param event MouseEvent of clicking on the Back button
	 * @throws IOException
	 */
	@FXML
	void clickOnBackBtn(MouseEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		MainScreenOperationsWorkerController mainOperationsWorkerController = new MainScreenOperationsWorkerController();
		mainOperationsWorkerController.start(primaryStage);
	}

	/**
	 * Method handle the event of clicking on the Update button. It updates the
	 * inventory of the selected item in the table and sends an email and SMS to the
	 * regional manager. If no item is selected, it shows an error message.
	 * 
	 * @param event MouseEvent of clicking on the Update button
	 * @throws IOException
	 */
	@FXML
	void clickOnUpdateBtn(MouseEvent event) throws IOException {
		ProductInStock selectedItem = inventoryTable.getSelectionModel().getSelectedItem();
		System.out.println(selectedItem);
		if (selectedItem != null) {
			ClientMissionHandler.updateStockToProduct(selectedItem);
			selectedItem.setAmount(200);
			popUpArr.add(selectedItem);
			ClientMissionHandler.getProductsToUpdateInventory(MainScreenOperationsWorkerController.getFacility(),
					dataToTable);
			errorLbl.setVisible(true);
			errorLbl.setTextFill(Color.GREEN);
			errorLbl.setText("Added Invetory To Item: " + selectedItem.getProductName());
		} else {
			errorLbl.setTextFill(Color.RED);
			errorLbl.setVisible(true);
			errorLbl.setText("Please choose an item OR try the refresh button");
		}

		if (inventoryTable.getItems().size() == 0 && selectedItem != null) {
			errorLbl.setVisible(true);
			errorLbl.setTextFill(Color.GREEN);
			errorLbl.setText("The call status was done successfully");
			String region = Util.getRegionFromFacilities(MainScreenOperationsWorkerController.getFacility());
			String str = popUpArr.toString().replace("[", "").replace("]", "").replace(", ", "");
			ClientMissionHandler.checkDetailsFromRegionalManager(region);
			popUpMsgController.textToSet = "Email and SMS have been sent to the regional manager in region: " + region
					+ ".\n" + "SMS was sent to " + UpdateInventoryController.phoneNumberManager + "\nEmail was sent to "
					+ UpdateInventoryController.emailManager
					+ "\nThe following products are with updated inventory in your facility area:\n" + str;
			popUpMsgController popUp = new popUpMsgController();
			popUpArr.clear();
			popUp.start(new Stage());
		}
	}

	/**
	 * Method handle the event of clicking on the Refresh button. It refreshes the
	 * table by getting the updated products from the server.
	 * 
	 * @param event MouseEvent of clicking on the Refresh button
	 * @throws IOException
	 */
	@FXML
	void clickRefresh(MouseEvent event) throws IOException {
		ClientMissionHandler.getProductsToUpdateInventory(MainScreenOperationsWorkerController.getFacility(),
				dataToTable);
	}

	/**
	 * Method is used for initializing the fields and properties of the elements in
	 * the FXML file. It hides the error label, sets the table to be uneditable,
	 * sets the column width to fit the content, sets the cell values for each
	 * column, sets the items to be displayed in the table, and gets the updated
	 * products from the server to be displayed in the table.
	 * 
	 * @throws IOException
	 */
	@FXML
	public void initialize() throws IOException {
		errorLbl.setVisible(false);
		inventoryTable.setEditable(false);
		inventoryTable.autosize();
		ProductName.setCellValueFactory((Callback) new PropertyValueFactory<ProductInStock, String>("productName"));
		Quantity.setCellValueFactory((Callback) new PropertyValueFactory<ProductInStock, String>("amount"));
		Facility.setCellValueFactory((Callback) new PropertyValueFactory<ProductInStock, String>("facility"));
		inventoryTable.setItems(dataToTable);
		ClientMissionHandler.getProductsToUpdateInventory(MainScreenOperationsWorkerController.getFacility(),
				dataToTable);
	}

	/**
	 * The start method is used for displaying the UpdateInventoryScreen window. It
	 * loads the FXML file, sets the title, icon, and scene of the primary stage,
	 * sets the stage to be not resizable, and adds an event handler for the close
	 * request.
	 * 
	 * @param primaryStage the primary stage of the window
	 * @throws IOException
	 */
	public void start(Stage primaryStage) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/UpdateInventoryScreen.fxml"));
		primaryStage.getIcons()
				.add(new Image(UpdateInventoryController.class.getResourceAsStream("/pictures/ekrutIcon.png")));
		Scene scene = new Scene(root);
		primaryStage.setTitle("E-Krut Update Inventory Screen");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);
		System.out.println(MainScreenOperationsWorkerController.getUsername());
		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.closeWindow(MainScreenOperationsWorkerController.getUsername());
		});
	}

	/**
	 * Handle method for window close request event. It is currently empty, but can
	 * be used for adding functionality when the window is closed.
	 * 
	 * @param event WindowEvent of the close request
	 */
	@Override
	public void handle(WindowEvent event) {
		// TODO Auto-generated method stub

	}

}
