package guiClientControllers;

import java.io.IOException;

import client.ClientMissionHandler;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 *
 * MainCEOController class contain getters and setters methods for first name, user name and phone number
 * 
 *  @author Maayan
 */
public class MainCEOController implements EventHandler<WindowEvent> {

	private static String firstName;
	private static String userName;
	private static String phoneNumber;
	private static String facility;
	
    /**
     * Get the first name of the CEO
     * @return the first name of the CEO
     */
	public static String getFirstName() {
		return firstName;
	}

    /**
     * Set the first name of the CEO
     * @param firstName the first name of the CEO
     */
	public static void setFirstName(String firstName) {
		MainCEOController.firstName = firstName;
	}

    /**
     * Get the user name of the CEO
     * @return the user name of the CEO
     */
	public static String getUserName() {
		return userName;
	}

    /**
     * Set the user name of the CEO
     * @param userName the user name of the CEO
     */
	public static void setUserName(String userName) {
		MainCEOController.userName = userName;
	}

    /**
     * Get the phone number of the CEO
     * @return the phone number of the CEO
     */	
	public static String getPhoneNumber() {
		return phoneNumber;
	}

	  /**
     * Set the phone number of the CEO
     * @param phoneNumber the phone number of the CEO
     */	
	public static void setPhoneNumber(String phoneNumber) {
		MainCEOController.phoneNumber = phoneNumber;
	}

    @FXML
    private ImageView EKpic;

    @FXML
    private ImageView OLpic;
    
    @FXML
    private Label configLbl;
	
	@FXML
	private TextArea consoleUser;

	@FXML
	private Button logoutButton;

	@FXML
	private Button viewDeliveryReportBtn;

	@FXML
	private Button viewReportsBtn;

	@FXML
	private Label welcomeLabel;

	/**
	* @author Maayan
	* The clickLogout() method is used to handle the event of clicking on the logout button.
	* It hides the current window, creates a new stage, creates a new instance of the ClientLoginScreenController,
	* calls the start() method on the new instance and passes the new stage as a parameter, and calls the logOut() method in the ClientMissionHandler class with the userName.
	* 
	* @param event the ActionEvent of clicking on the logout button
	* @throws IOException if an I/O error occurs while creating the new stage
	*/
	@FXML
	void clickLogout(ActionEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		ClientLoginScreenController subController = new ClientLoginScreenController();
		subController.start(primaryStage);
		ClientMissionHandler.logOut(userName);
	}

	/**
	* @author Maayan
	* The clickViewDeliveryReport() method is used to handle the event of clicking on the view delivery report button.
	* It hides the current window, creates a new stage, creates a new instance of the ChooseTimeReportCEOController,
	* calls the start() method on the new instance and passes the new stage as a parameter.
	*
	* @param event the MouseEvent of clicking on the view delivery report button
	* @throws IOException if an I/O error occurs while creating the new stage
	*/
	@FXML
	void clickViewDeliveryReport(MouseEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		ChooseTimeReportCEOController chooseTime = new ChooseTimeReportCEOController();
		chooseTime.start(primaryStage);
	}

	/**
	* @author Maayan
	* The clickViewReports() method is used to handle the event of clicking on the view reports button.
	* It hides the current window, creates a new stage, sets the role to "CEO" in the ChooseReportScreenController class, 
	* creates a new instance of the ChooseReportScreenController,
	* calls the start() method on the new instance and passes the new stage as a parameter.
	*
	* @param event the MouseEvent of clicking on the view reports button
	* @throws IOException if an I/O error occurs while creating the new stage
	*/
	@FXML
	void clickViewReports(MouseEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		final Stage primaryStage = new Stage();
		ChooseReportScreenController.setRole("CEO");
		ChooseReportScreenController reportScreen = new ChooseReportScreenController();
		reportScreen.start(primaryStage);
	}

	/**
	* @author Maayan
	* The initialize() method is used to initialize the FXML elements when the screen is loaded.
	* It checks the value of the facility variable and sets the visibility of the EKpic and OLpic ImageViews accordingly,
	* sets the text of the configLbl Label, calls the setDisabality() method with the appropriate boolean parameter,
	* sets the text of the welcomeLabel Label, and sets the text of the consoleUser TextArea.
	*
	* @throws IOException if an I/O error occurs while initializing the elements
	*/
	@FXML
	public void initialize() throws IOException {
		if (facility.equals("WAREHOUSE")) {
			EKpic.setVisible(false);
			OLpic.setVisible(true);
			configLbl.setText("OL");
			setDisabality(false);
		} else {
			EKpic.setVisible(true);
			OLpic.setVisible(false);
			configLbl.setText("EK");
			setDisabality(true);
		}
		
		welcomeLabel.setText("Welcome, " + firstName);
		consoleUser.setText("Username: " + userName + "\nConfirmed as CEO of EKrut");
	}

	/**
	* @author Maayan
	* The setDisability() method is used to set the disable property of the viewReportsBtn and viewDeliveryReportBtn buttons.
	* 
	* @param value the boolean value that represents the disable status of the buttons
	*/
	private void setDisabality(boolean value) {
		viewReportsBtn.setDisable(value);
		viewDeliveryReportBtn.setDisable(value);
		
	}

	/**
	* @author Maayan
	* The start() method is used to start the Main Screen CEO interface.
	* It loads the MainScreenCEO.fxml file, sets an icon for the stage, creates a new Scene with the root element,
	* sets the title of the stage, sets the scene, makes the stage visible, sets the stage to be not resizable,
	* sets an onCloseRequest event to call the closeWindow() method in the ClientMissionHandler class with the userName and set the onCloseRequest event to the current class.
	*
	* @param primaryStage the primary stage of the Main Screen CEO interface
	* @throws IOException if an I/O error occurs while loading the FXML file
	*/
	public void start(Stage primaryStage) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/MainScreenCEO.fxml"));
		primaryStage.getIcons()
				.add(new Image(MainCEOController.class.getResourceAsStream("/pictures/ekrutIcon.png")));
		Scene scene = new Scene(root);
		primaryStage.setTitle("E-Krut Update Inventory Screen");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);
		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.closeWindow(userName);
		});
	}

	/**
	* @author Maayan
	* The handle() method is used to handle the window event.
	* It is an overridden method from the EventHandler interface
	* 
	* @param event the WindowEvent to handle
	*/
	@Override
	public void handle(WindowEvent event) {
		
	}

	/**
	* @author Maayan
	* The getFacility() method is used to get the facility value
	*
	* @return the facility value
	*/
	public static String getFacility() {
		return facility;
	}

	/**
	* @author Maayan
	* The setFacility() method is used to set the facility value
	*
	* @param facility the facility value to set
	*/
	public static void setFacility(String facility) {
		MainCEOController.facility = facility;
	}

	
}
