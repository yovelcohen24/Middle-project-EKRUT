package guiClientControllers;

import java.io.IOException;

import client.ClientMissionHandler;
import common_entities.ProductInStock;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Callback;


/**
 * This class represents the ThresHoldLevelController and contains the methods to handle the ThresHold table,
 * the Update button, the back button and the error label.
 * 
 * @author Maayan
 */
public class ThresHoldLevelController implements EventHandler<WindowEvent> {
	ObservableList<ProductInStock> dataToTable = FXCollections.observableArrayList();
	public static String region;

	@FXML
	private TableColumn<ProductInStock, String> Facility;

	@FXML
	private TableColumn<ProductInStock, String> ProductName;

	@FXML
	private TableColumn<ProductInStock, String> Quantity;

	@FXML
	private TableView<ProductInStock> ThresHoldTable;

	@FXML
	private Button UpdateBtn;

	@FXML
	private Button backBtn;

	@FXML
	private Label errorLbl;


	/**
	* This method is called when the back button is pressed or clicked.
	* It closes the current window and opens the MainScreenManager window.
	*
	* @param event the MouseEvent that triggered the method.
	* @throws IOException if there is an error loading the MainScreenManager.fxml file.
	*/
	@FXML
	void clickOnBackBtn(MouseEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		MainScreenManagerController mainManagerScreen = new MainScreenManagerController();
		mainManagerScreen.start(primaryStage);

	}


	/**
	* Initializes the controller class. This method is automatically called after the FXML file has been loaded.
	* It sets the error label to be invisible, calls the CHECK_TRASH_HOLD method from the ClientMissionHandler class
	* to fill the table with data, sets the table to be non-editable and autosizes it, sets the cell value factory for each column
	* and sets the items for the table.
	*
	* @throws IOException if there is an error with the ClientMissionHandler.CHECK_TRASH_HOLD method.
	*/
	@FXML
	public void initialize() throws IOException {
		errorLbl.setVisible(false);
		ClientMissionHandler.CHECK_TRASH_HOLD(region, dataToTable, false);
		ThresHoldTable.setEditable(false);
		ThresHoldTable.autosize();
		ProductName.setCellValueFactory((Callback) new PropertyValueFactory<ProductInStock, String>("productName"));
		Quantity.setCellValueFactory((Callback) new PropertyValueFactory<ProductInStock, String>("amount"));
		Facility.setCellValueFactory((Callback) new PropertyValueFactory<ProductInStock, String>("facility"));
		ThresHoldTable.setItems(dataToTable);
	}


	/**
	* This method is called when the Update Products button is pressed or clicked.
	* It gets the selected item from the table, checks if it is not null, calls the Update_STATUS_TRASH_HOLD method from the ClientMissionHandler class
	* to update the status of the selected item, sets the error label to "SUCCESS" and green color, and calls the CHECK_TRASH_HOLD method from the ClientMissionHandler class
	* to fill the table with updated data. If the selected item is null, it sets the error label to "You must choose a product!" with red color.
	* If there are no products in the table, it sets the error label to "There are no products. Try the refresh button." with red color.
	*
	* @param event the MouseEvent that triggered the method.
	* @throws IOException if there is an error with the ClientMissionHandler.Update_STATUS_TRASH_HOLD or ClientMissionHandler.CHECK_TRASH_HOLD method.
	*/
	@FXML
	void clickOnUpdateProductsBtn(MouseEvent event) throws IOException {
		ProductInStock selectedItem = ThresHoldTable.getSelectionModel().getSelectedItem();
		if (selectedItem != null) {
			ClientMissionHandler.Update_STATUS_TRASH_HOLD(selectedItem);
			errorLbl.setVisible(false);
			ClientMissionHandler.CHECK_TRASH_HOLD(region, dataToTable, true);
			errorLbl.setTextFill(Color.GREEN);
			errorLbl.setVisible(true);
			errorLbl.setText("SUCCES");
			if (ThresHoldTable.getItems().size() == 0) 
				MainScreenManagerController.isAppearPopUpMsg = false;
		} else {
			if (ThresHoldTable.getItems().size() == 0) {
				errorLbl.setTextFill(Color.RED);
				errorLbl.setText("There are no products. Try the refresh button.");
				errorLbl.setVisible(true);
				MainScreenManagerController.isAppearPopUpMsg = false;
			} else {
				errorLbl.setTextFill(Color.RED);
				errorLbl.setText("You must choose a product!");
				errorLbl.setVisible(true);
			}
		}
	}


	/**
	* This method is called when the Refresh button is pressed or clicked.
	* It calls the CHECK_TRASH_HOLD method from the ClientMissionHandler class to fill the table with updated data and sets the MainScreenManagerController.isAppearPopUpMsg to true if the table is not empty.
	* It sets the error label to invisible.
	* 
	* @param event the MouseEvent that triggered the method.
	* @throws IOException if there is an error with the ClientMissionHandler.CHECK_TRASH_HOLD method.
	*/
	@FXML
	void clickRefresh(MouseEvent event) throws IOException {
		ClientMissionHandler.CHECK_TRASH_HOLD(region, dataToTable, false);
		if (ThresHoldTable.getItems().size() != 0)
			MainScreenManagerController.isAppearPopUpMsg = true;
		errorLbl.setVisible(false);

	}


	/**
	* The start method is used to initialize and set the properties of the ThresHoldLevel screen.
	* It loads the FXML file, sets the icon, title, scene, and makes the stage non-resizable.
	* It also sets the close request event to close the window and the connection to the server.
	* 
	* @param primaryStage the primary stage of the ThresHoldLevel screen.
	* @throws IOException if there is an error loading the FXML file.
	*/
	public void start(Stage primaryStage) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/ThresHoldLevelScreen.fxml"));
		primaryStage.getIcons()
				.add(new Image(MainScreenManagerController.class.getResourceAsStream("/pictures/ekrutIcon.png")));
		Scene scene = new Scene(root);
		primaryStage.setTitle("E-Krut Threshold Level Screen");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);
		primaryStage.setOnCloseRequest(e -> {
			ClientMissionHandler.closeWindow(MainScreenManagerController.getUsername());
			MainScreenManagerController.isAppearPopUpMsg = false;
		});
	}

	/**
	* handle method is used to handle a window event.
	* This method is empty and not used in this class.
	* 
	* @param event the window event to be handled.
	*/
	@Override
	public void handle(WindowEvent event) {
		// TODO Auto-generated method stub

	}

}
