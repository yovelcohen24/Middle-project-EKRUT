package guiClientControllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import client.ClientMissionHandler;
import common_class.Util;
import common_enums.Facility;
import common_enums.Region;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
* This class contains the methods that handle the view orders report screen.
*
* @author Nataly
*/
public class ViewOrdersReportScreenController implements EventHandler<WindowEvent> {

	private static HashMap<Facility, Integer> information;
	private static HashMap<String, ArrayList<String>> informationExtra;
	private static String Date;
	private static String region;

	public static HashMap<String, ArrayList<String>> getInformationExtra() {
		return informationExtra;
	}

	public static void setInformationExtra(HashMap<String, ArrayList<String>> informationExtra) {
		ViewOrdersReportScreenController.informationExtra = informationExtra;
	}

	@FXML
	private Label avgOrders;

	@FXML
	private Button backBtn;

	@FXML
	private Label bestSeller;

	@FXML
	private Label bestSeller2;

	@FXML
	private Label bestSellerStoreName;

	@FXML
	private Label bestSellerStoreName2;

	@FXML
	private Label bestTime;

	@FXML
	private Label bestTime2;

	@FXML
	private Label bestTimeStoreName;

	@FXML
	private Label bestTimeStoreName2;

	@FXML
	private Label infoLabel;

	@FXML
	private PieChart ordersPie;

	@FXML
	private Label ordersReportLabl;

	@FXML
	private Label totalOrderNumber;

	/**
	* Handles the event of a user clicking on the back button.
	*
	* This method hides the current window and opens the choose report screen.
	* 
	* @param event the mouse event that triggers this method
	* @throws IOException if there is an issue loading the choose report screen
	*/
	@FXML
	void clickOnBackBtn(MouseEvent event) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		ChooseReportScreenController chooseReportScreen = new ChooseReportScreenController();
		chooseReportScreen.start(primaryStage);
	}

	/**
    * Returns the information hashmap
    * @return the information hashmap
    */
	public static HashMap<Facility, Integer> getInformation() {
		return information;
	}

    /**
    * Sets the information hashmap
    * @param information the information to set
    */
	@SuppressWarnings("unchecked")
	public static void setInformation(Object information) {
		ViewOrdersReportScreenController.information = (HashMap<Facility, Integer>) information;
	}

    /**
    * Returns the date
    * @return the date
    */
	public static String getDate() {
		return Date;
	}

    /**
    * Sets the date
    * @param date the date to set
    */
	public static void setDate(String date) {
		Date = date;
	}

    /**
    * Returns the region
    * @return the region
    */
	public static String getRegion() {
		return region;
	}

	/**
    * Sets the region
    * @param region the region to set
    */
	public static void setRegion(String region) {
		ViewOrdersReportScreenController.region = region;
	}

	/**
	* Initializes the view orders report screen
	* This method populates the pie chart, labels, and text fields with information from the information hashmap, date, and region fields.
	* It also extracts extra information such as total orders, average orders, best seller store name, best time store name, and more.
	*/
	public void initialize() {
		ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();
		for (Map.Entry<Facility, Integer> currentSet : information.entrySet()) {
			Facility ekrutFacility = currentSet.getKey();
			Integer ekrutNumOfOrder = currentSet.getValue();
			pieChartData.add(new PieChart.Data(ekrutFacility.toString(), ekrutNumOfOrder));
		}

		ordersPie.setData(pieChartData);
		infoLabel.setText(region + ", " + Date);
		totalOrderNumber.setText(informationExtra.get("TotalOrders").get(0));
		avgOrders.setText(informationExtra.get("AvgOrders").get(0));
		ArrayList<String> arr = Util.getFacilitiesInTheRegion(Region.valueOf(region));
		bestSellerStoreName.setText(arr.get(0));
		bestSellerStoreName2.setText(arr.get(1));
		bestTimeStoreName.setText(arr.get(0));
		bestTimeStoreName2.setText(arr.get(1));
		bestSeller.setText(informationExtra.get(arr.get(0)).get(0));
		bestSeller2.setText(informationExtra.get(arr.get(1)).get(0));
		bestTime.setText(informationExtra.get(arr.get(0)).get(1));
		bestTime2.setText(informationExtra.get(arr.get(1)).get(1));

	}

	/**
	* Starts the view orders report screen
	* This method loads the FXML file for the view orders report screen, sets the title and icon for the stage,
	* sets the scene for the stage, shows the stage, and sets the stage to not be resizable.
	* It also sets an event handler for when the stage is closed, which calls a method to close the window on the server side.
	* @param primaryStage the stage for the view orders report screen
	*/
	public void start(Stage primaryStage) {
		Parent root;
		try {
			root = FXMLLoader.load(getClass().getResource("/guiClientScreens/ViewOrdersReportScreen.fxml"));
			Scene scene = new Scene(root);
			primaryStage.getIcons().add(
					new Image(ViewOrdersReportScreenController.class.getResourceAsStream("/pictures/ekrutIcon.png")));

			primaryStage.setTitle("E-Krut View Reports");
			primaryStage.setScene(scene);
			primaryStage.show();
			primaryStage.setResizable(false);
			primaryStage.setOnCloseRequest(e -> {
				if (ChooseReportScreenController.getRole().equals("CEO")) {
					ClientMissionHandler.closeWindow(MainCEOController.getUserName());
				} else {
					ClientMissionHandler.closeWindow(MainScreenManagerController.getUsername());
					MainScreenManagerController.isAppearPopUpMsg = false;
				}
			});
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	* Handle the window event
	* This method is overridden from the WindowEventHandler interface. 
	* It is meant to handle the window event that is passed as a parameter. 
	* However, the method is empty and does not contain any functionality. 
	* @param event the window event to handle
	*/
	@Override
	public void handle(WindowEvent event) {

	}

}
