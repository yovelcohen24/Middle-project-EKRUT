package guiClientControllers;

import java.io.IOException;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
* 
*
* popUpMsgController is a class that implements the EventHandler interface 
* and serves as a controller for a pop-up message screen.
*
* The class contains the following fields:
*  private TextArea simulation - A text area that displays a message.
*  private Button okBtn - A button that when clicked closes the screen.
* public static String textToSet - A static variable that holds the text to set in the simulation text area.
*
* The class contains the following methods:
* public void start(Stage primaryStage) - A method that runs when the class is started.
* It loads the FXML file, sets the scene and title of the primaryStage, 
* sets the primaryStage to not resizable, and sets the OnCloseRequest event to this class.
* It may throw IOException if there is an issue with loading the FXML file.
*
*  void initialize() - A method that runs when the FXML is loaded.
* It sets the text of the simulation text area to the text stored in the textToSet variable.
*
*  void clickOnOKBtn(MouseEvent event) - A method that hides the current window when the okBtn is clicked.
*
* void handle(WindowEvent arg0) - A method that handles the onCloseRequest event.
* 
* @author Eyal
*/
public class popUpMsgController implements EventHandler<WindowEvent> {
    @FXML
    private TextArea simulation;
	@FXML
	private Button okBtn;

	public static String textToSet;

	public void start(Stage primaryStage) throws IOException {

		Parent root = FXMLLoader.load(getClass().getResource("/guiClientScreens/popUpMsg.fxml"));
		primaryStage.getIcons().add(
				new Image(popUpMsgController.class.getResourceAsStream("/pictures/ekrutIcon.png")));
		Scene scene = new Scene(root);
		primaryStage.setTitle("��������");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);
		primaryStage.setOnCloseRequest(this);
	}

	@FXML
	public void initialize() {
		simulation.setText(textToSet);
	}

	@FXML
	void clickOnOKBtn(MouseEvent event) {
		((Node) event.getSource()).getScene().getWindow().hide();
	}

	@Override
	public void handle(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

}
