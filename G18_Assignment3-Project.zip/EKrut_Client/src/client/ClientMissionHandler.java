package client;

import java.io.IOException;
import java.net.InetAddress;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import common_class.MissionPack;
import common_class.Util;
import common_entities.DeliveryInfo;
import common_entities.PickupInfo;
import common_entities.ProductInCart;
import common_entities.ProductInStock;
import common_entities.Sale;
import common_entities.Saletable;
import common_entities.User;
import common_enums.Facility;
import common_enums.Mission;
import common_enums.Response;
import guiClientControllers.ChooseTimeReportCEOController;
import guiClientControllers.ClientLoginScreenController;
import guiClientControllers.ClientUI;
import guiClientControllers.EditThresholdLevelController;
import guiClientControllers.MainCEOController;
import guiClientControllers.MainCustomerPageController;
import guiClientControllers.MainScreenManagerController;
import guiClientControllers.MainScreenOperationsWorkerController;
import guiClientControllers.MarketingDepartmentEmployeeScreenController;
import guiClientControllers.MarketingManagerMenuScreenController;
import guiClientControllers.OperatesDeliveriesManApproveScreenController;
import guiClientControllers.OperatesDeliveriesManChangeStatusScreenController;
import guiClientControllers.OperatesDeliveriesManScreenController;
import guiClientControllers.PaymentWindowController;
import guiClientControllers.ServiceRepresentativeAddController;
import guiClientControllers.ServiceRepresentativeScreenController;
import guiClientControllers.ServiceRepresentativeaddingfromClientTosubscriberController;
import guiClientControllers.ShoppingWindowController;
import guiClientControllers.TheEndController;
import guiClientControllers.UpdateInventoryController;
import guiClientControllers.UserScreenController;
import guiClientControllers.ViewCustomerReportController;
import guiClientControllers.ViewDeliveriesReportScreenController;
import guiClientControllers.ViewOrdersReportScreenController;
import guiClientControllers.ViewStockReportScreenController;
import guiClientControllers.popUpMsgController;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 * The ClientMissionHandler class contains functions which allow us to
 * communicate with the server via OCSF sends an object MissionPack which
 * contains the mission to the server, accept the response and process the
 * information.
 *
 * @author Yovel
 */
public class ClientMissionHandler {

	/**
	 * This method handles the connection of the client to the server by creating a
	 * new ClientController object, creating a MissionPack object with the
	 * connection details, and sending it to the server. If the connection is
	 * successful, it opens the next window, otherwise it displays an error message.
	 * 
	 * @author Yovel
	 * @param event the mouse event that triggers the connection
	 * @param ip    the IP address of the server
	 * @param port  the port number to connect to on the server
	 * @throws Exception if there is an error connecting to the server
	 */
	public static void CONNECT_TO_SERVER(final MouseEvent event, final String ip, final String port) throws Exception {
		ClientUI.chat = new ClientController(ip, Integer.parseInt(port));
		if (ClientUI.chat != null) {
			MissionPack obj = new MissionPack(Mission.SEND_CONNECTION_DETAILS, null, null);
			final ArrayList<String> details = new ArrayList<String>();
			details.add(InetAddress.getLocalHost().getHostAddress());
			details.add(InetAddress.getLocalHost().getHostName());
			obj.setInformation(details);
			ClientUI.chat.accept(obj);
			obj = ClientUI.chat.getResponseFromServer();
			if (obj.getResponse().equals(Response.UPDATE_CONNECTION_SUCCESS)) {
				((Node) event.getSource()).getScene().getWindow().hide();
				final Stage primaryStage = new Stage();
				ClientLoginScreenController subController = new ClientLoginScreenController();
				subController.start(primaryStage); // connection successful->goto the next window
				System.out.println("connect to server");
			} else {
				System.out.println("did not connect to server");
			}
		}
	}

	/**
	 * This method sends the disconnection details to the server and disconnects the
	 * client.
	 * 
	 * @author Yovel
	 */
	public static void DISCONNECT_FROM_SERVER() {
		final MissionPack obj = new MissionPack(Mission.SEND_DISCONNECTION_DETAILS, null, null);
		final ArrayList<String> details = new ArrayList<String>();
		try {
			details.add(InetAddress.getLocalHost().getHostAddress());
			details.add(InetAddress.getLocalHost().getHostName());
		} catch (Exception e) {
			e.printStackTrace();
		}
		obj.setInformation(details);
		ClientUI.chat.accept(obj);
	}

	/**
	 * This method checks if the user is already logged in by sending a request to
	 * the server and updating the error label accordingly.
	 * 
	 * @author Yovel
	 * @param username   the username of the user
	 * @param errorLabel the Label object that displays error messages
	 * @return true if the user is not already logged in, false otherwise
	 */
	public static boolean CHECK_LOGGED_IN(String username, Label errorLabel) {
		MissionPack obj = new MissionPack(Mission.CHECK_LOGGED_IN, null, username);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.LOGGED_IN_ERROR)) {
			errorLabel.setText("User is already logged in");
			return false;
		} else if (obj.getResponse().equals(Response.USER_DOESNT_EXIST)) {
			errorLabel.setText("Username doesn't exist");
			return false;
		}
		return true;
	}
	/**
	 * Check if a user is logged in by their ID.
	 * 
	 * @author Yovel
	 * 
	 * @param subNumber The ID or subscriber number of the user.
	 * @param errorLabel A Label object to display error messages.
	 * @return Returns true if the user is logged in, false otherwise.
	 */
	public static boolean CHECK_LOGGED_IN_BY_ID(String subNumber, Label errorLabel) {
		MissionPack obj = new MissionPack(Mission.CHECK_LOGGED_IN_BY_ID, null, subNumber);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.LOGGED_IN_BY_ID_ERROR)) {
			errorLabel.setText("User is already logged in");
			return false;
		} else if (obj.getResponse().equals(Response.USER_DOESNT_EXIST)) {
			errorLabel.setText("Username doesn't exist");
			return false;
		}
		return true;
	}

	/**
	 * This method sends a request to the server to identify the user and updates
	 * the error label accordingly.
	 * 
	 * @author Yovel
	 * @param event      the MouseEvent that triggered the method
	 * @param username   the username of the user
	 * @param password   the password of the user
	 * @param errorLabel the Label object that displays error messages
	 */
	public static void IDENTIFY_USER(MouseEvent event, String username, String password, Label errorLabel)
			throws Exception {
		String[] data = { username, password };
		String[] setconfig = { username, password, ClientUI.config, ClientUI.facility };
		MissionPack objset = new MissionPack(Mission.SET_CONFIG_FACILITY, null, setconfig);
		ClientUI.chat.accept(objset);
		MissionPack obj = new MissionPack(Mission.IDENTIFY_USER, null, data); // create mission to login and send login
																				// // data
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();

		if (obj.getResponse().equals(Response.LOGIN_SUCCEED)) {
			String firstName = ((String[]) obj.getInformation())[4];
			String phone = ((String[]) obj.getInformation())[3];
			String role = ((String[]) obj.getInformation())[2];
			String config = ((String[]) obj.getInformation())[6];
			String facility = ((String[]) obj.getInformation())[7];
			String email = ((String[]) obj.getInformation())[8];
			String region = ((String[]) obj.getInformation())[5];
			String subscriberFirstPurchase = ((String[]) obj.getInformation())[9];
			((Node) event.getSource()).getScene().getWindow().hide();
			final Stage primaryStage = new Stage();
			if (role.equals("customer") || role.equals("subscriber")) {
				MainCustomerPageController.setFirstName(firstName);
				MainCustomerPageController.setPhone(phone);
				MainCustomerPageController.setRole(role);
				MainCustomerPageController.setUsername(username);
				MainCustomerPageController.setConfig(config);
				MainCustomerPageController.setFacility(facility);
				MainCustomerPageController.setEmail(email);
				MainCustomerPageController.setRegion(region);
				MainCustomerPageController.setSubscriberFirstPurchase(subscriberFirstPurchase);
				MainCustomerPageController subController = new MainCustomerPageController();
				subController.start(primaryStage);
			} else if (role.equals("ServiceRepresentative")) {
				ServiceRepresentativeScreenController.setUsername(username);
				ServiceRepresentativeScreenController.setFirstName(firstName);
				ServiceRepresentativeScreenController.setPhone(phone);
				ServiceRepresentativeScreenController.setFacility(facility);
				ServiceRepresentativeAddController.setFirstName(firstName);
				ServiceRepresentativeAddController.setPhone(phone);
				ServiceRepresentativeaddingfromClientTosubscriberController.setFirstName(firstName);
				ServiceRepresentativeaddingfromClientTosubscriberController.setPhone(phone);
				ServiceRepresentativeScreenController ServiceRepresentative = new ServiceRepresentativeScreenController();
				ServiceRepresentative.start(primaryStage);
			} else if (role.equals("RegionalManager")) {
				MainScreenManagerController.setUsername(username);
				MainScreenManagerController.setFirstName(firstName);
				MainScreenManagerController.setPhone(phone);
				MainScreenManagerController.setRole(role);
				MainScreenManagerController.setEmail(email);
				MainScreenManagerController.setRegion(region);
				MainScreenManagerController.setFacility(facility);
				MainScreenManagerController RegionalManager = new MainScreenManagerController();
				RegionalManager.start(primaryStage);
			} else if (role.equals("CEO")) {
				MainCEOController.setUserName(username);
				MainCEOController.setFirstName(firstName);
				MainCEOController.setPhoneNumber(phone);
				MainCEOController.setFacility(facility);
				MainCEOController ceoManager = new MainCEOController();
				ceoManager.start(primaryStage);
			} else if (role.equals("OperationsWorker")) {
				MainScreenOperationsWorkerController.setUsername(username);
				MainScreenOperationsWorkerController.setPhone(phone);
				MainScreenOperationsWorkerController.setEmail(email);
				MainScreenOperationsWorkerController.setFacility(facility);
				MainScreenOperationsWorkerController operationsWorker = new MainScreenOperationsWorkerController();
				operationsWorker.start(primaryStage);
			} else if (role.equals("DeliveryOperate")) {
				OperatesDeliveriesManScreenController.setUsername(username);
				OperatesDeliveriesManScreenController.setFirstName(firstName);
				OperatesDeliveriesManScreenController.setPhone(phone);
				OperatesDeliveriesManScreenController.setRegion(region);
				OperatesDeliveriesManScreenController.setFacility(facility);
				OperatesDeliveriesManApproveScreenController.setRegion(region);
				OperatesDeliveriesManApproveScreenController.setFirstName(firstName);
				OperatesDeliveriesManApproveScreenController.setPhone(phone);
				OperatesDeliveriesManChangeStatusScreenController.setRegion(region);
				OperatesDeliveriesManChangeStatusScreenController.setFirstName(firstName);
				OperatesDeliveriesManChangeStatusScreenController.setPhone(phone);
				OperatesDeliveriesManScreenController OperatesDeliveries = new OperatesDeliveriesManScreenController();
				OperatesDeliveries.start(primaryStage);

			} else if (role.equals("user") || role.equals("RequsestToBeCustomer")) {
				UserScreenController.setUsername(username);
				UserScreenController userScreen = new UserScreenController();
				userScreen.start(primaryStage);

			} else if (role.equals("MarketingEmployee")) {
				MarketingDepartmentEmployeeScreenController.setUsername(username);
				MarketingDepartmentEmployeeScreenController.setFirstName(firstName);
				MarketingDepartmentEmployeeScreenController.setPhone(phone);
				MarketingDepartmentEmployeeScreenController.setRegion(region);
				MarketingDepartmentEmployeeScreenController.setFacility(facility);
				MarketingDepartmentEmployeeScreenController MarketingEmployeeScreen = new MarketingDepartmentEmployeeScreenController();
				MarketingEmployeeScreen.start(primaryStage);

			} else if (role.equals("MarketingManager")) {
				MarketingManagerMenuScreenController.setUsername(username);
				MarketingManagerMenuScreenController.setFirstName(firstName);
				MarketingManagerMenuScreenController.setPhone(phone);
				MarketingManagerMenuScreenController.setFacility(facility);
				MarketingManagerMenuScreenController MarketingManagerScreen = new MarketingManagerMenuScreenController();
				MarketingManagerScreen.start(primaryStage);

			}

		} else {
			// System.out.println("User doesn't exist!Try again");
			errorLabel.setText("Wrong username/password!Try again");
		}
	}

	/**
	 * This method sends a request to the server to find a user with a specific
	 * username. It updates the visibility of certain UI elements according to the
	 * response of the server.
	 * 
	 * @author Yovel
	 * @param userName        the TextField containing the username to search for
	 * @param statusLabelfind the Label displaying the status of the search
	 * @param cardNumber1     the TextField for the first four digits of the credit
	 *                        card
	 * @param cardNumber2     the TextField for the second four digits of the credit
	 *                        card
	 * @param cardNumber3     the TextField for the third four digits of the credit
	 *                        card
	 * @param cardNumber4     the TextField for the fourth four digits of the credit
	 *                        card
	 * @param year            the ComboBox for the expiration year of the credit
	 *                        card
	 * @param month           the ComboBox for the expiration month of the credit
	 *                        card
	 * @param CVV             the TextField for the CVV of the credit card
	 * @param creditcard      the Label for the credit card section
	 * @param expiration      the Label for the expiration section
	 * @param cvv             the Label for the CVV section
	 * @param statusLabel     the Label displaying the status of the request
	 * @param line1           the Label for the first line of the credit card
	 *                        section
	 * @param line2           the Label for the second line of the credit card
	 *                        section
	 * @param line3           the Label for the third line of the credit card
	 *                        section
	 * @param addCustomer     the Button for adding a customer
	 * @param find 
	 */

	public static void findUser(TextField userName, Label statusLabelfind, TextField cardNumber1, TextField cardNumber2,
			TextField cardNumber3, TextField cardNumber4, ComboBox year, ComboBox month, TextField CVV,
			Label creditcard, Label expiration, Label cvv, Label statusLabel, Label line1, Label line2, Label line3,
			Button addCustomer, Button find) {
		statusLabel.setText(null);
		String UserNameToSearch = (String) userName.getText();
		MissionPack obj = new MissionPack(Mission.FIND_USER_IN_DATA, null, UserNameToSearch);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		System.out.println(obj.getInformation());
		if (obj.getResponse().equals(Response.FIND_USER_IN_DATA_SUCCESS)) {
			cardNumber1.setVisible(true);
			cardNumber2.setVisible(true);
			cardNumber3.setVisible(true);
			cardNumber4.setVisible(true);
			year.setVisible(true);
			month.setVisible(true);
			CVV.setVisible(true);
			creditcard.setVisible(true);
			expiration.setVisible(true);
			cvv.setVisible(true);
			line1.setVisible(true);
			line2.setVisible(true);
			line3.setVisible(true);
			addCustomer.setVisible(true);
			statusLabelfind.setText(null);
			find.setDisable(true);
			userName.setDisable(true);
			
		} else {
			statusLabelfind.setText("The user is not found");
		}

	}

	/**
	 * This method is used to add a new customer to the system. The method first
	 * checks if the CVV entered is 3 digits long and if the credit card number is
	 * 16 digits long. If the input is not valid, an error message is displayed. If
	 * the input is valid, the method sends a request to the server to add the
	 * customer and waits for a response. If the response is successful, the status
	 * label is updated to indicate that the customer is awaiting regional manager
	 * approval. If the response is not successful, the status label is updated to
	 * indicate that the attempt failed.
	 *
	 * @author Yovel
	 *
	 * @param userName    The text field containing the user name to add as a
	 *                    customer
	 * @param cardNumber1 The text field containing the first 4 digits of the credit
	 *                    card number
	 * @param cardNumber2 The text field containing the second 4 digits of the
	 *                    credit card number
	 * @param cardNumber3 The text field containing the third 4 digits of the credit
	 *                    card number
	 * @param cardNumber4 The text field containing the fourth 4 digits of the
	 *                    credit card number
	 * @param year        The combobox containing the expiration year of the credit
	 *                    card
	 * @param month       The combobox containing the expiration month of the credit
	 *                    card
	 * @param CVV         The text field containing the CVV of the credit card
	 * @param status      The label used to display status messages
	 * @param find 
	 * @param creditcard, expiration, cvv, line1, line2, line3, addCustomer
	 *                    Additional labels and buttons used in the UI
	 */
	public static void AddingCustomerNew(final TextField userName, final TextField cardNumber1, TextField cardNumber2,
			TextField cardNumber3, TextField cardNumber4, final ComboBox year, ComboBox month, final TextField CVV,
			Label status, Label creditcard, Label expiration, Label cvv, Label line1, Label line2, Label line3,
			Button addCustomer, Button find) {
		try {
			int cvvcheck = Integer.parseInt(CVV.getText());

		} catch (NumberFormatException e) {
			status.setTextFill(Color.RED);
			status.setText("the CVV need to be with 3 digits !");

			return;
		}
		if (CVV.getText().length() != 3) {
			status.setTextFill(Color.RED);
			status.setText("the CVV length need to be with 3 digits !");

			return;
		}
		if (cardNumber1.getText().length() != 4 || cardNumber2.getText().length() != 4
				|| cardNumber3.getText().length() != 4 || cardNumber4.getText().length() != 4) {
			status.setTextFill(Color.RED);
			status.setText("You have to enter 4 digits in each cell!");
			return;
		} else {
			try {
				int firstnumber = Integer.parseInt(cardNumber1.getText());
				int secondnumber = Integer.parseInt(cardNumber2.getText());
				int thirdnumber = Integer.parseInt(cardNumber3.getText());
				int fournumber = Integer.parseInt(cardNumber4.getText());

			} catch (NumberFormatException e) {
				status.setTextFill(Color.RED);
				status.setText("A credit card consists of numbers only!");

				return;
			}
		}

		String[] newone = { userName.getText(),
				cardNumber1.getText() + "-" + cardNumber2.getText() + "-" + cardNumber3.getText() + "-"
						+ cardNumber4.getText(),
				(String) month.getValue() + "/" + (String) year.getValue(), CVV.getText() };
		MissionPack obj = new MissionPack(Mission.ADD_CUSTOMER_DATA, null, newone);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.ADD_CUSTOMER_DATA_SUCCESS)) {
			status.setTextFill(Color.GREEN);
			status.setText("Awaiting regional manager approval");
			changeVisable(userName, cardNumber1, cardNumber2, cardNumber3, cardNumber4, year, month, CVV, creditcard,
					expiration, cvv, line1, line2, line3, addCustomer);
			find.setDisable(false);
			userName.setDisable(false);
			System.out.println(
					"the The user has been successfully added to the system as a customer and waiting for the approval of the regional manager");
		} else {
			status.setTextFill(Color.RED);
			status.setText("The Attempt failed");
			
			changeVisable(userName, cardNumber1, cardNumber2, cardNumber3, cardNumber4, year, month, CVV, creditcard,
					expiration, cvv, line1, line2, line3, addCustomer);
			find.setDisable(false);
			userName.setDisable(false);
			userName.setText(null);
			
		}
		

	}

	/**
	 * 
	 * This method is used to change the visibility of certain elements on the UI
	 * such as text fields, labels, and buttons after a customer has been added to
	 * the system. It sets the visibility of the elements to false and clears their
	 * contents.
	 * 
	 * @author Yovel
	 * @param userName    A TextField where the user enters the user name
	 * @param cardNumber1 A TextField where the user enters the first set of digits
	 *                    of the credit card
	 * @param cardNumber2 A TextField where the user enters the second set of digits
	 *                    of the credit card
	 * @param cardNumber3 A TextField where the user enters the third set of digits
	 *                    of the credit card
	 * @param cardNumber4 A TextField where the user enters the fourth set of digits
	 *                    of the credit card
	 * @param year        A ComboBox where the user selects the year of the credit
	 *                    card's expiration date
	 * @param month       A ComboBox where the user selects the month of the credit
	 *                    card's expiration date
	 * @param CVV         A TextField where the user enters the CVV of the credit
	 *                    card
	 * @param creditcard  A Label that labels the credit card text fields
	 * @param expiration  A Label that labels the expiration date ComboBoxes
	 * @param cvv         A Label that labels the CVV TextField
	 * @param line1       A Label that serves as a visual separator
	 * @param line2       A Label that serves as a visual separator
	 * @param line3       A Label that serves as a visual separator
	 * @param addCustomer A Button that is used to submit the customer's information
	 */

	private static void changeVisable(final TextField userName, final TextField cardNumber1, TextField cardNumber2,
			TextField cardNumber3, TextField cardNumber4, final ComboBox year, ComboBox month, final TextField CVV,
			Label creditcard, Label expiration, Label cvv, Label line1, Label line2, Label line3, Button addCustomer) {
		cardNumber1.setVisible(false);
		cardNumber2.setVisible(false);
		cardNumber3.setVisible(false);
		cardNumber4.setVisible(false);
		year.setVisible(false);
		month.setVisible(false);
		CVV.setVisible(false);
		creditcard.setVisible(false);
		expiration.setVisible(false);
		cvv.setVisible(false);
		line1.setVisible(false);
		line2.setVisible(false);
		line3.setVisible(false);
		addCustomer.setVisible(false);
		cardNumber1.clear();
		cardNumber2.clear();
		cardNumber3.clear();
		cardNumber4.clear();
		year.getSelectionModel().clearSelection();
		month.getSelectionModel().clearSelection();
		CVV.clear();
		userName.clear();
	}

	/**
	 * 
	 * This method is used to upgrade a customer to a subscriber.
	 * 
	 * @author Yovel
	 * @param usernameofcustomer The TextField that contains the username of the
	 *                           customer.
	 * @param status             The Label that shows the status of the process.
	 * @param vIPimg             The ImageView that shows the VIP image.
	 * @throws IOException if the popUpMsgController.start method throws an
	 *                     exception.
	 */
	public static void fromCustomerToSubscriber(final TextField usernameofcustomer, Label status, ImageView vIPimg)
			throws IOException {
		status.setText(null);
		String UserNameToSearch = (String) usernameofcustomer.getText();
		MissionPack obj = new MissionPack(Mission.FROM_CUSTOMER_TO_SUBSCRIBER, null, UserNameToSearch);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.FROM_CUSTOMER_TO_SUBSCRIBER_SUCCESS)) {
			vIPimg.setVisible(true);
			String[] information = (String[]) obj.getInformation();
			final Stage primaryStage = new Stage();
			popUpMsgController.textToSet = "User request -> " + UserNameToSearch + "\r\n"
					+ "Become a subscriber successfully completed\r\n" + "An email was sent to his email address ->"
					+ information[0] + "\r\n" + "And SMS message was sent to his cell phone number -> " + information[1]
					+ "\r\n" + "with the following content: Dear customer your subscription number -> " + information[2]
					+ "\r\n"
					+ "And you have access to install the EKT app, congratulations you won a 20% discount \n on your first purchase, go shopping :)";
			popUpMsgController popUp = new popUpMsgController();
			popUp.start(primaryStage);
			System.out.println("the The user has been successfully added to the system as a subscriber ");
		} else {
			status.setText("The Attempt failed");
			vIPimg.setVisible(false);
		}
		usernameofcustomer.clear();

	}

	/**
	 * 
	 * This method is used to refresh the list of deliveries in a specific region.
	 * It accepts the region to be searched, the listView of deliveries, and a label
	 * for displaying error messages. It sends a request to the server with the
	 * desired region, and if the server responds with success, it updates the
	 * listView with the new information. Otherwise, it displays an error message on
	 * the provided label.
	 * 
	 * @param region   the region to be searched for deliveries
	 * @param listView the listView containing the deliveries
	 * @param errorLbl label for displaying error messages
	 * @author Yovel
	 */
	public static void refreshDelivery(String region, final ObservableList<DeliveryInfo> listView, Label errorLbl) {

		MissionPack obj = new MissionPack(Mission.REFRESH_DELIVERY, null, region);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.REFRESH_DELIVERY_SUCCESS)) {
			listView.clear();
			@SuppressWarnings("unchecked")
			List<DeliveryInfo> list = (List<DeliveryInfo>) obj.getInformation();
			for (int i = 0; i < list.size(); i++) {
				listView.add(list.get(i));
			}
		} else {
			errorLbl.setText("The Attempt failed");

		}

	}

	/**
	 * 
	 * @author Yovel
	 * 
	 *         This method is used to approve a selected delivery and notify the
	 *         customer about the approval.
	 * 
	 * @param selectedDelivery The selected delivery that needs to be approved.
	 * 
	 * @param errorLbl         A label used to show error messages if the approval
	 *                         fails.
	 * 
	 * 
	 * @throws IOException
	 * 
	 *                     The method sends a request to the server to approve the
	 *                     selected delivery. If the approval is successful, it
	 *                     sends an email and SMS notification to the customer with
	 *                     the estimated delivery time. If the approval fails, it
	 *                     shows an error message on the errorLbl label.
	 */
	public static void approveDelivery(DeliveryInfo selectedDelivery, Label errorLbl) throws IOException {
		errorLbl.setText(null);
		MissionPack obj = new MissionPack(Mission.APPROVE_DELIVERY, null, selectedDelivery);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.APPROVE_DELIVERY_SUCCESS)) {
			SimpleDateFormat formatter1 = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			SimpleDateFormat formatter2 = new SimpleDateFormat("dd/MM/yyyy HH:mm");
			Date date1 = new Date(); // current
			String nowTime = formatter1.format(date1);
			Date date2 = new Date();
			date2.setHours(date2.getHours() + Util.totalDeliveryTime());
			String deliveryArrivalTime = formatter2.format(date2);
			final Stage primaryStage = new Stage();
			popUpMsgController.textToSet = "User's shipment" + "Confirmed at " + nowTime + "\n"
					+ "An email notification has been sent to email -> " + selectedDelivery.getEmail() + "\r\n"
					+ "and an SMS message to the cell phone number -> " + selectedDelivery.getPhoneNumber() + "\r\n"
					+ "With the following content: Dear customer,\n" + "your shipment has been confirmed and\n"
					+ "will reach its destination on -> " + deliveryArrivalTime;
			popUpMsgController popUp = new popUpMsgController();
			popUp.start(primaryStage);
		} else {

			errorLbl.setText("The Attempt failed");

		}
	}

	/**
	 * This method is used to refresh the delivery status of a specific region. The
	 * method takes in a region, an observable list of delivery information, and a
	 * status label.
	 * 
	 * @author Yovel
	 * @param region       the region of the delivery
	 * @param dataToTable  the observable list of delivery information to be updated
	 * @param statusLabel1 the label used to display the status of the operation
	 */
	public static void refreshDeliverytostatus(String region, final ObservableList<DeliveryInfo> dataToTable,
			Label statusLabel1) {
		MissionPack obj = new MissionPack(Mission.REFRESH_DELIVERY_TO_STATUS, null, region);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.REFRESH_DELIVERY_SUCCESS)) {
			dataToTable.clear();
			@SuppressWarnings("unchecked")
			List<DeliveryInfo> list = (List<DeliveryInfo>) obj.getInformation();
			for (int i = 0; i < list.size(); i++) {
				dataToTable.add(list.get(i));
			}
		} else {
			statusLabel1.setText("The Attempt failed");
		}

	}

	/**
	 * 
	 * @author Yovel This method runs a sale for the selected sales template. The
	 *         method receives a Saletable object, representing the selected sales
	 *         template, and a Label object, used to display error messages. The
	 *         method first creates a MissionPack object, with a mission type of
	 *         Mission.RUN_SALE, and the selected sales template as the information.
	 *         The method then sends the MissionPack object to the server using the
	 *         ClientUI.chat.accept() method. The method then receives a response
	 *         from the server in the form of another MissionPack object, and checks
	 *         its response field. If the response field is equal to
	 *         Response.RUN_SALE_SUCCESS, it means the promotion template has been
	 *         successfully activated and the error label text is set to "The
	 *         marketing manager promotion template has been successfully activated"
	 *         with a green color. If the response field is not equal to
	 *         Response.RUN_SALE_SUCCESS, it means the activation failed, and the
	 *         error label text is set to "The Attempt failed" with a red color.
	 * @param selectedsales The selected sales template to activate.
	 * @param erorlable     The label object to display error messages.
	 */
	public static void runSale(Saletable selectedsales, Label erorlable) {
		MissionPack obj = new MissionPack(Mission.RUN_SALE, null, selectedsales);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.RUN_SALE_SUCCESS)) {
			erorlable.setTextFill(Color.GREEN);
			erorlable.setText("The marketing manager promotion \n template  has been \n successfully activated");
		} else {
			erorlable.setTextFill(Color.RED);
			erorlable.setText("The Attempt failed");

		}

	}

	/**
	 * 
	 * This method is used to refresh the sale table in the marketing manager GUI.
	 * It sends a request to the server to retrieve the sales information for the
	 * given region and updates the table with the returned data. If the request is
	 * successful, the table will be cleared and the new data will be added to it.
	 * If the request is unsuccessful, an error message will be displayed.
	 * 
	 * @author Yovel
	 * @param region      - the region for which the sales information should be
	 *                    retrieved
	 * @param dataToTable - the observable list that holds the data for the table
	 * @param erorlable   - the label that displays error messages
	 */
	public static void refreshSaleTable(String region, ObservableList<Saletable> dataToTable, Label erorlable) {
		MissionPack obj = new MissionPack(Mission.REFRESH_SALES_TABLE, null, region);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.REFRESH_SALES_TABLE_SUCCESS)) {
			dataToTable.clear();
			@SuppressWarnings("unchecked")
			List<Saletable> list = (List<Saletable>) obj.getInformation();
			for (int i = 0; i < list.size(); i++) {
				dataToTable.add(list.get(i));
			}
		} else {
			erorlable.setText("The Attempt failed");
		}

	}

	/**
	 * 
	 * The method changeStatus is responsible for updating the status of a selected
	 * delivery. It sends a request to the server with a MissionPack object that
	 * contains the selected delivery, the mission type and the necessary
	 * information to update the status.
	 * 
	 * @author Yovel
	 * @param selectedDelivery - the selected delivery from the table view that
	 *                         needs to have its status changed.
	 * @param statusLabel1     - a label that will display a message indicating
	 *                         whether the status update was successful or not.
	 * @throws IOException - in case of an error with the communication with the
	 *                     server.
	 */
	public static void changeStatus(DeliveryInfo selectedDelivery, Label statusLabel1) throws IOException {
		statusLabel1.setText(null);
		MissionPack obj = new MissionPack(Mission.CHANGE_STATUS, null, selectedDelivery);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.CHANGE_STATUS_SUCCESS)) {
			statusLabel1.setTextFill(Color.GREEN);
			statusLabel1.setText("The shipment was made successfully");
		} else {
			statusLabel1.setTextFill(Color.RED);
			statusLabel1.setText("The Attempt failed");

		}

	}

	/**
	 * The EktLogin method is used to log in to the EKT system.
	 *
	 * @param event         The mouse event that triggered the method.
	 * @param subscribernum The ComboBox containing the subscriber number.
	 * @param status        The label used to display the status of the login
	 *                      attempt.
	 * @throws Exception if there is an error while communicating with the server.
	 * @author Yovel
	 */

	public static void EktLogin(MouseEvent event, ComboBox<String> subscribernum, Label status) throws Exception {
		String subscribernumber = (String) subscribernum.getValue();
		MissionPack obj = new MissionPack(Mission.EKT_LOGIN, null, subscribernumber);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.EKT_LOGIN_SUCCESS)) {
			String[] information = (String[]) obj.getInformation();
			IDENTIFY_USER(event, information[0], information[1], status);
		} else {

			status.setText("The Attempt failed");

		}

	}

	/**
	 * The initiateActivation method is used to initiate the activation process for
	 * a promotion.
	 * 
	 * @param areacombo     The ComboBox containing the area for the promotion.
	 * @param templatecombo The ComboBox containing the template for the promotion.
	 * @param statusSale    The Label used to display the status of the activation
	 *                      attempt.
	 * @author Yovel
	 * @param endingSaleTime 
	 * @param startingSaleTime 
	 */
	public static void initiateActivation(ComboBox<String> areacombo, ComboBox<String> templatecombo,
			Label statusSale, int startingSaleTime, int endingSaleTime) {

		Object[] saledetails = { areacombo.getValue(), templatecombo.getValue(),startingSaleTime,endingSaleTime };
		MissionPack obj = new MissionPack(Mission.DEFINE_TEMPLATE, null, saledetails);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.DEFINE_TEMPLATE_SUCCESS)) {
			statusSale.setTextFill(Color.GREEN);
			statusSale.setText(
					"The promotions on the products \n were successfully transferred\n to activation \n by the employee of the\n marketing department\n who is responsible for\n the promotion area");
		} else {
			statusSale.setTextFill(Color.RED);
			statusSale.setText("The Attempt failed");

		}

	}

	/**
	 * The FindSubscriberNumber method is used to find all subscriber numbers.
	 *
	 * @return a list of subscriber numbers if the attempt was successful, null
	 *         otherwise.
	 * @author Yovel
	 */

	@SuppressWarnings("unchecked")
	public static List<String> FindSubscribernumber() {
		MissionPack obj = new MissionPack(Mission.FIND_SUBSCRIBER_NUMBERS, null, null);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.FIND_SUBSCRIBER_NUMBER_SUCCESS)) {
			System.out.println("The Attempt success ");
			return (List<String>) obj.getInformation();
		} else {

			System.out.println("The Attempt failed");
			return null;
		}

	}

	@SuppressWarnings("unchecked")
	/**
	 * The GET_ORDERS_REPORT method is used to get an orders report for a specific
	 * date and region.
	 *
	 * @param event         The mouse event that triggered the method.
	 * @param errorLabel    The label used to display an error message if the report
	 *                      could not be found.
	 * @param reportDetails The details of the report, including the date and
	 *                      region.
	 * @author Yovel
	 */
	public static void GET_ORDERS_REPORT(MouseEvent event, Label errorLabel, ArrayList<String> reportDetails) {
		MissionPack obj = new MissionPack(Mission.GET_MONTHLY_ORDERS_REPORT, null, reportDetails);
		ClientUI.chat.accept(obj);
		ViewOrdersReportScreenController.setDate(reportDetails.get(0) + " / " + reportDetails.get(1));
		ViewOrdersReportScreenController.setRegion(reportDetails.get(2));
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse() == Response.GET_MONTHLY_ORDERS_REPORT_FAILD) {
			errorLabel.setVisible(true);
			errorLabel.setText("No such report");
		} else {
			MissionPack task = new MissionPack(Mission.EXTRA_DETAILS_FOR_ORDER_REPORT, null, reportDetails);
			ClientUI.chat.accept(task);
			task = ClientUI.chat.getResponseFromServer();
			if (task.getResponse() == Response.EXTRA_DETAILS_FOR_ORDER_REPORT_SUCCESS) {
				((Node) event.getSource()).getScene().getWindow().hide();
				final Stage primaryStage = new Stage();
				ViewOrdersReportScreenController.setInformation(obj.getInformation());
				ViewOrdersReportScreenController
						.setInformationExtra((HashMap<String, ArrayList<String>>) task.getInformation());
				ViewOrdersReportScreenController showreportScreen = new ViewOrdersReportScreenController();
				showreportScreen.start(primaryStage);
			}

		}
	}

	/**
	 * The GET_STOCK_REPORT method is used to get a stock report for a specific date
	 * and facility.
	 *
	 * @param event         The mouse event that triggered the method.
	 * @param errorLabel    The label used to display an error message if the report
	 *                      could not be found.
	 * @param reportDetails The details of the report, including the date and
	 *                      facility.
	 * @author Yovel
	 */
	public static void GET_STOCK_REPORT(MouseEvent event, Label errorLabel, ArrayList<String> reportDetails) {
		MissionPack obj = new MissionPack(Mission.GET_MONTHLY_STOCK_REPORT, null, reportDetails);
		ClientUI.chat.accept(obj);
		ViewStockReportScreenController.setDate(reportDetails.get(0) + "/" + reportDetails.get(1));
		ViewStockReportScreenController.setFacility(Facility.valueOf(reportDetails.get(2)));
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse() == Response.GET_MONTHLY_STOCK_REPORT_FAILD) {
			errorLabel.setVisible(true);
			errorLabel.setText("No such report");
		} else {
			MissionPack task = new MissionPack(Mission.EXTRA_DETAILS_FOR_STOCK_REPORT, null, reportDetails);
			ClientUI.chat.accept(task);
			task = ClientUI.chat.getResponseFromServer();
			if (task.getResponse() == Response.EXTRA_DETAILS_FOR_STOCK_REPORT_SUCCESS) {
				((Node) event.getSource()).getScene().getWindow().hide(); // hiding primary window
				final Stage primaryStage = new Stage();
				ViewStockReportScreenController.setInformation(obj.getInformation());
				ViewStockReportScreenController.setExtraInformation((HashMap<String, String>) task.getInformation());
				ViewStockReportScreenController showreportScreen = new ViewStockReportScreenController();
				showreportScreen.start(primaryStage);
			}
		}
	}

	/**
	 * The GET_CUSTOMER_REPORT method is used to get a customer report for a
	 * specific date and region.
	 *
	 * @param event         The mouse event that triggered the method.
	 * @param errorLabel    The label used to display an error message if the report
	 *                      could not be found.
	 * @param reportDetails The details of the report, including the date and
	 *                      region.
	 * @author Yovel
	 */
	public static void GET_CUSTOMER_REPORT(MouseEvent event, Label errorLabel, ArrayList<String> reportDetails) {
		MissionPack obj = new MissionPack(Mission.GET_MONTHLY_CUSTOMER_REPORT, null, reportDetails);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse() == Response.GET_MONTHLY_CUSTOMER_REPORT_FAILD) {
			errorLabel.setVisible(true);
			errorLabel.setText("No such report");
		} else {
			MissionPack task = new MissionPack(Mission.EXTRA_DETAILS_FOR_CUSTOMER_REPORT, null, reportDetails);
			ClientUI.chat.accept(task);
			task = ClientUI.chat.getResponseFromServer();
			if (task.getResponse() == Response.EXTRA_DETAILS_FOR_CUSTOMER_REPORT_SUCCESS) {
				((Node) event.getSource()).getScene().getWindow().hide(); // hiding primary window
				final Stage primaryStage = new Stage();
				ViewCustomerReportController.setDate(reportDetails.get(0) + "/" + reportDetails.get(1));
				ViewCustomerReportController.setRegion(reportDetails.get(2));
				ArrayList<String> details = (ArrayList<String>) task.getInformation();
				ViewCustomerReportController.setBestCustomer(details.get(3));
				ViewCustomerReportController.setBestEkrut(details.get(2));
				ViewCustomerReportController.setConfig(details.get(1));
				ViewCustomerReportController.setNumOfCancelOrder(details.get(0));
				ViewCustomerReportController.setInformation((ArrayList<Integer>) obj.getInformation());
				ViewCustomerReportController showreportScreen = new ViewCustomerReportController();
				showreportScreen.start(primaryStage);
			}
		}
	}

	/**
	 * The logOut method is used to log out a user from the system.
	 *
	 * @param username The username of the user that is logging out.
	 * @author Yovel
	 */
	public static void logOut(String username) {
		MissionPack obj = new MissionPack(Mission.LOG_OUT, null, username);
		ClientUI.chat.accept(obj);
	}

	/**
	 * The CREATE_LOCAL_ORDER method is used to create a local order for a specific
	 * store.
	 *
	 * @param store The store for which the local order is being created.
	 * @param event the event that triggered the method.
	 * @throws IOException if the ShoppingWindowController fails to open
	 * @author Yovel
	 */
	public static void CREATE_LOCAL_ORDER(String store, ActionEvent event) throws IOException {
		MissionPack obj = new MissionPack(Mission.CREATE_LOCAL_ORDER, null, store);
		ClientUI.chat.accept(obj);
		final Stage primaryStage = new Stage();
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.LOCAL_ORDER_OPENED)) {
			ShoppingWindowController.setProducts((ProductInStock[]) obj.getInformation());
			ShoppingWindowController.setFacility(store);
			ShoppingWindowController shoppingWindowController = new ShoppingWindowController();
			((Node) event.getSource()).getScene().getWindow().hide();
			shoppingWindowController.start(primaryStage);
		}
	}

	/**
	 * The CREATE_REMOTE_ORDER method is used to create a remote order for a
	 * specific warehouse.
	 *
	 * @param event The event that triggered the method.
	 * @throws IOException if the ShoppingWindowController fails to open
	 * @author Yovel
	 */
	public static void CREATE_REMOTE_ORDER(ActionEvent event) throws IOException {
		MissionPack obj = new MissionPack(Mission.CREATE_REMOTE_ORDER, null, null);
		ClientUI.chat.accept(obj);
		final Stage primaryStage = new Stage();
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.REMOTE_ORDER_OPENED)) {
			ShoppingWindowController.setProducts((ProductInStock[]) obj.getInformation());
			ShoppingWindowController.setFacility("WAREHOUSE");
			ShoppingWindowController shoppingWindowController = new ShoppingWindowController();
			((Node) event.getSource()).getScene().getWindow().hide();
			shoppingWindowController.start(primaryStage);
		}
	}

	/**
	 * The getPaymentData method is used to retrieve payment data for a specific
	 * user. It takes in an ActionEvent and a String username as input arguments.
	 *
	 * The method creates a new instance of the MissionPack class with the mission
	 * type GET_PAYMENT_DATA and a null information object, and the provided
	 * username. Then it calls the accept method on the ClientUI chat object with
	 * the newly created MissionPack object. The method then waits for a response
	 * from the server and if the response is PAYMENT_DATA_SUCCESS, it extracts the
	 * payment data from the response and sets it to the PaymentWindowController
	 * class. It then creates a new stage, hides the current window, creates an
	 * instance of PaymentWindowController and calls its start method.
	 *
	 * @author Yovel
	 * @param event    the event that triggers the method
	 * @param username the username of the user for whom the payment data is
	 *                 retrieved
	 * @throws IOException if an I/O error occurs
	 */

	public static void getPaymentData(ActionEvent event, String username) throws IOException {
		MissionPack obj = new MissionPack(Mission.GET_PAYMENT_DATA, null, username);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.PAYMENT_DATA_SUCCESS)) {
			String[] data = (String[]) obj.getInformation();
			PaymentWindowController.setCreditCard(data[0]);
			PaymentWindowController.setExpirationDate(data[1]);
			PaymentWindowController.setCvv(data[2]);
			PaymentWindowController.setId(data[3]);

			final Stage primaryStage = new Stage();
			((Node) event.getSource()).getScene().getWindow().hide();
			PaymentWindowController payment = new PaymentWindowController();
			payment.start(primaryStage);
		}

	}

	/**
	 * @author Yovel The GET_REQUESTED_CUSTOMERS method is used to retrieve a list
	 *         of requested customers from the server. It takes in two input
	 *         arguments, an ObservableList of User objects and a TableView of User
	 *         objects.
	 *
	 *         The method creates a new instance of the MissionPack class with the
	 *         mission type GET_REQUESTED_TO_BE_COSTOMERS and a null information
	 *         object. Then it calls the accept method on the ClientUI chat object
	 *         with the newly created MissionPack object. The method then waits for
	 *         a response from the server and if the response is
	 *         REQUESTED_TO_BE_COSTOMERS_SUCCESS, it clears the listView and fills
	 *         it with the requested customers retrieved from the server.
	 *
	 * @param listView an ObservableList of User objects that will be filled with
	 *                 the requested customers
	 * @param region   a TableView of User objects that will be filled with the
	 *                 requested customers
	 * @throws IOException if an I/O error occurs
	 */

	public static void GET_REQUESTED_CUSTOMERS(final ObservableList<User> listView, final String region)
			throws IOException {
		MissionPack obj = new MissionPack(Mission.GET_REQUESTED_TO_BE_COSTOMERS, null, region);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.REQUESTED_TO_BE_COSTOMERS_SUCCESS)) {
			listView.clear();
			List<User> list = (List<User>) obj.getInformation();
			for (int i = 0; i < list.size(); ++i) {
				listView.add(list.get(i));
			}
		}
	}

	/**
	 * @author Yovel The closeWindow method is used for logging out from specified
	 *         user screen, and disconnect it from server
	 * @param username username of the logged on user (String)
	 */
	public static void closeWindow(String username) {
		ClientMissionHandler.logOut(username);
		ClientMissionHandler.DISCONNECT_FROM_SERVER();
		Platform.exit();
		System.exit(0);
	}

	/**
	 * @author Yovel The closeWindowForTimer is used or logging out from specified
	 *         user screen because the user cross the limit of the time he can stay
	 *         logged on
	 * @param username username of the logged on user (String)
	 */
	public static void closeWindowForTimer(String username) {
		ClientMissionHandler.logOut(username);
	}

	/**
	 * The updateStock method updates the stock of products in the system. @ author
	 * Yovel
	 * 
	 * @param event        the event that triggered this method
	 * @param shoppingCart the list of products in the customer's shopping cart
	 * @param error        the label used to display error messages
	 * @throws IOException if there is a problem communicating with the server
	 * @return the response from the server indicating the success or failure of the
	 *         stock update
	 */
	public static Response updateStock(ActionEvent event, ObservableList<ProductInCart> shoppingCart, Label error)
			throws IOException {
		List<ProductInCart> products = new ArrayList<>();
		for (int i = 0; i < shoppingCart.size(); i++) {
			products.add(shoppingCart.get(i));
		}
		String deliveryOrPickup = TheEndController.getPickupOrDelivery();
		String facility;
		if (MainCustomerPageController.getConfig().equals("OL") && deliveryOrPickup.equals("Pickup"))
			facility = TheEndController.getFacility();
		else
			facility = MainCustomerPageController.getFacility();
		String facilityToPickup = TheEndController.getFacility();
		String email = MainCustomerPageController.getEmail();
		String region = MainCustomerPageController.getRegion();
		String username = MainCustomerPageController.getUsername();
		String phone = MainCustomerPageController.getPhone();
		String role = MainCustomerPageController.getRole();
		String address = TheEndController.getDeliveryCity() + "," + TheEndController.getDeliveryAddress();
		String subscriberFirstPurchase = MainCustomerPageController.getSubscriberFirstPurchase();
		Object[] arr = { products, facility, deliveryOrPickup, email, region, username, phone, role, address,
				subscriberFirstPurchase, facilityToPickup };
		MissionPack obj = new MissionPack(Mission.UPDATE_STOCK, null, arr);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		System.out.println(obj.getResponse());
		if (obj.getResponse().equals(Response.STOCK_UPDATE_SUCCESS)) {
			if (deliveryOrPickup != null && deliveryOrPickup.equals("Pickup")) {
				TheEndController.setOrderNum((Integer) obj.getInformation());
			}
			final Stage primaryStage = new Stage();
			((Node) event.getSource()).getScene().getWindow().hide();
			TheEndController end = new TheEndController();
			end.start(primaryStage);
		} else {
			error.setText("There is not enough\nof the products you chose in " + facility);
		}
		return obj.getResponse();
	}

	/**
	 * The APPROVE_CUSTOMERS method approves a user to be a customer.
	 * 
	 * @author Yovel
	 * @param approvedUser the user to be approved as a customer
	 * @throws IOException if there is a problem communicating with the server
	 */
	public static void APPROVE_CUSTOMERS(User approvedUser) throws IOException {
		MissionPack obj = new MissionPack(Mission.APPROVE_TO_BE_CUSTOMER, null, approvedUser);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.APPROVED_TO_BE_COSTOMERS_SUCCESS)) {
			final Stage primaryStage = new Stage();
			popUpMsgController popUpMsg = new popUpMsgController();
			popUpMsgController.textToSet = "Congratulations! \n The user " + approvedUser.getUsername()
					+ " became a customer\n\n" + "\t\t\t\tSIMULATION\n An email was sent the email address: "
					+ approvedUser.getEmail() + "\n SMS was sent to the phone number: \n"
					+ "with the following content: Dear user application to be a customer approved" + "\r\n"
					+ "And you have access to purches in all EKrut machines :)";

			popUpMsg.start(primaryStage);
		}
	}

	/**
	 * The refreshDeliveryApproval method refreshes the delivery approval
	 * information for a user.
	 * 
	 * @author Yovel
	 * @param username     the username of the user whose delivery approval
	 *                     information is to be refreshed
	 * @param dataToTable  the data to Table where the delivery approval information
	 *                     will be displayed
	 * @param statusLabel1 the label used to display the status of the refresh
	 *                     operation
	 */
	public static void refreshDeliveryApproval(String username, final ObservableList<DeliveryInfo> dataToTable,
			Label statusLabel1) {
		MissionPack obj = new MissionPack(Mission.REFRESH_DELIVERY_APPROVAL, null, username);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.REFRESH_DELIVERY_SUCCESS)) {
			dataToTable.clear();
			@SuppressWarnings("unchecked")
			List<DeliveryInfo> list = (List<DeliveryInfo>) obj.getInformation();
			for (int i = 0; i < list.size(); i++) {
				dataToTable.add(list.get(i));
			}
		} else {
			statusLabel1.setText("The Attempt failed");
		}

	}

	/**
	 * The approveDeliveryFromClientSide method approves a delivery from the
	 * customer side.
	 * 
	 * @author Yovel
	 * @param selectedDelivery the delivery to be approved
	 * @param errorLbl         the label used to display error messages
	 */

	public static void approveDeliveryFromClientSide(DeliveryInfo selectedDelivery, Label errorLbl) {
		errorLbl.setText(null);
		MissionPack obj = new MissionPack(Mission.APPROVE_DELIVERY_FROM_CUSTOMER_SIDE, null, selectedDelivery);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.APPROVE_DELIVERY_SUCCESS)) {
			errorLbl.setTextFill(Color.CORNFLOWERBLUE);
			errorLbl.setText("Successfuly approved");
		} else {

			errorLbl.setText("The Attempt failed");
		}
	}

	/**
	 * The getSales method retrieves sales data for a specific region.
	 * 
	 * @author Yovel
	 * @param region the region for which sales data is to be retrieved
	 */

	public static void getSales(String region) {
		MissionPack obj = new MissionPack(Mission.GET_SALES, null, region);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		List<Sale> sales;
		if (obj.getResponse().equals(Response.GET_SALES_SUCCESS)) {
			sales = (List<Sale>) obj.getInformation();
			ShoppingWindowController.setSales(sales);
		} else {

		}

	}

	/**
	 * The refreshPickup method retrieves pickup information for a specific user and
	 * facility.
	 * 
	 * @author Yovel
	 * @param username    the username of the user whose pickup information is to be
	 *                    retrieved
	 * @param facility    the facility for which pickup information is to be
	 *                    retrieved
	 * @param dataToTable the data to Table where the pickup information will be
	 *                    displayed
	 * @param errorLbl    the label used to display error messages
	 */
	public static void refreshPickup(String username, String facility, ObservableList<PickupInfo> dataToTable,
			Label errorLbl) {
		String[] data = { username, facility };
		MissionPack obj = new MissionPack(Mission.REFRESH_PICKUP, null, data);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.REFRESH_PICKUP_SUCCESS)) {
			dataToTable.clear();
			@SuppressWarnings("unchecked")
			List<PickupInfo> list = (List<PickupInfo>) obj.getInformation();
			for (int i = 0; i < list.size(); i++) {
				dataToTable.add(list.get(i));
			}
		} else {
			errorLbl.setText("The Attempt failed");
		}

	}

	/**
	 * The pickupOrder method retrieves pickup order for a specific pickup
	 * information.
	 * 
	 * @author Yovel
	 * @param selectedPickup the pickup information of the order that is to be
	 *                       retrieved
	 * @param errorLbl       the label used to display error messages
	 */
	public static void pickupOrder(PickupInfo selectedPickup, Label errorLbl) {
		errorLbl.setText(null);
		MissionPack obj = new MissionPack(Mission.PICKUP_ORDER, null, selectedPickup);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.PICKUP_SUCCESS)) {
			errorLbl.setTextFill(Color.CORNFLOWERBLUE);
			errorLbl.setText("EK-OP is now working on your order");
		} else {

			errorLbl.setText("The Attempt failed");
		}

	}

	/**
	 * The addMonthlyBill method adds a monthly bill for a specific user.
	 * 
	 * @author Yovel
	 * @param username the username of the user for whom the bill is to be added
	 * @param total    the total cost of the bill
	 * @param errorLbl the label used to display error messages
	 */
	public static void addMonthlyBill(String username, double total, Label errorLbl) {
		Object[] data = { username, total };
		MissionPack obj = new MissionPack(Mission.ADD_BILL, null, data);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.BILL_NOT_ADDED)) {
			errorLbl.setText("The Attempt failed");
		}
	}

	/**
	 * The GET_REQUESTED_CUSTOMERS method retrieves a list of requested customers.
	 * 
	 * @author Yovel
	 * @param listView the listView where the requested customers will be displayed
	 * @throws IOException if there is a problem communicating with the server
	 */
	public static void GET_REQUESTED_CUSTOMERS(final ObservableList<User> listView) throws IOException {
		MissionPack obj = new MissionPack(Mission.GET_REQUESTED_TO_BE_COSTOMERS, null, null);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.REQUESTED_TO_BE_COSTOMERS_SUCCESS)) {
			listView.clear();
			List<User> list = (List<User>) obj.getInformation();
			for (int i = 0; i < list.size(); ++i) {
				listView.add(list.get(i));
			}
		}
	}

	/**
	 * The GET_DELIVERIES_REPORT method retrieves a monthly deliveries report.
	 *
	 * @author Yovel
	 * @param event         the mouse event that triggered the method
	 * @param errorLabel    the label used to display error messages
	 * @param reportDetails the details of the report to be retrieved
	 */
	@SuppressWarnings("unchecked")
	public static void GET_DELIVERIES_REPORT(MouseEvent event, Label errorLabel, ArrayList<String> reportDetails) {
		MissionPack obj = new MissionPack(Mission.GET_MONTHLY_DELIVERIES_REPORT, null, reportDetails);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		ChooseTimeReportCEOController.setRes(obj.getResponse());
		if (obj.getResponse() == Response.GET_MONTHLY_DELIVERIES_REPORT_FAILED) {
			errorLabel.setVisible(true);
			errorLabel.setText("No such report");
		} else {
			ViewDeliveriesReportScreenController
					.setInformation((HashMap<String, ArrayList<String>>) obj.getInformation());
		}
	}

	/**
	 * The CHECK_TRASH_HOLD method checks the inventory levels of products in a
	 * specific region and sends notifications if any products are below the
	 * threshold level.
	 *
	 * @author Yovel
	 * @param region   the region to check the inventory levels in
	 * @param listView the listView where the products with low inventory will be
	 *                 displayed
	 * @param flag     a flag to indicate whether to display a pop-up message or not
	 * @throws IOException if there is a problem communicating with the server
	 */
	public static void CHECK_TRASH_HOLD(String region, final ObservableList<ProductInStock> listView, boolean flag)
			throws IOException {
		MissionPack obj = new MissionPack(Mission.CHECK_THRES_HOLD_INVENTORY, null, region);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.CHECK_THRES_HOLD_INVENTORY_SUCCESS)) {
			ArrayList<ProductInStock> products = (ArrayList<ProductInStock>) obj.getInformation();
			MainScreenManagerController.products = products;
			if (listView != null) {
				listView.clear();
				List<ProductInStock> list = (List<ProductInStock>) obj.getInformation();
				for (int i = 0; i < list.size(); ++i) {
					listView.add(list.get(i));
				}
			}
			if (products.size() != 0) {
				MainScreenManagerController.isAppearPopUpMsg = true;
			} else {
				MainScreenManagerController.isAppearPopUpMsg = false;
			}
			if (flag && products.size() != 0 && !MainScreenManagerController.alreadyAppearPopUpMsg) {
				String str = products.toString().replace("[", "").replace("]", "").replace(", ", "");
				popUpMsgController.textToSet = "Email and SMS have been sent to the regional manager in region: "
						+ MainScreenManagerController.getRegion() + ".\n" + "SMS was sent to "
						+ MainScreenManagerController.getPhone() + "\nEmail was sent to "
						+ MainScreenManagerController.getEmail()
						+ "\nThe following products are below the threshold inventory level in your area:\n" + str;
				popUpMsgController popUp = new popUpMsgController();
				popUp.start(new Stage());
				MainScreenManagerController.alreadyAppearPopUpMsg = true;
			}
		}
	}

	/**
	 * The updateAValueTreshold method updates the minimum threshold inventory value
	 * for a specific product in a specific region
	 *
	 * @author Yovel
	 * @param data an ArrayList that contains the new threshold value and the
	 *             product's name and region
	 */
	public static void updateAValueTreshold(ArrayList<String> data) {
		MissionPack obj = new MissionPack(Mission.UPDATE_MINIMUM_THRESHOLD_INVENTORY_VALUE, null, data);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.UPDATE_MINIMUM_THRESHOLD_INVENTORY_VALUE_SUCCESS)) {
			EditThresholdLevelController.res = Response.UPDATE_MINIMUM_THRESHOLD_INVENTORY_VALUE_SUCCESS;
		}
	}

	/**
	 * @author Yovel This method is used to check a threshold value for a facility.
	 * @param facility the facility to check the threshold value for
	 */
	public static void checkAValueTreshold(String facility) {
		MissionPack obj = new MissionPack(Mission.PICK_THRESHOLD_INVENTORY_VALUE, null, facility);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.PICK_THRESHOLD_INVENTORY_VALUE_SUCCESS)) {
			EditThresholdLevelController.treshold = (int) obj.getInformation();
		}
	}

	/**
	 * This method is responsible for updating the status of a product in the
	 * inventory, if the product quantity is below the threshold level.
	 * 
	 * @author Yovel
	 * @param Item the ProductInStock object that holds the product information
	 */
	public static void Update_STATUS_TRASH_HOLD(ProductInStock Item) {
		MissionPack obj = new MissionPack(Mission.UPDATE_STATUS_THRES_HOLD_INVENTORY, null, Item);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.UPDATE_STATUS_THRES_HOLD_INVENTORY_SUCCESS)) {

		}
	}

	/**
	 * @author Yovel The method update the stock of a product in a specific facility
	 * @param item The product in stock object that contain the information of the
	 *             product and the stock after update
	 * @throws IOException in case there is a problem with the connection to the
	 *                     server
	 */
	public static void updateStockToProduct(ProductInStock item) throws IOException {
		MissionPack obj = new MissionPack(Mission.UPDATE_PRODUCT_STOCK_IN_FACILITY, null, item);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.UPDATE_PRODUCT_STOCK_IN_FACILITY_SUCCESS)) {

		}
	}

	/**
	 * @author Yovel The method retrieves a list of all the products in a specific
	 *         region that need to update their stock.
	 * @param region   the region we want to check
	 * @param listView the list view we want to update with the products
	 * @throws IOException
	 */
	public static void getProductsToUpdateInventory(String region, final ObservableList<ProductInStock> listView)
			throws IOException {
		MissionPack obj = new MissionPack(Mission.CHECK_PRODUCTS_NEED_TO_BE_UPDATE_STOCK, null, region);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.CHECK_PRODUCTS_NEED_TO_BE_UPDATE_STOCK_SUCCESS)) {
			ArrayList<ProductInStock> products = (ArrayList<ProductInStock>) obj.getInformation();
			if (listView != null) {
				listView.clear();
				List<ProductInStock> list = (List<ProductInStock>) obj.getInformation();
				for (int i = 0; i < list.size(); ++i) {
					listView.add(list.get(i));
				}
			}
		}
	}

	/**
	 * The method retrieves the phone number and the email address of the regional
	 * manager of the entered region.
	 * 
	 * @author Yovel
	 * @param region the region of the manager
	 */
	public static void checkDetailsFromRegionalManager(String region) throws IOException {
		MissionPack obj = new MissionPack(Mission.CHECK_DETAILS_OF_REGIONAL_MANAGER, null, region);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.CHECK_DETAILS_OF_REGIONAL_MANAGER_SUCCESS)) {
			ArrayList<String> managerData = (ArrayList<String>) obj.getInformation();
			UpdateInventoryController.setEmailManager(managerData.get(0));
			UpdateInventoryController.setPhoneNumberManager(managerData.get(1));
		}
	}

	/**
	 * @author Yovel
	 * 
	 *         This method updates the order details in the shopping cart. It gets
	 *         the current date and time, formats it to the pattern "yyyy/MM/dd",
	 *         and splits it into month and year. It then creates an order details
	 *         string by concatenating all the product details in the cart. The
	 *         method also gets the client ID and configuration from other
	 *         controllers. Finally, it creates a MissionPack object with the
	 *         UPDATE_ORDER mission, sends it to the client, and checks the
	 *         response. If the response is ORDER_FAILED, it sets an error message
	 *         on the error label.
	 *
	 * @param event        the event that triggered the method
	 * @param shoppingCart the observable list of products in the cart
	 * @param errorlbl     the error label on which to display any error messages
	 */
	public static void updateorder(ActionEvent event, ObservableList<ProductInCart> shoppingCart, Label errorlbl) {
		String facility = MainCustomerPageController.getFacility();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
		LocalDateTime now = LocalDateTime.now();
		String my_str = dtf.format(now);
		String[] dateStrings = my_str.split("/");
		String month = dateStrings[1];
		String year = dateStrings[0];
		String orderdetails = "";
		for (ProductInCart product : shoppingCart) {
			orderdetails += product.toString() + " ";
		}
		String clientId = PaymentWindowController.getId();
		String config = MainCustomerPageController.getConfig();
		Object[] details = { orderdetails, facility, month, year, clientId, config };
		MissionPack obj = new MissionPack(Mission.UPDATE_ORDER, null, details);
		ClientUI.chat.accept(obj);
		obj = ClientUI.chat.getResponseFromServer();
		if (obj.getResponse().equals(Response.ORDER_FAILED)) {
			errorlbl.setText("Failed to update order");
		}
	}

}