
package entities;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import common_class.MissionPack;
import ocsf.server.ConnectionToClient;
import server.ServerMissionAnalyze;
/**
 * This class is responsible for connecting to a database and providing a connection to the other parts of the program.
 * It makes use of the Singleton pattern, ensuring that only one instance of the connector is used throughout the program.
 *
 * @author Yovel
 */

public class DatabaseConnector {

	private static DatabaseConnector dataBaseConnector = null;
	private Connection connection = null;
	private boolean isConnected = false;
	private List<String> connectionDetailsList = new ArrayList<>();

	/**
	 * private constructor to enforce singleton pattern
	 */
	private DatabaseConnector() {
	}

	/**
	 * Returns the single instance of the DatabaseConnector
	 *
	 * @return the single instance of the DatabaseConnector
	 */
	public static DatabaseConnector getDatabaseConnectorInstance() {
		if (dataBaseConnector == null) {
			dataBaseConnector = new DatabaseConnector();
		}
		return dataBaseConnector;
	}

	/**
	 * Returns the current connection to the database, creating a new connection if one does not already exist.
	 *
	 * @return the current connection to the database
	 */
	public Connection getConnection() {
		if (connection == null) {
			configDriver();
			connect();
		}
		return connection;
	}

	/**
	 * Parses the data received from the client, analyzes it and performs the necessary actions
	 *
	 * @param obj  the MissionPack object containing the data
	 * @param client  the client that sent the data
	 * @throws IOException
	 */
	public static void parsingToData(MissionPack obj, ConnectionToClient client) throws IOException {
		try {
			ServerMissionAnalyze.MissionsAnalyze(obj, client);
			System.out.println("parsing");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Connects to the database using the connection details provided.
	 *
	 * @return a string indicating the success or failure of the connection
	 */
	public String connect() {
		StringBuffer buff = new StringBuffer();
		buff.append(configDriver());
		if (buff.toString().equals("\nDriver definition failed\n"))
			return buff.toString();
		// add check if length smaller than 4
		if (connectionDetailsList.size() == 4) {
			String ip = connectionDetailsList.get(0);
			String dbName = connectionDetailsList.get(1);
			String dbUsername = connectionDetailsList.get(2);
			String dbPassword = connectionDetailsList.get(3);
			connectToDatebase(buff, ip, dbName, dbUsername, dbPassword);
		} else {
			buff.append("missing arguments");
		}
		return buff.toString();
	}

	/**
	 * Sets the connection details to be used when connecting to the database
	 *
	 * @param detailsList the list of connection details
	 */
	public void setConnectionDetailsList(List<String> detailsList) {
		for (String currentDetail : detailsList) {
			connectionDetailsList.add(currentDetail);
		}
	}

	/**
	 * Disconnects from the current database connection
	 *
	 * @return true if the disconnection was successful, false otherwise
	 */
	public boolean disconnect() {
		if (isConnected) {
			if (connection != null) {
				try {
					connection.close();
					connection = null;
				} catch (SQLException e) {
					return false;
				}
			}
		}
		isConnected = false;
		return true;
	}

	/**
	 * Connects to the database using the provided connection details
	 *
	 * @param buff a StringBuffer to store the result of the connection
	 * @param ip the IP address of the database
	 * @param dbName the name of the database
	 * @param dbUsername the username to use when connecting to the database
	 * @param dbPassword the password to use when connecting to the database
	 */
	private void connectToDatebase(StringBuffer buff, String ip, String dbName, String dbUsername, String dbPassword) {
		try {
			connection = DriverManager.getConnection(dbName, dbUsername, dbPassword);
			buff.append("\nDatabase connection succeeded!\n");
			isConnected = true;
		} catch (SQLException e) {
			buff.append("\nDatabase connection failed!\n");
			isConnected = false;
		}
	}

	/**
	 * Configures the driver for the JDBC API
	 *
	 * @return a string indicating the success or failure of the driver configuration
	 */
	private String configDriver() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			return "\nDriver definition succeed\n";
		} catch (Exception ex) {
			return "\nDriver definition failed\n";
		}
	}

	/**
	 * Clears the connection details list
	 */
	public void clearConnectionDetailsList() {
		connectionDetailsList.clear();
	}
}