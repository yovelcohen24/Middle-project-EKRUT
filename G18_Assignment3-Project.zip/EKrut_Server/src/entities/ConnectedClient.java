
package entities;

import common_enums.ClientStatus;
/**
* This class represents a connected client, which includes the client's IP, host, and status.
*
* @author Yovel
*/
public class ConnectedClient {
	
	private String ip;
	private String host;
	private ClientStatus status;
	
	/**
	* Constructs a new ConnectedClient with the specified IP, host, and status.
	*
	* @param ip the IP address of the client
	* @param host the hostname of the client
	* @param status the status of the client
	*/
	public ConnectedClient(String ip, String host, ClientStatus status) {
		this.ip = ip;
		this.host = host;
		this.status = status;
	}

	/**
	* Sets the IP address of the client.
	*
	* @param ip the IP address of the client
	*/
	public void setIp(String ip) {
		this.ip = ip;
	}

	/**
	* Returns the IP address of the client.
	*
	* @return the IP address of the client
	*/
	public String getIp() {
		return ip;
	}

	/**
	* Sets the hostname of the client.
	*
	* @param host the hostname of the client
	*/
	public void setHost(String host) {
		this.host = host;
	}

	/**
	* Returns the hostname of the client.
	*
	* @return the hostname of the client
	*/
	public String getHost() {
		return host;
	}

	/**
	* Sets the status of the client.
	*
	* @param status the status of the client
	*/
	public void setStatus(ClientStatus status) {
		this.status = status;
	}

	/**
	* Returns the status of the client.
	*
	* @return the status of the client
	*/
	public ClientStatus getStatus() {
		return status;
	}
	
	/**
	* Returns a string representation of the client, including the IP, host, and status.
	*
	* @return a string representation of the client
	*/
	@Override
	public String toString() {
		return "[ip=" + ip + ", host=" + host + ", status=" + status + "]";
	}
}
