package guiServerControllers;

import java.io.IOException;
import javafx.application.Application;
import javafx.stage.Stage;
import server.ServerConfiguration;

public class ServerUI extends Application {
	static ServerConfiguration sv;

	/**
	 * The main method launches the JavaFX application.
	 *
	 * @param args the command line arguments
	 * @throws Exception if an error occurs
	 * @author Elroei
	 */
	public static void main(String[] args) throws Exception {
		launch(args);
	}

	public void start(Stage primaryStage) throws Exception {
		ServerController serverGui = new ServerController();
		serverGui.start(primaryStage);
	}

	/**
	 *
	 * 
	 * @author Maayan
	 * @param p port number to listen on This method runs a server on the provided
	 *          port number. It first attempts to parse the given port number as an
	 *          integer, and sets the port variable to that value. If an exception
	 *          is thrown during the parsing, an error message is printed. The
	 *          method then creates a new ServerConfiguration object, passing in the
	 *          port variable as an argument. The listen() method of the
	 *          ServerConfiguration object is then called, which starts listening
	 *          for connections on the specified port. If an exception is thrown
	 *          during the listening process, an error message is printed.
	 */
	public static void runServer(String p) {
		int port = 0; // Port to listen on

		try {
			port = Integer.parseInt(p); // Set port to 5555

		} catch (Throwable t) {
			System.out.println("ERROR - Could not connect!");
		}

		sv = new ServerConfiguration(port);

		try {
			sv.listen(); // Start listening for connections
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("ERROR - Could not listen for clients!");
		}
	}

	/**
	 * The disconnect method stops the server from listening for new connections and
	 * closes existing connections.
	 *
	 */
	public static void disconnect() {
		if (sv == null)
			sv.stopListening();
		else
			try {
				sv.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		System.out.println("Server Disconnected");
	}
}
