package guiServerControllers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;

import common_class.MissionPack;
import common_class.Time;
import common_enums.Facility;
import common_enums.Mission;

import java.io.IOException;
import java.io.PrintStream;
import java.net.URL;
import java.sql.SQLException;

import entities.ConnectedClient;
import entities.DatabaseConnector;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import server.QueryExecutor;
import server.ServerConfiguration;
import server.ServerMissionAnalyze;
/**
 * The ServerController class is the main controller class for the Server GUI.
 * It handles all the events and actions that occur in the Server GUI screen.
 * 
 * @author Maayan
 */
public class ServerController implements Initializable {
	
	@FXML
	private Button BTNImport;

	@FXML
	private TextField DBNameField;

	@FXML
	private PasswordField DBPasswordTextField;

	@FXML
	private TextField DBUserTextField;

	@FXML
	private TextField IPTextField;

	@FXML
	private Button connectButton;

	@FXML
	private TableView<ConnectedClient> connectionTable;

	@FXML
	private TextArea consoleField;

	@FXML
	private Button disconnectButton;

	@FXML
	private TableColumn<ConnectedClient, String> hostCol;

	@FXML
	private TableColumn<ConnectedClient, String> ipCol;

	@FXML
	private TextField portTextField;

	@FXML
	private TableColumn<ConnectedClient, String> statusCol;

	PrintStream replaceConsole;

	static ObservableList<ConnectedClient> listView = FXCollections.observableArrayList();

	public static ObservableList<ConnectedClient> getListView() {
		return listView;
	}

	public static void setListView(ObservableList<ConnectedClient> listView) {
		ServerController.listView = listView;
	}

	/**
     * The start method initializes and displays the Server GUI screen.
     * It loads the fxml file for the screen, sets the icon, title, scene, and sets the on close request event.
     * @author Elroei
     */
	public void start(final Stage primaryStage) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("/guiServerScreens/ServerScreen.fxml"));
		primaryStage.getIcons().add(new Image(ServerController.class.getResourceAsStream("/pictures/ekrutIcon.png")));
		Scene scene = new Scene(root);
		primaryStage.setTitle("E-Krut");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);
		primaryStage.setOnCloseRequest(e -> {
			Platform.exit();
			System.exit(0);
		});
	}
	/**
     * The clickOnConnect method handles the event when the user clicks on the connect button.
     * It runs the server on the specified port, gets the connection details from the text fields,
     * and tries to connect to the database. If the connection is successful, it generates monthly reports.
     *
     * @param event the mouse event that triggers the method
    
     */
	@FXML
	void clickOnConnect(MouseEvent event) {
		List<String> detailsList = new ArrayList<>();
		ServerUI.runServer(portTextField.getText());
		String ip = IPTextField.getText();
		String DBName = DBNameField.getText();
		String DBUserName = DBUserTextField.getText();
		String password = DBPasswordTextField.getText();
		if ((ip != null) && (DBName != null) && (DBUserName != null) && (password != null)) {
			detailsList.add(IPTextField.getText());
			detailsList.add(DBNameField.getText());
			detailsList.add(DBUserTextField.getText());
			detailsList.add(DBPasswordTextField.getText());
			DatabaseConnector.getDatabaseConnectorInstance().setConnectionDetailsList(detailsList);
		}
		System.out.println(DatabaseConnector.getDatabaseConnectorInstance().connect());
		connectButton.setDisable(true);
		disconnectButton.setDisable(false);
		disableDataInput(true);
		if (DatabaseConnector.getDatabaseConnectorInstance().connect().contains("\nDriver definition succeed\n\nDatabase connection succeeded!\n")) {
			ArrayList<String> endOfMonthDate = Time.getCurrentMonthAndYearOnlyIfItIsTheEndOfTheMonth();
			if (endOfMonthDate != null) {
				for (Facility currentFacility : Facility.values()) {
					QueryExecutor.generateMonthlyStockReport(
							new ArrayList<String>(Arrays.asList(endOfMonthDate.get(0), endOfMonthDate.get(1),
									currentFacility.toString())),
							DatabaseConnector.getDatabaseConnectorInstance().getConnection());
					QueryExecutor.generateMonthlyOrderReport(
							new ArrayList<String>(Arrays.asList(endOfMonthDate.get(0), endOfMonthDate.get(1),
									currentFacility.toString())),
							DatabaseConnector.getDatabaseConnectorInstance().getConnection());
					QueryExecutor.generateMonthlyCustomerReport(
							new ArrayList<String>(Arrays.asList(endOfMonthDate.get(0), endOfMonthDate.get(1),
									currentFacility.toString())),
							DatabaseConnector.getDatabaseConnectorInstance().getConnection());
				}
			}

		}

	}
	/**
     * The clickOnDisconnect method handles the event when the user clicks on the disconnect button.
     * It disconnects the server, clears the connection details, disables the disconnect button,
     * enables the connect button, and clears the connection table.
     *
     * @param event the mouse event that triggers the method
     */
	@FXML
	void clickOnDisconnect(MouseEvent event) {
		ServerUI.disconnect();
		DatabaseConnector.getDatabaseConnectorInstance().clearConnectionDetailsList();
		disconnectButton.setDisable(true);
		connectButton.setDisable(false);
		disableDataInput(false);
		connectionTable.getItems().clear();
	}
	/**
     * The disableDataInput method sets the disable property of the input fields.
     *
     * @param Condition the condition to set the disable property
 
     */
	void disableDataInput(boolean Condition) {
		portTextField.setDisable(Condition);
		IPTextField.setDisable(Condition);
		DBNameField.setDisable(Condition);
		DBUserTextField.setDisable(Condition);
		DBPasswordTextField.setDisable(Condition);
	}
	/**
     * The setTableColumns method sets the cell value factories of the columns in the connection table.
    
     */
	private void setTableColumns() {
		ipCol.setCellValueFactory(new PropertyValueFactory<ConnectedClient, String>("ip"));
		hostCol.setCellValueFactory(new PropertyValueFactory<ConnectedClient, String>("host"));
		statusCol.setCellValueFactory(new PropertyValueFactory<ConnectedClient, String>("status"));
	}
	 /**
     * The consoleStreamIntoGUI method redirects the standard output and error streams to the Console class
     * which is used to display the messages in the console area of the GUI.
  
     */
	void consoleStreamIntoGUI() {
		replaceConsole = new PrintStream(new guiServerControllers.Console(consoleField));
		System.setOut(replaceConsole);
		System.setErr(replaceConsole);
	}
	/**
     * The initialize method is called by JavaFX when the FXML file is loaded.
     * It initializes the connection table, sets the default values for the input fields, and disables the disconnect button.
     *
     * @param location the location of the FXML file
     * @param resources the resources used by the FXML file
     */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// Initialize the table columns about the connected clients detail
		connectionTable.setItems(ServerConfiguration.getClientList());
		// Setting up our TableView columns
		setTableColumns();
		// Change output stream into the ServerGUI Console Area
		consoleStreamIntoGUI();
		IPTextField.setText("localhost");
		portTextField.setText("5555");
		DBNameField.setText("jdbc:mysql://localhost/ekrut?serverTimezone=IST");
		DBUserTextField.setText("root");
		DBPasswordTextField.setText("Aa123456");
		disconnectButton.setDisable(true);
	}
	 /**
     * The Import method is invoked when the user clicks on the Import button.
     * It creates a new MissionPack object with the import data mission, and then calls the MissionsAnalyze method of the ServerMissionAnalyze class.
     *The method imports the user information of our system (ekrut) from an external system.
     * @param event the action event that triggers the method
     * @throws IOException if an I/O error occurs
     */
	@FXML
	void Import(ActionEvent event) throws IOException {
		MissionPack obj = new MissionPack(Mission.IMPORT_DATA, null, null);
		try {
			ServerMissionAnalyze.MissionsAnalyze(obj, null);
		} catch (SQLException e) {
			System.out.println("Unable to import data");
		}

	}
}
