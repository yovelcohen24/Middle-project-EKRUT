package guiServerControllers;

import java.io.IOException;
import java.io.OutputStream;

import javafx.application.Platform;
import javafx.scene.control.TextArea;

/**
 * This class replaces the output stream into a TextArea within the GUI in the FXML file.
 * 
 * @author Yovel
 */
public class Console extends OutputStream {
    private TextArea console;

    /**
     * Constructor that takes the TextArea to display the output
     * 
     * @param console the TextArea to display the output
     */
    public Console(TextArea console) {
        this.console = console;
    }

    /**
     * Appends the given text to the TextArea
     * 
     * @param valueOf the text to append to the TextArea
     */
    public void appendText(String valueOf) {
        Platform.runLater(() -> console.appendText(valueOf));
    }

    /**
     * Override the write method to capture the output and append it to the TextArea
     * 
     * @param b the output to write
     * @throws IOException 
     */
    @Override
    public void write(int b) throws IOException {
        appendText(String.valueOf((char)b));
    }
}