package server;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import common_class.MissionPack;
import common_class.Util;
import common_entities.DeliveryInfo;
import common_entities.PickupInfo;
import common_entities.ProductInCart;
import common_entities.ProductInStock;
import common_entities.Sale;
import common_entities.Saletable;

import common_entities.User;
import common_enums.ClientStatus;
import common_enums.Facility;
import common_enums.Region;
import common_enums.Response;
import entities.ConnectedClient;
import javafx.collections.ObservableList;
import ocsf.server.ConnectionToClient;

public class QueryExecutor {

	  /**
     * The updateClientList method updates the list of connected clients based on the status of the client.
     *
     * @param obj the mission pack that contains information about the mission
     * @param client the connection to the client
     * @param connectionStatus the status of the connection
     * @author Elroei
     */
	public static void updateClientList(MissionPack obj, ConnectionToClient client, ClientStatus connectionStatus) {
		ObservableList<ConnectedClient> clientList = ServerConfiguration.getClientList();

		for (int i = 0; i < clientList.size(); i++) {
			/* Comparing clients by IP addresses */
			if (clientList.get(i).getIp().equals(client.getInetAddress().getHostAddress()))
				clientList.remove(i);
		}

		/*
		 * In both cases of Connect and Disconnected we will need to add Client into the
		 * list so this function covers both of them simultaneously
		 */

		boolean hasAdd = clientList.add(new ConnectedClient(client.getInetAddress().getHostAddress(),
				client.getInetAddress().getHostName(), connectionStatus));
		if (hasAdd)
			obj.setResponse(Response.UPDATE_CONNECTION_SUCCESS);
		else
			obj.setResponse(Response.UPDATE_CONNECTION_FAILD);
		ServerConfiguration.setClientList(clientList);

	}

	/**

	*This method is used to identify the user. It takes in two parameters, MissionPack object and connection object.
	*@param obj - MissionPack object that contains the information about the mission and its data.
*@param con - Connection object that is used to connect to the database
	*@throws SQLException - If there is an error in SQL query execution.
	*/
	public static void identifyUser(MissionPack obj, Connection con) throws SQLException {
		String[] data = (String[]) obj.getInformation();
		String username = data[0];
		String password = data[1];
		String role = null, phoneNumber = null, firstName = null, region = null, config = null, facility = null,
				email = null, subscriberFirstPurchase = null, isLoggedIn = null;
		String[] newData = new String[11];

		PreparedStatement ps = null;
		boolean exists = false;

		try {
			ps = con.prepareStatement(
					"SELECT users.username, password, role,phoneNumber,firstName,storeName,config,Region,email,subscriberFirstPurchase FROM ekrut.users;");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				if (rs.getString("username").equals(username) && rs.getString("password").equals(password)) {
					exists = true;
					role = rs.getString("role");
					phoneNumber = rs.getString("phoneNumber");
					firstName = rs.getString("firstName");
					region = rs.getString("Region");
					config = rs.getString("config");
					facility = rs.getString("storeName");
					email = rs.getString("email");
					subscriberFirstPurchase = rs.getString("subscriberFirstPurchase");
					// System.out.println(username+" "+role);
				}

			}
		} catch (SQLException sqlException) {
			System.out.println("Statement failure");
		}

		if (exists == true) {
			obj.setResponse(Response.LOGIN_SUCCEED);
			newData[0] = username;
			newData[1] = password;
			newData[2] = role;
			newData[3] = phoneNumber;
			newData[4] = firstName;
			newData[5] = region;
			newData[6] = config;
			newData[7] = facility;
			newData[8] = email;
			newData[9] = subscriberFirstPurchase;
			obj.setInformation(newData);
			try {
				ps = con.prepareStatement("UPDATE ekrut.users SET isLoggedIn=\"1\" WHERE username=?");
				ps.setString(1, username);
				ps.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
				obj.setResponse(Response.LOGIN_FAILED);
			}
		} else {
			obj.setResponse(Response.LOGIN_FAILED);
		}
	}

	/**

	*Method to find user in the database

	*@param obj MissionPack object containing information about the mission and data

	*@param connection Connection object to the database
	*/
	public static void findUser(MissionPack obj, Connection connection) {
		PreparedStatement ps = null;
		boolean NotExist = true;
		String username = (String) obj.getInformation();
		try {
			ps = connection.prepareStatement("SELECT users.username FROM ekrut.users ;");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				if (rs.getString("username").equals(username)) {
					obj.setInformation(username);
					obj.setResponse(Response.FIND_USER_IN_DATA_SUCCESS);
					System.out.println("Executing statement-FIND_USER_IN_DATA_SUCCESS");
					NotExist = false;
					break;
				}
			}
			if (NotExist) {
				obj.setResponse(Response.FIND_USER_IN_DATA_FAILED);
				System.out.println("Executing statement-FIND_USER_IN_DATA_FAILED");
			}

		} catch (SQLException sqlException) {
			System.out.println("Exception- Executing statement- new throws FIND_USER_IN_DATA_FAILED");
			obj.setResponse(Response.FIND_USER_IN_DATA_FAILED);
		}

	}

	/**

	*Method to add new customer to the database.

	*@param obj MissionPack object that contains the user's information.

	*@param con Connection object to connect to the database.
	*/	
	public static void AddingNewCustomer(MissionPack obj, Connection con) {
		PreparedStatement ps = null;
		String[] ouruser = (String[]) obj.getInformation();
		String username = ouruser[0];
		String password = "1234";
		String cardNumber = ouruser[1];
		String espirationDate = ouruser[2];
		String CVV = ouruser[3];

		String role1 = "RequsestToBeCustomer";
		String role2 = "customer";
		String role3 = "subscriber";
		try {
			ps = con.prepareStatement(
					"SELECT users.username,password,firstName,lastName,role,email,phoneNumber,isLoggedIn,storeName,id,creditCard,CVV,expirationDate,config,Region FROM ekrut.users ;");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				if (rs.getString("username").equals(username) && rs.getString("role") == null
						|| rs.getString("username").equals(username) && rs.getString("role").equals("NULL")
						|| rs.getString("username").equals(username) && rs.getString("role").equals("user")) {

					ps = con.prepareStatement("UPDATE ekrut.users SET role=\"RequsestToBeCustomer\" WHERE username=?");
					ps.setString(1, username);
					ps.executeUpdate();
					ps = con.prepareStatement("UPDATE ekrut.users SET creditCard=? WHERE username=?");
					ps.setString(1, cardNumber);
					ps.setString(2, username);
					ps.executeUpdate();
					ps = con.prepareStatement("UPDATE ekrut.users SET CVV=? WHERE username=?");
					ps.setString(1, CVV);
					ps.setString(2, username);
					ps.executeUpdate();
					ps = con.prepareStatement("UPDATE ekrut.users SET expirationDate=? WHERE username=?");
					ps.setString(1, espirationDate);
					ps.setString(2, username);
					ps.executeUpdate();
					obj.setInformation(ouruser);
					obj.setResponse(Response.ADD_CUSTOMER_DATA_SUCCESS);
					return;
				} else if (rs.getString("username").equals(username) && !(rs.getString("role").equals(role1))
						&& !(rs.getString("role").equals(role2)) && !(rs.getString("role").equals(role3))) {

					try {

						ps = con.prepareStatement(
								"INSERT INTO ekrut.users (username,password,firstName,lastName,role,email,phoneNumber,isLoggedIn,storeName,id,creditCard,CVV,expirationDate,config,Region) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);");
						ps.setString(1, username + "_customer");
						ps.setString(2, password);
						ps.setString(3, rs.getString(3));
						ps.setString(4, rs.getString(4));
						ps.setString(5, "RequsestToBeCustomer");
						ps.setString(6, rs.getString(6));
						ps.setString(7, rs.getString(7));
						ps.setString(8, "0");
						ps.setString(9, rs.getString(9));
						ps.setString(10, rs.getString(10));
						ps.setString(11, cardNumber);
						ps.setString(12, CVV);
						ps.setString(13, espirationDate);
						ps.setString(14, rs.getString(14));
						ps.setString(15, rs.getString(15));
						ps.executeUpdate();
						obj.setInformation(ouruser);
						obj.setResponse(Response.ADD_CUSTOMER_DATA_SUCCESS);
						return;
					} catch (Exception exception) {
						exception.printStackTrace();
						System.out.println("Exception-Executing statement-Add CUSTOMER_DATA_FAILD");
						obj.setResponse(Response.ADD_CUSTOMER_DATA_FAILD);
					}
				}

			}
			System.out.println("Exception-Executing statement-Add CUSTOMER_DATA_FAILD");
			obj.setResponse(Response.ADD_CUSTOMER_DATA_FAILD);

		} catch (Exception exception) {
			exception.printStackTrace();
			System.out.println("Exception-Executing statement-Add CUSTOMER_DATA_FAILD");
			obj.setResponse(Response.ADD_CUSTOMER_DATA_FAILD);
		}

	}

	/**

	This method changes the role of a user from "customer" to "subscriber". It takes in two arguments:
	an instance of MissionPack and an instance of Connection. It uses a PreparedStatement to query the
	"users" table in the "ekrut" database for a user with the role "customer" and the given username.
	

	*@param obj an instance of MissionPack which contains information and response.
	*@param con an instance of Connection to connect to the database.
	*/
	public static void changeToSubscriber(MissionPack obj, Connection con) {
		PreparedStatement ps = null;
		String role = "customer";
		boolean NotExist = true;
		String username = (String) obj.getInformation();

		try {
			ps = con.prepareStatement("SELECT users.username,role,email,phoneNumber,id FROM ekrut.users ;");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				if ((rs.getString("role")).equals(role) && (rs.getString("username")).equals(username)) {

					ps = con.prepareStatement("UPDATE ekrut.users SET role=\"subscriber\" WHERE username=?");
					ps.setString(1, username);
					ps.executeUpdate();
					ps = con.prepareStatement("UPDATE ekrut.users SET subscriberNumber=? WHERE username=?");
					ps.setString(1, rs.getString("id"));
					ps.setString(2, username);
					ps.executeUpdate();
					ps = con.prepareStatement("UPDATE ekrut.users SET subscriberFirstPurchase=? WHERE username=?");
					ps.setString(1, "0");
					ps.setString(2, username);
					ps.executeUpdate();
					String[] information = { rs.getString("email"), rs.getString("phoneNumber"),
							rs.getString("id") };
					obj.setInformation(information);
					obj.setResponse(Response.FROM_CUSTOMER_TO_SUBSCRIBER_SUCCESS);
					NotExist = false;
					break;
				}
			}
			if (NotExist) {
				obj.setResponse(Response.FROM_CUSTOMER_TO_SUBSCRIBER_FAILD);
				System.out.println("Executing statement-FROM_CUSTOMER_TO_SUBSCRIBER_FAILD");
			}

		} catch (SQLException sqlException) {
			System.out.println("Exception- Executing statement-FROM_CUSTOMER_TO_SUBSCRIBER_FAILD");
			obj.setResponse(Response.FROM_CUSTOMER_TO_SUBSCRIBER_FAILD);
		}

	}

	/**

	*This method is used to refresh the list of deliveries that are currently not approved.
	*@param obj -MissionPack object that contains the information about the delivery and the response of the method.
	*@param connection link Connection object that represents the connection to the database.
	*/
	public static void refreshDelivery(MissionPack obj, Connection connection) {
		PreparedStatement ps = null;
		List<DeliveryInfo> deliveryToBeApproved = new ArrayList<>();
		try {
			ps = connection.prepareStatement(
					"SELECT deliveries.numberOfDelivery,phoneNumber, email, address FROM ekrut.deliveries WHERE deliveryStatus='NOT_APPROVE' AND customerStatus='NOT_DELIVERED' AND region = ?;");
			ps.setString(1, (String) obj.getInformation());
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				DeliveryInfo delivery = new DeliveryInfo(rs.getString("phoneNumber"), rs.getInt("numberOfDelivery"),
						rs.getString("address"), rs.getString("email"));

				deliveryToBeApproved.add(delivery);
			}
			obj.setInformation(deliveryToBeApproved);
			obj.setResponse(Response.REFRESH_DELIVERY_SUCCESS);
		} catch (SQLException e) {
			e.printStackTrace();
			obj.setResponse(Response.REFRESH_DELIVERY_FAILED);
		}

	}

	/**

	*This method is used to approve a delivery.
	*@param obj of type MissionPack which contains the information of the delivery to be approved.
	*@param connection of type Connection, which is used to connect to the database.
	*The method updates the deliveryStatus of the delivery in the database to "APPROVE" if the delivery is not already approved.
	*The method sets the response of the obj as APPROVE_DELIVERY_SUCCESS if the delivery is approved successfully,
	*otherwise it sets the response as APPROVE_DELIVERY_FAILED.
	*/
	public static void approveDelivery(MissionPack obj, Connection connection) {
		PreparedStatement ps = null;
		DeliveryInfo inforation = (DeliveryInfo) obj.getInformation();
		if (checkNonAlreadyApproved(inforation.getNumberOfDelivery(), connection)) {
			try {
				ps = connection.prepareStatement(
						"UPDATE ekrut.deliveries SET deliveryStatus=\"APPROVE\" WHERE numberOfDelivery=?");
				ps.setInt(1, inforation.getNumberOfDelivery());
				ps.executeUpdate();
				obj.setResponse(Response.APPROVE_DELIVERY_SUCCESS);
			} catch (SQLException e) {
				e.printStackTrace();
				obj.setResponse(Response.APPROVE_DELIVERY_FAILED);
			}
		} else
			obj.setResponse(Response.APPROVE_DELIVERY_FAILED);

	}

	/**

	*This method changes the status of a delivery to 'FINISH' in the database.
	*@param obj A MissionPack object that contains the DeliveryInfo object with the number of the delivery to be changed.
	*@param connection A Connection object used to connect to the database.
	*/
	public static void changeStatus(MissionPack obj, Connection connection) {
		PreparedStatement ps = null;
		DeliveryInfo inforation = (DeliveryInfo) obj.getInformation();
		if (checkNonAlreadyChangeStatus(inforation.getNumberOfDelivery(), connection)) {
			try {
				ps = connection.prepareStatement(
						"UPDATE ekrut.deliveries SET deliveryStatus=\"FINISH\" WHERE numberOfDelivery=?");
				ps.setInt(1, inforation.getNumberOfDelivery());
				ps.executeUpdate();
				obj.setResponse(Response.CHANGE_STATUS_SUCCESS);
			} catch (SQLException e) {
				e.printStackTrace();
				obj.setResponse(Response.CHANGE_STATUS_FAILED);
			}
		} else
			obj.setResponse(Response.CHANGE_STATUS_FAILED);
	}

	/**

	*This method is used to refresh the deliveries that are approved and delivered to the store.
	*The method retrieves the deliveries that match the given region and have the deliveryStatus as 'APPROVE'
	*and the customerStatus as 'DELIVERED'
	*@param obj MissionPack object that holds the information and response of the method
	*@param connection Connection object to connect to the database
	*/
	public static void refreshDeliveryToStatus(MissionPack obj, Connection connection) {
		PreparedStatement ps = null;
		List<DeliveryInfo> deliveryToBeApproved = new ArrayList<>();
		try {
			ps = connection.prepareStatement(
					"SELECT deliveries.numberOfDelivery,phoneNumber, email, address FROM ekrut.deliveries WHERE deliveryStatus='APPROVE' AND customerStatus='DELIVERED' AND region = ?;");
			ps.setString(1, (String) obj.getInformation());
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				DeliveryInfo delivery = new DeliveryInfo(rs.getString("phoneNumber"), rs.getInt("numberOfDelivery"),
						rs.getString("address"), rs.getString("email"));

				deliveryToBeApproved.add(delivery);
			}
			obj.setInformation(deliveryToBeApproved);
			obj.setResponse(Response.REFRESH_DELIVERY_SUCCESS);
		} catch (SQLException e) {
			e.printStackTrace();
			obj.setResponse(Response.REFRESH_DELIVERY_FAILED);
		}

	}

	/**

	*This method checks whether the delivery is already approved or not.

	*@param numberOfDelivery int representing the number of delivery that needs to be checked.

	*@param con Connection object to connect to the database

	@return boolean indicating whether the delivery is already approved or not.
	*/
	private static boolean checkNonAlreadyApproved(int numberOfDelivery, Connection con) {
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(
					"SELECT numberOfDelivery FROM ekrut.deliveries  WHERE deliveryStatus='NOT_APPROVE' AND customerStatus='NOT_DELIVERED' AND numberOfDelivery = ?;");
			ps.setInt(1, numberOfDelivery);
			return ps.executeQuery().next();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}

	}

	/**
	 * Checks if a delivery has already had its status changed to "APPROVE" and "DELIVERED" by the customer.
	 * 
	 * @param numberOfDelivery The number of the delivery to check
	 * @param con A connection to the database
	 * @return true if the delivery's status has already been changed, false otherwise
	 */
	private static boolean checkNonAlreadyChangeStatus(int numberOfDelivery, Connection con) {
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(
					"SELECT numberOfDelivery FROM ekrut.deliveries  WHERE deliveryStatus='APPROVE' AND customerStatus='DELIVERED' AND numberOfDelivery = ?;");
			ps.setInt(1, numberOfDelivery);
			return ps.executeQuery().next();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}

	}

	/**
	 * EktLogin method is used to log a user into the system.
	 * The method takes in two parameters: a MissionPack object and a Connection object.
	 * It checks the role and subscriberNumber of user in the database and returns the username and password if the user is exist.
	 * Otherwise it sets the response of the obj to EKT_LOGIN_FAILED.
	 *
	 * @param obj, connection
	 */
	public static void EktLogin(MissionPack obj, Connection connection) {
		PreparedStatement ps = null;
		String role = "subscriber";
		boolean NotExist = true;
		String subscribernumber = (String) obj.getInformation();

		try {
			ps = connection.prepareStatement("SELECT users.username,password,role,subscriberNumber FROM ekrut.users ;");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				if ((rs.getString("role")).equals(role)
						&& (rs.getString("subscriberNumber")).equals(subscribernumber)) {

					String[] information = { rs.getString("username"), rs.getString("password") };
					obj.setInformation(information);
					obj.setResponse(Response.EKT_LOGIN_SUCCESS);
					NotExist = false;
					break;
				}
			}
			if (NotExist) {
				obj.setResponse(Response.EKT_LOGIN_FAILED);
				System.out.println("Executing statement-EKT_LOGIN_FAILED");
			}

		} catch (SQLException sqlException) {
			System.out.println("Exception- Executing statement-EKT_LOGIN_FAILED");
			obj.setResponse(Response.EKT_LOGIN_FAILED);
		}

	}

	/**
	 * FindSubscriberNumbers method is used to find the subscriber numbers of logged-out users in the system.

	 * It checks the role of users in the database and returns a list of subscriber numbers of logged-out users.
	 * @param obj, connection
	 */
	public static void FindSubscriberNumbers(MissionPack obj, Connection connection) {
		PreparedStatement ps = null;
		String role = "subscriber";
		boolean NotExist = true;
		List<String> numberofsubscriber = new ArrayList<String>();

		try {
			ps = connection
					.prepareStatement("SELECT users.role,subscriberNumber FROM ekrut.users;");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				if ((rs.getString("role")).equals(role)) {

					numberofsubscriber.add(rs.getString("subscriberNumber"));
					NotExist = false;
				}

			}
			if (NotExist) {
				obj.setResponse(Response.FIND_SUBSCRIBER_NUMBER_FAILED);
				System.out.println("Executing statement-FIND_SUBSCRIBER_NUMBER_FAILED");
			} else {
				obj.setInformation(numberofsubscriber);
				obj.setResponse(Response.FIND_SUBSCRIBER_NUMBER_SUCCESS);
			}

		} catch (SQLException sqlException) {
			System.out.println("Exception- Executing statement-FIND_SUBSCRIBER_NUMBER_FAILED");
			obj.setResponse(Response.FIND_SUBSCRIBER_NUMBER_FAILED);
		}

	}
	
	/**
	* This method is used to refresh the sales table. It retrieves information from the "sales" table
	* in the database where the status is 'READY' and the region is the same as the one provided in the MissionPack object.
	* @param connection The Connection object used to connect to the database.
	*/
	public static void refreshSalesTable(MissionPack obj, Connection connection) {
		PreparedStatement ps = null;
		List<Saletable> salesToBeRun = new ArrayList<>();
		try {
			ps = connection.prepareStatement(
					"SELECT sales.saleCode,description,productName FROM ekrut.sales WHERE status='READY' AND region = ?;");
			ps.setString(1, (String) obj.getInformation());
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Saletable sales = new Saletable(rs.getInt("saleCode"), rs.getString("productName"),
						rs.getString("description"));

				salesToBeRun.add(sales);
			}
			obj.setInformation(salesToBeRun);
			obj.setResponse(Response.REFRESH_SALES_TABLE_SUCCESS);
		} catch (SQLException e) {
			e.printStackTrace();
			obj.setResponse(Response.REFRESH_SALES_TABLE_FAILED);
		}

	}
	
	/**
	* This method is used to run a sale. It first checks if the sale has already been run by calling the checkNonAlreadyrunSales method 
	* and passing it the saleCode, region and the connection object.
	* @param connection The Connection object used to connect to the database.
	*/
	public static void runSales(MissionPack obj, Connection connection) {
		PreparedStatement ps = null;
		Saletable inforation = (Saletable) obj.getInformation();
		if (checkNonAlreadyrunSales(inforation.getSaleCode(), inforation.getRegion(), connection)) {
			try {
				ps = connection
						.prepareStatement("UPDATE ekrut.sales SET status=\"Active\" WHERE saleCode=? AND region = ?");
				ps.setInt(1, inforation.getSaleCode());
				ps.setString(2, inforation.getRegion());
				ps.executeUpdate();
				obj.setResponse(Response.RUN_SALE_SUCCESS);
			} catch (SQLException e) {
				e.printStackTrace();
				obj.setResponse(Response.RUN_SALE_FAILED);
			}
		} else
			obj.setResponse(Response.RUN_SALE_FAILED);

	}

	/**
	* This method is used to check if a sale has already been run. It retrieves information from the "sales" table
	* in the database where the status is 'READY' and the saleCode and region match the ones provided as parameters.
	* It returns a boolean value indicating whether the sale has already been run or not. 
	* @param saleCode The saleCode of the sale to be checked
	* @param region The region of the sale to be checked
	* @param con The Connection object used to connect to the database.
	* @return boolean value indicating whether the sale has already been run or not.
	*/
	private static boolean checkNonAlreadyrunSales(int saleCode, String region, Connection con) {
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(
					"SELECT sales.saleCode FROM ekrut.sales WHERE status='READY' AND saleCode = ? AND region = ?;");
			ps.setInt(1, saleCode);
			ps.setString(2, region);
			return ps.executeQuery().next();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}

	}
	
	/**
	 * This method is used to define a template for a sale.  
	 * If an error occurs, the response is set to DEFINE_TEMPLATE_FAILED and the error is printed to the console.
	 *
	 * @param obj The MissionPack object containing the region and description to be used in the query and where the response will be stored.
	 * @param connection The Connection object used to connect to the database.
	 */
	public static void defineTemplate(MissionPack obj, Connection connection) {
		PreparedStatement ps = null;
		Object[] oursales = (Object[]) obj.getInformation();
		String region = (String) oursales[0];
		String description = (String) oursales[1];
		int startingSaleTime=(Integer)oursales[2];
		int endingTime=(Integer)oursales[3];
		try {
			ps = connection.prepareStatement(
					"SELECT salesdepartment.saleCode,indexInArray,productName,discount,description FROM ekrut.salesdepartment WHERE  description = ? ;");
			ps.setString(1, description);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				try {

					ps = connection.prepareStatement(
							"INSERT INTO ekrut.sales (saleCode,indexInArray,productName,discount,description,region,status,startingTime,endingTime) VALUES (?,?,?,?,?,?,?,?,?);");
					ps.setInt(1, rs.getInt("saleCode"));
					ps.setString(2, rs.getString("indexInArray"));
					ps.setString(3, rs.getString("productName"));
					ps.setDouble(4, rs.getDouble("discount"));
					ps.setString(5, rs.getString("description"));
					ps.setString(6, region);
					ps.setString(7, "READY");
					ps.setInt(8, startingSaleTime);
					ps.setInt(9, endingTime);
					ps.executeUpdate();
					obj.setInformation(oursales);
					obj.setResponse(Response.DEFINE_TEMPLATE_SUCCESS);
				} catch (Exception exception) {
					exception.printStackTrace();
					System.out.println("Exception-Executing statement-DEFINE_TEMPLATE_FAILED");
					obj.setResponse(Response.DEFINE_TEMPLATE_FAILED);
				}
			}

		}

		catch (Exception exception) {
			exception.printStackTrace();
			System.out.println("Exception-Executing statement-DEFINE_TEMPLATE_FAILED");
			obj.setResponse(Response.DEFINE_TEMPLATE_FAILED);
		}

	}
	
	/**
	 * This method is used to get the orders report for a specific month, year and region. It retrieves the sum of the number of total orders and the store name from the "monthly_orders_reports" table
	 * in the database where the month, year and region match the ones provided in the MissionPack object's information field
	 * @param obj The MissionPack object containing the month, year and region to be used in the query and where the response and report details will be stored.
	 * @param con The Connection object used to connect to the database.
	 */
	public static void getOrdersReport(MissionPack obj, Connection con) {
		ArrayList<String> reportDetails = (ArrayList<String>) obj.getInformation();
		String month = reportDetails.get(0), year = reportDetails.get(1), region = reportDetails.get(2);
		HashMap<Facility, Integer> mapOfFacilities = new HashMap<>();
		int numOfTotalOrders = 0;
		Facility facility;
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(
					"SELECT SUM(ekrut.monthly_orders_reports.numOfTotalOrders), ekrut.monthly_orders_reports.store FROM ekrut.monthly_orders_reports  WHERE ekrut.monthly_orders_reports.month = ? AND ekrut.monthly_orders_reports.year = ? AND ekrut.monthly_orders_reports.region = ? GROUP BY ekrut.monthly_orders_reports.store");
			ps.setString(1, month);
			ps.setString(2, year);
			ps.setString(3, region);
			ResultSet rs = ps.executeQuery();
			boolean hasNext = rs.next();
			if (!hasNext)
				obj.setResponse(Response.GET_MONTHLY_ORDERS_REPORT_FAILD);
			else {
				while (hasNext) {
					facility = Facility.valueOf(rs.getString("store"));
					numOfTotalOrders = rs.getInt("SUM(ekrut.monthly_orders_reports.numOfTotalOrders)");
					mapOfFacilities.put(facility, numOfTotalOrders);
					hasNext = rs.next();
				}
				obj.setInformation(mapOfFacilities);
				obj.setResponse(Response.GET_MONTHLY_ORDERS_REPORT_SUCCESS);
			}
		} catch (SQLException e) {
			System.out.println("Statement for getting Monthly Incomes Report has failed!");
			obj.setResponse(Response.GET_MONTHLY_ORDERS_REPORT_FAILD);
		}
	}
	
	/**
	 * Retrieves stock report for given month, year and facility from database, stores it in a HashMap and set in MissionPack.
	 * If report can't be retrieved, sets response in MissionPack to GET_MONTHLY_STOCK_REPORT_FAILED.
	 * @param obj MissionPack object containing report details and storage
	 * @param con database connection
	 */
	public static void getStockReport(MissionPack obj, Connection con) {
		ArrayList<String> reportDetails = (ArrayList<String>) obj.getInformation();
		String month = reportDetails.get(0), year = reportDetails.get(1);
		Facility facility = Facility.valueOf(reportDetails.get(2));
		HashMap<String, Integer> mapOfProductStock = new HashMap<>();
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(
					"SELECT ProductName, numOfProductInStock FROM ekrut.monthly_stock_reports WHERE Facility = ? AND Month = ? AND Year = ?");
			ps.setString(1, facility.toString());
			ps.setString(2, month);
			ps.setString(3, year);
			ResultSet rs = ps.executeQuery();
			boolean hasNext = rs.next();
			if (!hasNext)
				obj.setResponse(Response.GET_MONTHLY_STOCK_REPORT_FAILD);
			else {
				while (hasNext) {
					mapOfProductStock.put(rs.getString("ProductName"), rs.getInt("numOfProductInStock"));
					hasNext = rs.next();
				}
				obj.setInformation(mapOfProductStock);
				obj.setResponse(Response.GET_MONTHLY_STOCK_REPORT_SUCCESS);
			}
		} catch (SQLException e) {
			System.out.println("Statement for getting Monthly Incomes Report has failed!");
			obj.setResponse(Response.GET_MONTHLY_STOCK_REPORT_FAILD);
		}
	}
	
	/**
	 * Retrieves customer report for given month, year and region from database, stores it in ArrayList and set in MissionPack.
	 * If report can't be retrieved, sets response in MissionPack to GET_MONTHLY_CUSTOMER_REPORT_FAILED.
	 * @param obj MissionPack object containing report details and storage
	 * @param con database connection
	 */
	public static void getCustomerReport(MissionPack obj, Connection con) {
		ArrayList<String> reportDetails = (ArrayList<String>) obj.getInformation();
		String month = reportDetails.get(0), year = reportDetails.get(1);
		Region region = Region.valueOf(reportDetails.get(2));
		Integer numberOfClients = QueryExecutor.getNumberOfClients(month, year, region, con);
		if ((numberOfClients != null) && (numberOfClients != 0)) {
			ArrayList<Integer> info = new ArrayList<>();
			PreparedStatement ps = null;
			try {
				ps = con.prepareStatement(
						"SELECT numOfOrders FROM ekrut.monthly_customer_reports WHERE Region = ? AND month = ? AND year = ?");
				ps.setString(1, region.toString());
				ps.setString(2, month);
				ps.setString(3, year);
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					info.add(rs.getInt("numOfOrders"));
				}
				obj.setInformation(info);
				obj.setResponse(Response.GET_MONTHLY_CUSTOMER_REPORT_SUCCESS);
			} catch (SQLException e) {
			}
		} else {
			obj.setResponse(Response.GET_MONTHLY_CUSTOMER_REPORT_FAILD);
		}
	}
	
	/**
	 * Retrieves number of clients for a given month, year and region from database.
	 * @param month month for which the report is generated
	 * @param year year for which the report is generated
	 * @param region region for which the report is generated
	 * @param con database connection
	 * @return number of clients
	 */
	private static Integer getNumberOfClients(String month, String year, Region region, Connection con) {
		PreparedStatement ps = null;
		Integer retVal = null;
		try {
			ps = con.prepareStatement(
					"SELECT COUNT(ekrut.monthly_customer_reports.clientID) FROM ekrut.monthly_customer_reports WHERE Region = ? AND month = ? AND year = ?");
			ps.setString(1, region.toString());
			ps.setString(2, month);
			ps.setString(3, year);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				retVal = rs.getInt("COUNT(ekrut.monthly_customer_reports.clientID)");
			}
		} catch (SQLException e) {
		}
		return retVal;
	}
	
	/**
	 * Logs out a user by updating the "isLoggedIn" field in the database to "0"
	 * @param obj MissionPack object containing the user's username
	 * @param con database connection
	 */
	public static void logOut(MissionPack obj, Connection con) {
		PreparedStatement ps = null;
		String username = (String) obj.getInformation();
		obj.setResponse(Response.LOG_OUT_SUCCESS);
		try {
			ps = con.prepareStatement("UPDATE ekrut.users SET isLoggedIn=\"0\" WHERE username=?");
			ps.setString(1, username);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			obj.setResponse(Response.LOG_OUT_FAILED);
		}

	}

	/**
	 * Retrieves product name, quantity, and image from the database for a given store and creates a ProductInStock object for each product.
	 * The ProductInStock objects are stored in an array and set in the MissionPack object.
	 * @param obj MissionPack object containing the store name and storing the ProductInStock objects
	 * @param con database connection
	 */
	public void CREATE_LOCAL_ORDER(MissionPack obj, Connection con) throws IOException {
		int i = 0;
		ProductInStock[] products = new ProductInStock[12];
		PreparedStatement ps = null;
		String store = (String) obj.getInformation();
		obj.setResponse(Response.LOCAL_ORDER_OPENED);
		try {
			ps = con.prepareStatement("SELECT productName,quantity FROM ekrut.product_stock WHERE facility=?");
			ps.setString(1, store);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				String productName = rs.getString("productName");
				InputStream input = null;
				try {

					input = this.getClass().getResourceAsStream("/pictures/" + productName + ".png");
				} catch (Exception e) {
					e.printStackTrace();
				}

				ByteArrayOutputStream output = new ByteArrayOutputStream();
				byte[] buffer = new byte[1024];
				int n = 0;
				while (-1 != (n = input.read(buffer))) {
					output.write(buffer, 0, n);
				}
				byte[] imageBytes = output.toByteArray();
				products[i] = new ProductInStock(rs.getString("productName"), rs.getInt("quantity"), imageBytes);
				i++;
			}
			obj.setInformation(products);
		} catch (SQLException e) {
			e.printStackTrace();
			obj.setResponse(Response.LOCAL_ORDER_NOTOPENED);
		}
	}

	/**
	 * Retrieves product name, quantity, and image from the warehouse's stock in the database and creates a ProductInStock object for each product.
	 * The ProductInStock objects are stored in an array and set in the MissionPack object.
	 * @param obj MissionPack object storing the ProductInStock objects
	 * @param con database connection
	 */
	public void CREATE_REMOTE_ORDER(MissionPack obj, Connection con) throws IOException {
		int i = 0;
		ProductInStock[] products = new ProductInStock[12];
		PreparedStatement ps = null;
		obj.setResponse(Response.REMOTE_ORDER_OPENED);
		try {
			ps = con.prepareStatement("SELECT productName,quantity FROM ekrut.product_stock WHERE facility=?");
			ps.setString(1, "WAREHOUSE");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				String productName = rs.getString("productName");
				InputStream input = null;
				try {
					input = this.getClass().getResourceAsStream("/pictures/" + productName + ".png");
				} catch (Exception e) {
					e.printStackTrace();
				}

				
				ByteArrayOutputStream output = new ByteArrayOutputStream();
				byte[] buffer = new byte[1024];
				int n = 0;
				while (-1 != (n = input.read(buffer))) {
					output.write(buffer, 0, n);
				}
				byte[] imageBytes = output.toByteArray();
				products[i] = new ProductInStock(rs.getString("productName"), rs.getInt("quantity"), imageBytes);
				i++;
			}
			obj.setInformation(products);
		} catch (SQLException e) {
			e.printStackTrace();
			obj.setResponse(Response.REMOTE_ORDER_NOTOPENED);
		}
	}

	/**
	 * Retrieves credit card, expiration date, CVV, and user ID from the database for a given username and stores them in an array.
	 * The array is then set in the MissionPack object.
	 * @param obj MissionPack object containing the username and storing the payment data
	 * @param con database connection
	 */
	public static void GET_PAYMENT_DATA(MissionPack obj, Connection con) {
		PreparedStatement ps = null;
		String username = (String) obj.getInformation();
		String[] data = new String[4];
		try {
			ps = con.prepareStatement("SELECT id,creditCard,CVV,expirationDate FROM ekrut.users WHERE username=?");
			ps.setString(1, username);
			ResultSet rs = ps.executeQuery();
			rs.first();
			data[0] = rs.getString("creditCard");
			data[1] = rs.getString("expirationDate");
			data[2] = rs.getString("CVV");
			data[3] = rs.getString("id");
			obj.setInformation(data);
			obj.setResponse(Response.PAYMENT_DATA_SUCCESS);
		} catch (SQLException e) {
			e.printStackTrace();
			obj.setResponse(Response.PAYMENT_DATA_FAILED);
		}
	}

	/**
	 * Imports all user data from an external database and inserts it into the current database.
	 * @param obj MissionPack object that stores the imported data
	 * @param con Current database connection
	 */
	public static void ImportUsersData(MissionPack obj, Connection con) {
		Connection externalConnection = con;
		Statement createStmt;
		try {
			createStmt = externalConnection.createStatement(); // externalDB con

			ResultSet rs = createStmt.executeQuery("SELECT * FROM ekrutdb.users;");
			while (rs.next()) {
				PreparedStatement ps;
				try {
					ps = con.prepareStatement(
							"INSERT INTO ekrut.users (username, password, firstName, lastName, role, email, phoneNumber, isLoggedIn, storeName, id, creditCard, CVV, expirationDate, config, Region,subscriberNumber,subscriberFirstPurchase) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);");
					ps.setString(1, rs.getString(1));
					ps.setString(2, rs.getString(2));
					ps.setString(3, rs.getString(3));
					ps.setString(4, rs.getString(4));
					ps.setString(5, rs.getString(5));
					ps.setString(6, rs.getString(6));
					ps.setString(7, rs.getString(7));
					ps.setString(8, rs.getString(8));
					ps.setString(9, rs.getString(9));
					ps.setString(10, rs.getString(10));
					ps.setString(11, rs.getString(11));
					ps.setString(12, rs.getString(12));
					ps.setString(13, rs.getString(13));
					ps.setString(14, rs.getString(14));
					ps.setString(15, rs.getString(15));
					ps.setString(16, rs.getString(16));
					ps.setString(17, rs.getString(17));
					ps.executeUpdate();
				} catch (Exception e) {
					System.out.println("Failed to import.");
				}
			}
			System.out.println("The import succeeded");

		} catch (Exception e) {
			System.out.println("Failed to import");
		}

	}

	/**

	*Retrieves a list of users who have requested to be customers from a specific region.
	*@param obj MissionPack object containing the region and list of requested customers
	*@param con connection to the database
	*/
	public static void GET_REQUESTED_TO_BE_COSTOMERS(MissionPack obj, Connection con) {
		PreparedStatement ps = null;
		List<User> userRequestToBeCustomers = new ArrayList<>();
		String region = (String) obj.getInformation();
		try {
			ps = con.prepareStatement(
					"SELECT username, firstName, lastName, email, storeName FROM ekrut.users WHERE role='RequsestToBeCustomer' AND Region=?;");
			ps.setString(1, region);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				User user = new User(rs.getString("username"), rs.getString("firstName"), rs.getString("lastName"),
						rs.getString("email"), rs.getString("storeName"));
				userRequestToBeCustomers.add(user);
			}
			obj.setInformation(userRequestToBeCustomers);
			obj.setResponse(Response.REQUESTED_TO_BE_COSTOMERS_SUCCESS);
		} catch (SQLException e) {
			e.printStackTrace();
			obj.setResponse(Response.REQUESTED_TO_BE_COSTOMERS_FAILED);
		}
	}

	/**

	*Approves a user's request to be a customer.
	*@param obj MissionPack object containing the approved user
	*@param con connection to the database
	*/
	public static void APPROVED_TO_BE_COSTOMERS(MissionPack obj, Connection con) {
		PreparedStatement ps = null;
		User approvedUser = (User) obj.getInformation();
		if (checkNonAlreadyCustomer(approvedUser.getUsername(), con)) {
			try {
				ps = con.prepareStatement("UPDATE ekrut.users SET role='customer' WHERE (username = ?);");
				ps.setString(1, approvedUser.getUsername());
				ps.executeUpdate();
				obj.setResponse(Response.APPROVED_TO_BE_COSTOMERS_SUCCESS);
			} catch (SQLException e) {
				e.printStackTrace();
				obj.setResponse(Response.APPROVED_TO_BE_COSTOMERS_FAILED);
			}
		} else
			obj.setResponse(Response.APPROVED_TO_BE_COSTOMERS_FAILED);

	}

	/**

	*private helper method to check if the user is already a customer or not
	*@param username the user's username
	*@param  connection to the database
	*@return true if the user is not already a customer, false otherwise
	*/
	private static boolean checkNonAlreadyCustomer(String username, Connection con) {
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(
					"SELECT username FROM ekrut.users WHERE role='RequsestToBeCustomer' AND username = ? ");
			ps.setString(1, username);
			return ps.executeQuery().next();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}

	}

	/**

	*Update the stock quantity of a facility after purchase, also insert delivery information if delivery is selected
	*@param obj, connection
	*/
	public static void UpdateStock(MissionPack obj, Connection con) {
		obj.setResponse(Response.STOCK_UPDATE_SUCCESS);
		Object[] arr = (Object[]) obj.getInformation();
		ArrayList<ProductInCart> shoppingCart = (ArrayList<ProductInCart>) arr[0];
		String facility = (String) arr[1];
		String deliveryOrPickup = (String) arr[2];
		String email = (String) arr[3];
		String region = (String) arr[4];
		String username = (String) arr[5];
		String phone = (String) arr[6];
		String address = (String) arr[8];
		String subscriberFirstPurchase = (String) arr[9];
		String role = (String) arr[7];
		String facilityToPickup = (String) arr[10];
		PreparedStatement ps = null;
		int dbQuantity = 0;
		for (int i = 0; i < shoppingCart.size(); i++) {
			ProductInCart product = shoppingCart.get(i);
			int amount = product.getAmount();
			String name = product.getProduct();
			try {
				ps = con.prepareStatement(
						"SELECT quantity FROM ekrut.product_stock WHERE productName=? AND facility=?");
				ps.setString(1, name);
				ps.setString(2, facility);
				ResultSet rs = ps.executeQuery();
				rs.first();
				dbQuantity = rs.getInt("quantity");
			} catch (SQLException e) {
				e.printStackTrace();
				obj.setResponse(Response.STOCK_UPDATE_FAILED);
				System.out.println("fail 1");
			}
			if (dbQuantity <= 0 || dbQuantity - amount < 0) {
				obj.setResponse(Response.STOCK_UPDATE_FAILED);
				System.out.println("fail 2");
				return;
			}
			try {
				ps = con.prepareStatement(
						"UPDATE ekrut.product_stock SET quantity=? WHERE productName=? AND facility=?");
				ps.setInt(1, dbQuantity - amount);
				ps.setString(2, name);
				ps.setString(3, facility);
				ps.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
				obj.setResponse(Response.STOCK_UPDATE_FAILED);
				System.out.println("fail 3");
			}

		}
		if (deliveryOrPickup != null && deliveryOrPickup.equals("Delivery")) {
			try {
				ps = con.prepareStatement("SELECT MAX(numberOfDelivery) AS max FROM ekrut.deliveries");
				ResultSet rs = ps.executeQuery();
				rs.first();
				Integer maxi = rs.getInt("max");
				maxi++;
				try {
					ps = con.prepareStatement(
							"INSERT INTO ekrut.deliveries (numberOfDelivery, username, phoneNumber, email, deliveryStatus, customerStatus, region, address) VALUES (?,?,?,?,?,?,?,?);");
					ps.setInt(1, maxi);
					ps.setString(2, username);
					ps.setString(3, phone);
					ps.setString(4, email);
					ps.setString(5, "NOT_APPROVE");
					ps.setString(6, "NOT_DELIVERED");
					ps.setString(7, region);
					ps.setString(8, address);
					ps.executeUpdate();
				} catch (Exception e) {
					e.printStackTrace();
					obj.setResponse(Response.STOCK_UPDATE_FAILED);
					System.out.println("fail 4");
				}

			} catch (SQLException e) {
				e.printStackTrace();
				obj.setResponse(Response.STOCK_UPDATE_FAILED);
				System.out.println("fail 5");
			}
		}

		else if (deliveryOrPickup != null && deliveryOrPickup.equals("Pickup")) {
			try {
				ps = con.prepareStatement("SELECT MAX(numberOfPickup) AS max FROM ekrut.pickups");
				ResultSet rs = ps.executeQuery();
				rs.first();
				Integer maxi = rs.getInt("max");
				maxi++;
				try {
					ps = con.prepareStatement(
							"INSERT INTO ekrut.pickups (numberOfPickup, username, pickupStatus, storeName) VALUES (?,?,?,?);");
					ps.setInt(1, maxi);
					ps.setString(2, username);
					ps.setString(3, "NOT_PICKED_UP");
					ps.setString(4, facilityToPickup);
					ps.executeUpdate();
					obj.setInformation(maxi);
				} catch (Exception e) {
					e.printStackTrace();
					obj.setResponse(Response.STOCK_UPDATE_FAILED);
					System.out.println("fail 6");
				}
			}

			catch (SQLException e) {
				e.printStackTrace();
				obj.setResponse(Response.STOCK_UPDATE_FAILED);
				System.out.println("fail 7");
			}
		}

		if (role.equals("subscriber") && subscriberFirstPurchase.equals("0"))

		{
			try {
				ps = con.prepareStatement("UPDATE ekrut.users SET subscriberFirstPurchase='1' WHERE username=?");
				ps.setString(1, username);
				ps.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
				obj.setResponse(Response.STOCK_UPDATE_FAILED);
				System.out.println("fail 8");
			}
		}

	}

	/**

	*Retrieves a list of deliveries that have been approved but not yet delivered, for a specific user.
	*The user's username is passed in as a parameter through the MissionPack object.
	*The list of deliveries is stored in the MissionPack object's information field.
	*@param obj The MissionPack object containing the user's username and the list of approved, undelivered deliveries
	*@param  connection to the database
	*/
	public static void refreshDeliveryApproval(MissionPack obj, Connection connection) {
		PreparedStatement ps = null;
		List<DeliveryInfo> deliveryToBeApproved = new ArrayList<>();
		DeliveryInfo delivery = null;
		try {
			ps = connection.prepareStatement(
					"SELECT deliveries.numberOfDelivery,phoneNumber, email, address FROM ekrut.deliveries WHERE deliveryStatus=\"APPROVE\" AND customerStatus=\"NOT_DELIVERED\" AND username = ?;");
			ps.setString(1, (String) obj.getInformation());
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				delivery = new DeliveryInfo(rs.getString("phoneNumber"), rs.getInt("numberOfDelivery"),
						rs.getString("address"), rs.getString("email"));

				deliveryToBeApproved.add(delivery);
			}
			obj.setInformation(deliveryToBeApproved);
			obj.setResponse(Response.REFRESH_DELIVERY_SUCCESS);
		} catch (SQLException e) {
			e.printStackTrace();
			obj.setResponse(Response.REFRESH_DELIVERY_FAILED);
		}
	}
	/**

	*Approves a delivery as delivered by the customer.
	*The delivery information is passed in as a parameter through the MissionPack object.
	*@param obj The MissionPack object containing the delivery information to be approved
	*@param connection to the database
	*/
	public static void approveDeliveryFromCustomerSide(MissionPack obj, Connection connection) {
		PreparedStatement ps = null;
		DeliveryInfo inforation = (DeliveryInfo) obj.getInformation();
		try {
			ps = connection.prepareStatement(
					"UPDATE ekrut.deliveries SET customerStatus=\"DELIVERED\" WHERE numberOfDelivery=?");
			ps.setInt(1, inforation.getNumberOfDelivery());
			ps.executeUpdate();
			obj.setResponse(Response.APPROVE_DELIVERY_SUCCESS);
		} catch (SQLException e) {
			e.printStackTrace();
			obj.setResponse(Response.APPROVE_DELIVERY_FAILED);
		}
	}
	/**

	*Retrieves a list of active sales from a specific region
	*The region is passed in as a parameter through the MissionPack object.
	*The list of sales is stored in the MissionPack object's information field.
	*@param obj The MissionPack object containing the region and the list of active sales
	*@param  connection to the database
	*/
	public static void GET_SALES(MissionPack obj, Connection connection) {
		PreparedStatement ps = null;
		List<Sale> sales = new ArrayList<>();
		Sale sale = null;
		String region = (String) obj.getInformation();
		try {
			ps = connection.prepareStatement(
					"SELECT sales.indexInArray,discount,description,startingTime,endingTime FROM ekrut.sales WHERE region= ? AND status='Active';");
			ps.setString(1, region);
			
			ResultSet rs = ps.executeQuery();
			Calendar now = Calendar.getInstance();
			int hour = now.get(Calendar.HOUR_OF_DAY);
			System.out.println(hour);
			while (rs.next()) {			
				if (hour >= rs.getInt("startingTime") && hour < rs.getInt("endingTime")) {
					sale = new Sale(rs.getString("indexInArray"), rs.getDouble("discount"), rs.getString("description"));
					sales.add(sale);   
				}
				
			}
			obj.setInformation(sales);
			obj.setResponse(Response.GET_SALES_SUCCESS);
		} catch (SQLException e) {
			e.printStackTrace();
			obj.setResponse(Response.GET_SALES_FAIL);
		}

	}
	/**
	* This method is used to refresh a list of pickups for a given user and facility.
	*
	* @param obj, connection
	*/
	public static void REFRESH_PICKUP(MissionPack obj, Connection connection) {
		String[] data = (String[]) obj.getInformation();
		PreparedStatement ps = null;
		List<PickupInfo> pickups = new ArrayList<>();
		PickupInfo pickup = null;
		String username = data[0];
		String facility = data[1];
		try {
			ps = connection.prepareStatement(
					"SELECT pickups.numberOfPickup,storeName FROM ekrut.pickups WHERE storeName=? AND pickupStatus=\"NOT_PICKED_UP\" AND username = ?;");
			System.out.println(facility + " " + username);
			ps.setString(1, facility);
			ps.setString(2, username);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				pickup = new PickupInfo(rs.getInt("numberOfPickup"), rs.getString("storeName"));
				pickups.add(pickup);
			}
			obj.setInformation(pickups);
			obj.setResponse(Response.REFRESH_PICKUP_SUCCESS);
		} catch (SQLException e) {
			e.printStackTrace();
			obj.setResponse(Response.REFRESH_PICKUP_FAIL);
		}

	}
	/**
	* This method is used to update the status of a pickup order to "PICKED_UP".
	*
	* @param obj an object of the MissionPack class, which contains information
	*            about the current operation and any data that is associated with it,
	*            including the pickup order number.
	* @param  connection object that is used to connect to the database.
	*/
	public static void PICKUP_ORDER(MissionPack obj, Connection connection) {
		PreparedStatement ps = null;
		PickupInfo information = (PickupInfo) obj.getInformation();
		try {
			ps = connection
					.prepareStatement("UPDATE ekrut.pickups SET pickupStatus=\"PICKED_UP\" WHERE numberOfPickup=?");
			ps.setInt(1, information.getOrderNum());
			ps.executeUpdate();
			obj.setResponse(Response.PICKUP_SUCCESS);
		} catch (SQLException e) {
			e.printStackTrace();
			obj.setResponse(Response.PICKUP_FAIL);
		}

	}
	/**
	* This method is used to add a bill for a user for a specific month.
	*
	* @param obj, connection
	*/
	public static void ADD_BILL(MissionPack obj, Connection con) {
		PreparedStatement ps = null;
		Object[] information = (Object[]) obj.getInformation();
		Date date = new Date();
		LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		int month = localDate.getMonthValue();
		String username = (String) information[0];
		double price = (Double) information[1];
		try {

			ps = con.prepareStatement("INSERT INTO ekrut.monthlybills (username,price,month,status) VALUES (?,?,?,?);");
			ps.setString(1, username);
			ps.setDouble(2, price);
			ps.setInt(3, month);
			ps.setString(4, "NOT_PAID");
			ps.executeUpdate();
			obj.setResponse(Response.BILL_ADDED);
		} catch (Exception exception) {
			exception.printStackTrace();
			obj.setResponse(Response.BILL_NOT_ADDED);
		}
	}
	/**
	* This method is used to check if a user is currently logged in or not.
	*
	* @param obj an object of the MissionPack class, which contains information
	*            about the current operation and any data that is associated with it,
	*            including the username of the user.
	* @param connection object that is used to connect to the database.
	*/
	public static void CHECK_LOGGED_IN(MissionPack obj, Connection connection) {
		PreparedStatement ps = null;
		boolean exists = false;
		String username = (String) obj.getInformation();
		try {
			ps = connection.prepareStatement("SELECT users.isLoggedIn FROM ekrut.users WHERE username=? ;");
			ps.setString(1, username);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				if (rs.getString("isLoggedIn").equals("1"))
					obj.setResponse(Response.LOGGED_IN_ERROR);
				else
					obj.setResponse(Response.NOT_LOGGED_IN);
				exists = true;
			}
			if (!exists) {
				obj.setResponse(Response.USER_DOESNT_EXIST);
			}

		} catch (SQLException sqlException) {
			System.out.println("Exception- Executing statement- new throws FIND_USER_IN_DATA_FAILED");
			sqlException.printStackTrace();
			obj.setResponse(Response.FIND_USER_IN_DATA_FAILED);
		}

	}
	/**
	 * Check if a user is logged in by their ID.
	 * 
	 * @author Yovel
	 * 
	 * @param obj  The MissionPack object that holds the subscriber number and the 
	 *             response to be sent to the client.
	 * @param connection The connection object used to communicate with the database.
	 */
	public static void CHECK_LOGGED_IN_BY_ID(MissionPack obj, Connection connection) {
		PreparedStatement ps = null;
		boolean exists = false;
		String id = (String) obj.getInformation();
		try {
			ps = connection.prepareStatement("SELECT users.isLoggedIn FROM ekrut.users WHERE subscriberNumber=? ;");
			ps.setString(1, id);
			
			ResultSet rs = ps.executeQuery();
			

			while (rs.next()) {
				if (rs.getString("isLoggedIn").equals("1"))
					obj.setResponse(Response.LOGGED_IN_BY_ID_ERROR);
				else
					obj.setResponse(Response.LOGGED_IN_BY_ID_SUCCESS);
				exists = true;
			}
			if (!exists) {
				obj.setResponse(Response.USER_DOESNT_EXIST);
			}

		} catch (SQLException sqlException) {
			System.out.println("Exception- Executing statement- new throws FIND_USER_IN_DATA_FAILED");
			sqlException.printStackTrace();
			obj.setResponse(Response.FIND_USER_IN_DATA_FAILED);
		}

	}
	/**
	* This method is used to set the facility for a user.
	*
	* @param obj an object of the MissionPack class, which contains information
	*            about the current operation and any data that is associated with it,
	*            including the username, password, config, and storeName of the user.
	* @param  connection object that is used to connect to the database.
	*/
	public static void setFacility(MissionPack obj, Connection connection) {
		System.out.println("��� �����");
		PreparedStatement ps = null;
		String[] information = (String[]) obj.getInformation();
		try {
			ps = connection
					.prepareStatement("UPDATE ekrut.users SET storeName=?,config=? WHERE username=? AND password =?");
			ps.setString(1, information[3]);
			ps.setString(2, information[2]);
			ps.setString(3, information[0]);
			ps.setString(4, information[1]);
			ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("the set fail");
		}
	}
	/**
	* This method is used to retrieve extra details for a customer report.
	*
 * @param obj, connection
	*/
	public static void getExtraDetailsForCustomerReport(MissionPack obj, Connection con) {
		ArrayList<String> reportDetails = (ArrayList<String>) obj.getInformation();
		String month = reportDetails.get(0), year = reportDetails.get(1), region = reportDetails.get(2);
		String bestCustomerName = QueryExecutor.getBestCustomerName(month, year, region, con);
		String bestEKrut = QueryExecutor.getBestEKrut(month, year, region, con);
		String bestConfig = QueryExecutor.getBestConfig(month, year, region, con);
		String numberOfCancelOrders = QueryExecutor.getNumberOfCancelOrders(month, year, region, con);
		if ((bestCustomerName == null) || (bestEKrut == null) || (bestConfig == null)
				|| (numberOfCancelOrders == null)) {
			obj.setResponse(Response.EXTRA_DETAILS_FOR_CUSTOMER_REPORT_FAILED);
		} else {
			ArrayList<String> extraDetails = new ArrayList<>();
			extraDetails.add(numberOfCancelOrders);
			extraDetails.add(bestConfig);
			extraDetails.add(bestEKrut);
			extraDetails.add(bestCustomerName);
			obj.setInformation(extraDetails);
			obj.setResponse(Response.EXTRA_DETAILS_FOR_CUSTOMER_REPORT_SUCCESS);
		}
	}
	/**
	* This method is used to retrieve the number of cancel orders for a specific month, year, and region.
	*
	* @param  month for which the report is generated.
	* @param year for which the report is generated.
	* @param  region for which the report is generated.
	* @param connection object that is used to connect to the database.
	* @return the number of cancel orders as a string or null if no data is found.
	*/
	private static String getNumberOfCancelOrders(String month, String year, String region, Connection con) {
		PreparedStatement ps = null;
		String retVal = null;
		try {
			ps = con.prepareStatement(
					"SELECT numOfTotalCancelOrder FROM ekrut.monthly_customer_reports WHERE Region = ? AND month = ? AND year = ?");
			ps.setString(1, region);
			ps.setString(2, month);
			ps.setString(3, year);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				retVal = Integer.toString(rs.getInt("numOfTotalCancelOrder"));
			}
		} catch (SQLException e) {
		}
		return retVal;
	}
	/**
	* This method is used to retrieve the best config for a specific month, year, and region.
	*
	* @param  month for which the report is generated.
	* @param  year for which the report is generated.
	* @param  region for which the report is generated.
	* @param connection object that is used to connect to the database.
	* @return the best config as a string or null if no data is found.
	*/
	private static String getBestConfig(String month, String year, String region, Connection con) {
		PreparedStatement ps = null;
		String retVal = null;
		try {
			ps = con.prepareStatement(
					"SELECT config FROM ekrut.monthly_customer_reports WHERE Region = ? AND month = ? AND year = ?");
			ps.setString(1, region);
			ps.setString(2, month);
			ps.setString(3, year);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				retVal = rs.getString("config");
			}
		} catch (SQLException e) {
		}
		return retVal;
	}
	/**
	* This method is used to retrieve the best customer name for a specific month, year, and region.
	*
	* @param month for which the report is generated.
	* @param year for which the report is generated.
	* @param region for which the report is generated.
	* @param connection object that is used to connect to the database.
	* @return the best customer name as a string or null if no data is found.
	*/
	private static String getBestCustomerName(String month, String year, String region, Connection con) {
		PreparedStatement ps = null;
		String retVal = null;
		try {
			ps = con.prepareStatement(
					"SELECT bestCustomerName, MAX(ekrut.monthly_customer_reports.numOfOrders) FROM ekrut.monthly_customer_reports WHERE Region = ? AND month = ? AND year = ?");
			ps.setString(1, region);
			ps.setString(2, month);
			ps.setString(3, year);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				retVal = rs.getString("bestCustomerName");
			}
		} catch (SQLException e) {
		}
		return retVal;
	}
	/**
	* This method is used to retrieve the best EKrut for a specific month, year, and region.
	*
	* @param month the month for which the report is generated.
	* @param year the year for which the report is generated.
	* @param region the region for which the report is generated.
	* @param connection object that is used to connect to the database.
	* @return the best EKrut as a string or null if no data is found.
	*/
	private static String getBestEKrut(String month, String year, String region, Connection con) {
		PreparedStatement ps = null;
		String retVal = null;
		try {
			ps = con.prepareStatement(
					"SELECT bestEKrut FROM ekrut.monthly_customer_reports WHERE Region = ? AND month = ? AND year = ?");
			ps.setString(1, region);
			ps.setString(2, month);
			ps.setString(3, year);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				retVal = rs.getString("bestEKrut");
			}
		} catch (SQLException e) {
		}
		return retVal;
	}
	/**
	* This method is used to retrieve extra details for an order report for a specific month, year, and region.
	* It retrieves the total order number, best seller, average orders and best time.
	*
	* @param obj, connection
	*/
	public static void getExtraDetailsForOrderReport(MissionPack obj, Connection con) {
		ArrayList<String> reportDetails = (ArrayList<String>) obj.getInformation();
		String month = reportDetails.get(0), year = reportDetails.get(1), region = reportDetails.get(2);
		String totalOrderNumber = QueryExecutor.getTotalOrderNumber(month, year, region, con);
		HashMap<String, String> mapBestSeller = QueryExecutor.getBestSeller(month, year, region, con);
		String avgOrders = Float.toString((float) ((Integer.valueOf(totalOrderNumber) / (31.0))));
		HashMap<String, String> mapBestTime = QueryExecutor.getBestTime(month, year, region, con);

		if ((totalOrderNumber == null) || (mapBestSeller == null) || (mapBestTime == null) || (avgOrders == null)) {
			obj.setResponse(Response.EXTRA_DETAILS_FOR_ORDER_REPORT_FAILED);
		} else {
			HashMap<String, ArrayList<String>> dataToClient = new HashMap<String, ArrayList<String>>();
			for (Map.Entry<String, String> current : mapBestSeller.entrySet()) {
				if (dataToClient.get(current.getKey()) == null)
					dataToClient.put(current.getKey(), new ArrayList<String>());
				dataToClient.get(current.getKey()).add(current.getValue());
			}

			for (Map.Entry<String, String> current : mapBestTime.entrySet()) {
				if (dataToClient.get(current.getKey()) == null)
					dataToClient.put(current.getKey(), new ArrayList<String>());
				dataToClient.get(current.getKey()).add(current.getValue());
			}
			ArrayList<String> dataTotalOrders = new ArrayList<>();
			ArrayList<String> dataAvgOrders = new ArrayList<>();
			dataTotalOrders.add(totalOrderNumber);
			dataToClient.put("TotalOrders", dataTotalOrders);
			dataAvgOrders.add(avgOrders);
			dataToClient.put("AvgOrders", dataAvgOrders);
			obj.setInformation(dataToClient);
			obj.setResponse(Response.EXTRA_DETAILS_FOR_ORDER_REPORT_SUCCESS);
		}
	}
	/**

	*This method is used to get the best time of the month, year and region
	*@param month for which the best time needs to be retrieved
	*@param year for which the best time needs to be retrieved
	*@param  region for which the best time needs to be retrieved
	*@param con the connection to the database
	*@return a HashMap where the key is the store name and the value is the best time of that store.
	   * If the query fails, it returns null
	*/
	private static HashMap<String, String> getBestTime(String month, String year, String region, Connection con) {
		PreparedStatement ps = null;
		HashMap<String, String> map = new HashMap<>();
		try {
			ps = con.prepareStatement(
					"SELECT bestTime, store FROM ekrut.monthly_orders_reports WHERE region = ? AND month = ? AND year = ?");
			ps.setString(1, region);
			ps.setString(2, month);
			ps.setString(3, year);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				map.put(rs.getString("store"), rs.getString("bestTime"));
			}
		} catch (SQLException e) {
			map = null;
		}
		return map;
	}
	/**

	*This method retrieves the total number of orders for a given month,
	* year and region from the ekrut.monthly_orders_reports table
	*@param month for which the orders need to be retrieved
	*@param  year for which the orders need to be retrieved
	*@param  region for which the orders need to be retrieved
	*@param con The connection to the database
	*@return The total number of orders as a string
	*/
	private static String getTotalOrderNumber(String month, String year, String region, Connection con) {
		PreparedStatement ps = null;
		String retVal = null;
		try {
			ps = con.prepareStatement(
					"SELECT SUM(ekrut.monthly_orders_reports.numOfTotalOrders) FROM ekrut.monthly_orders_reports WHERE region = ? AND month = ? AND year = ?");
			ps.setString(1, region);
			ps.setString(2, month);
			ps.setString(3, year);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				retVal = Integer.toString(rs.getInt("SUM(ekrut.monthly_orders_reports.numOfTotalOrders)"));
			}
		} catch (SQLException e) {
		}
		return retVal;
	}
	/**

	*Retrieves the best seller for each store in the given region, month and year.
	*@param month of the report
	*@param  year of the report
	*@param  region of the report
	*@param con the database connection
	*@return a HashMap containing store as the key and best seller as the value, or null if an error occurs
	*/
	private static HashMap<String, String> getBestSeller(String month, String year, String region, Connection con) {
		PreparedStatement ps = null;
		HashMap<String, String> map = new HashMap<>();
		try {
			ps = con.prepareStatement(
					"SELECT bestSeller, store FROM ekrut.monthly_orders_reports WHERE region = ? AND month = ? AND year = ?");
			ps.setString(1, region);
			ps.setString(2, month);
			ps.setString(3, year);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				map.put(rs.getString("store"), rs.getString("bestSeller"));
			}
		} catch (SQLException e) {
			map = null;
		}
		return map;
	}
	/**
	*This method retrieves additional details for a stock report,
	* including the nearest expiration date and the minimum threshold for each product.
	*@param obj contains the report details (month, year, facility) to query the database
	*@param con the connection to the database
	*/
	public static void getExtraDetailsForStockReport(MissionPack obj, Connection con) {
		ArrayList<String> reportDetails = (ArrayList<String>) obj.getInformation();
		String month = reportDetails.get(0), year = reportDetails.get(1), facility = reportDetails.get(2);
		String nearestExpDate = QueryExecutor.getNearestExpDate(month, year, facility, con);
		HashMap<String, String> mapMinTreshold = QueryExecutor.getMinTreshold(month, year, facility, con);

		if ((nearestExpDate == null) || (mapMinTreshold == null)) {
			obj.setResponse(Response.EXTRA_DETAILS_FOR_STOCK_REPORT_FAILED);
		} else {
			HashMap<String, String> dataToClient = new HashMap<String, String>();
			for (Map.Entry<String, String> current : mapMinTreshold.entrySet()) {
				dataToClient.put(current.getKey(), current.getValue());
			}
			dataToClient.put("NearestExpDate", nearestExpDate);
			obj.setInformation(dataToClient);
			obj.setResponse(Response.EXTRA_DETAILS_FOR_STOCK_REPORT_SUCCESS);
		}
	}
	/**
	 * Retrieves the minimum threshold for a given facility, month and year from the database.
	 * @param  month for which the threshold is to be retrieved
	 * @param  year for which the threshold is to be retrieved
	 * @param  facility for which the threshold is to be retrieved
	 * @param con the connection to the database
	 * @return a HashMap containing the product name as key and the threshold as value, or null if an error occurs
	 */
	private static HashMap<String, String> getMinTreshold(String month, String year, String facility, Connection con) {
		PreparedStatement ps = null;
		HashMap<String, String> map = new HashMap<>();
		try {
			ps = con.prepareStatement(
					"SELECT ProductName, numOfTimesWentTreshold FROM ekrut.monthly_stock_reports WHERE Facility = ? AND month = ? AND year = ?");
			ps.setString(1, facility);
			ps.setString(2, month);
			ps.setString(3, year);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				map.put(rs.getString("ProductName"), Integer.toString(rs.getInt("numOfTimesWentTreshold")));
			}
		} catch (SQLException e) {
			map = null;
		}
		return map;
	}
	/**
	*Retrieves the nearest expiration date of all products at a certain facility for a certain month and year.
	*@param  month to retrieve the nearest expiration date for.
	*@param  year to retrieve the nearest expiration date for.
	*@param  facility to retrieve the nearest expiration date for.
	*@param con The connection to the database to use for retrieving the data.
	*@return The nearest expiration date for the specified month, year, and facility.
	*/
	private static String getNearestExpDate(String month, String year, String facility, Connection con) {
		PreparedStatement ps = null;
		String retVal = null;
		try {
			ps = con.prepareStatement(
					"SELECT ekrut.monthly_stock_reports.nearestExpDate FROM ekrut.monthly_stock_reports WHERE Facility = ? AND month = ? AND year = ?");
			ps.setString(1, facility);
			ps.setString(2, month);
			ps.setString(3, year);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				retVal = rs.getString("nearestExpDate");
			}
		} catch (SQLException e) {
		}
		return retVal;
	}
	/**
	*This method is used to check products that are below the threshold level in a given region.
	*It updates the status of products that are below the threshold level and retrieves their details.
	*@param obj the MissionPack object that contains the region for which the threshold check is to be done
	*@param con the database connection object
	*/
	public static void ThresholdInventory(MissionPack obj, Connection con) {
		ArrayList<ProductInStock> products = new ArrayList<ProductInStock>();
		String region = (String) obj.getInformation();
		QueryExecutor.updateStatusInProductStockInRegion(region, con);
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(
					"SELECT ekrut.product_stock.facility, ekrut.product_stock.productName, ekrut.product_stock.quantity FROM ekrut.product_stock WHERE ekrut.product_stock.status = 'INVALID' AND ekrut.product_stock.region=?");
			ps.setString(1, region);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				products.add(new ProductInStock(rs.getString("facility"), rs.getString("productName"),
						rs.getInt("quantity")));
			}
			obj.setResponse(Response.CHECK_THRES_HOLD_INVENTORY_SUCCESS);
			obj.setInformation(products);
		} catch (SQLException e) {
			System.out.println("Statement for threshold inventory check has failed!");
			obj.setResponse(Response.CHECK_THRES_HOLD_INVENTORY_FAILED);
		}
	}
	
	/**
	*This method updates the status of products in a specific region in the "product_stock" table in the "ekrut" database.
	*Products with a quantity less than or equal to the minimum threshold and a status of "VALID" will have their status updated to "INVALID".
	*Products with a quantity greater than the minimum threshold and a status of "INVALID" will have their status updated to "VALID".
	*@param region - the region to update the status of products in
	*@param con - the connection to the "ekrut" database
	*/
	private static void updateStatusInProductStockInRegion(String region, Connection con) {
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(
					"UPDATE ekrut.product_stock SET ekrut.product_stock.status='INVALID' WHERE ekrut.product_stock.region = ? AND ekrut.product_stock.quantity <= ekrut.product_stock.minTrashHold AND ekrut.product_stock.status = 'VALID' AND ekrut.product_stock.reportID > 0");
			ps.setString(1, region);
			ps.executeUpdate();
			ps = con.prepareStatement(
					"UPDATE ekrut.product_stock SET ekrut.product_stock.status='VALID' WHERE ekrut.product_stock.region = ? AND ekrut.product_stock.quantity > ekrut.product_stock.minTrashHold AND ekrut.product_stock.status = 'INVALID' AND ekrut.product_stock.reportID > 0");
			ps.setString(1, region);
			ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("fail");
		}
	}
	/**
	*This method is used to update the status of a product in the inventory to "IN_PROGRESS" when it reaches its minimum threshold level.
	*It takes an object of type MissionPack as input which contains the details of the product to update.
	*@param obj an object of type MissionPack which contains the details of the product to update
	*@param con Connection to the database
	*/
	public static void UpdateThresholdInventory(MissionPack obj, Connection con) {
		ProductInStock item = (ProductInStock) obj.getInformation();
		String productName = item.getProductName();
		String productFacility = item.getFacility();

		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(
					"UPDATE ekrut.product_stock SET ekrut.product_stock.status = 'IN_PROGRESS' WHERE ekrut.product_stock.productName=? AND ekrut.product_stock.facility=? ");
			ps.setString(1, productName);
			ps.setString(2, productFacility);
			ps.executeUpdate();

			obj.setResponse(Response.UPDATE_STATUS_THRES_HOLD_INVENTORY_SUCCESS);
		} catch (SQLException e) {
			System.out.println("Statement for threshold inventory check has failed!");
			obj.setResponse(Response.UPDATE_STATUS_THRES_HOLD_INVENTORY_FAILED);
		}
	}
	/**
	*A method that retrieves the minimum threshold value of a specific product in a specific facility.
	*@param obj A MissionPack object that contains the facility name as the information field
	*@param con A connection to the database
	*/
	public static void pickAThresholdInventoryValue(MissionPack obj, Connection con) {
		String facility = (String) obj.getInformation();
		PreparedStatement ps = null;
		int minTrashHold = 0;
		try {
			ps = con.prepareStatement(
					"SELECT ekrut.product_stock.minTrashHold FROM ekrut.product_stock WHERE ekrut.product_stock.facility = ? AND productName = 'Bisli' AND ekrut.product_stock.reportID > 0");
			ps.setString(1, facility);
			ResultSet rs = ps.executeQuery();
			if (rs.next())
				minTrashHold = rs.getInt("minTrashHold");
			obj.setInformation(minTrashHold);
			obj.setResponse(Response.PICK_THRESHOLD_INVENTORY_VALUE_SUCCESS);
		} catch (SQLException e) {
			System.out.println("Statement for threshold inventory check has failed!");
			obj.setResponse(Response.PICK_THRESHOLD_INVENTORY_VALUE_FAILED);
		}
	}
	/**
	*The method UpdateMinTreshold updates the minimum threshold of the product stock for a specific facility.
	*@param obj - The mission pack object that contains the necessary information for the method to execute.
	*@param con - The connection to the database.
	*/
	public static void UpdateMinTreshold(MissionPack obj, Connection con) {
		ArrayList<String> data = (ArrayList<String>) obj.getInformation();
		String facility = data.get(0), minTrashold = data.get(1);
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(
					"UPDATE ekrut.product_stock SET ekrut.product_stock.minTrashHold = ? WHERE ekrut.product_stock.facility = ? AND ekrut.product_stock.reportID > 0");
			ps.setInt(1, Integer.valueOf(minTrashold));
			ps.setString(2, facility);
			ps.executeUpdate();
			QueryExecutor.updateStatusInProductStockInFacility(facility, con);
			obj.setResponse(Response.UPDATE_MINIMUM_THRESHOLD_INVENTORY_VALUE_SUCCESS);
		} catch (SQLException e) {
			System.out.println("Statement for threshold inventory check has failed!");
			obj.setResponse(Response.UPDATE_MINIMUM_THRESHOLD_INVENTORY_VALUE_FAILED);
		}
	}

	/**
	*This method updates the status of products in a given facility based on their quantity and minimum threshold.
	*If the quantity is less than or equal to the minimum threshold and the status is valid, the status is updated to 'INVALID'.
	*If the quantity is greater than the minimum threshold and the status is 'INVALID', the status is updated to 'VALID'.
	*@param facility the facility of which the product statuses will be updated
	*@param con the connection to the database
	*/
	private static void updateStatusInProductStockInFacility(String facility, Connection con) {
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(
					"UPDATE ekrut.product_stock SET ekrut.product_stock.status='INVALID' WHERE ekrut.product_stock.facility = ? AND ekrut.product_stock.quantity <= ekrut.product_stock.minTrashHold AND ekrut.product_stock.status = 'VALID' AND ekrut.product_stock.reportID > 0");
			ps.setString(1, facility);
			ps.executeUpdate();
			ps = con.prepareStatement(
					"UPDATE ekrut.product_stock SET ekrut.product_stock.status='VALID' WHERE ekrut.product_stock.facility = ? AND ekrut.product_stock.quantity > ekrut.product_stock.minTrashHold AND ekrut.product_stock.status = 'INVALID' AND ekrut.product_stock.reportID > 0");
			ps.setString(1, facility);
			ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("unsuccess");
		}
	}
	/**
	*A method that checks the items that need to be updated in the inventory
	*@param obj an object of MissionPack that contains information and response
	*@param con a Connection object to connect to the database
	*/
	public static void checkItemsToUpdateInventory(MissionPack obj, Connection con) {
		String facility = (String) obj.getInformation();
		ArrayList<ProductInStock> products = new ArrayList<>();
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(
					"SELECT ekrut.product_stock.productName, ekrut.product_stock.quantity, ekrut.product_stock.facility FROM ekrut.product_stock WHERE ekrut.product_stock.facility = ? AND  ekrut.product_stock.status='IN_PROGRESS' AND ekrut.product_stock.reportID > 0");
			ps.setString(1, facility);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				products.add(new ProductInStock(rs.getString("facility"), rs.getString("productName"),
						rs.getInt("quantity")));
			}
			obj.setInformation(products);
			obj.setResponse(Response.CHECK_PRODUCTS_NEED_TO_BE_UPDATE_STOCK_SUCCESS);
		} catch (SQLException e) {
			System.out.println("Statement for threshold inventory check has failed!");
			obj.setResponse(Response.CHECK_PRODUCTS_NEED_TO_BE_UPDATE_STOCK_FAILED);
		}
	}
	
	/**
	 * This method updates the inventory of a product in a facility.
	 *
	 * @param obj MissionPack object containing information about the product and facility to update.
	 * @param con Connection to the database.
	 */
	public static void UpdateInventory(MissionPack obj, Connection con) {
		ProductInStock data = (ProductInStock) obj.getInformation();
		String facility = data.getFacility(), productName = data.getProductName();
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(
					"UPDATE ekrut.product_stock SET ekrut.product_stock.status = 'VALID',ekrut.product_stock.quantity=200 WHERE ekrut.product_stock.status='IN_PROGRESS' AND ekrut.product_stock.facility = ? AND ekrut.product_stock.productName=? AND ekrut.product_stock.reportID > 0;");
			ps.setString(1, facility);
			ps.setString(2, productName);
			ps.executeUpdate();
			obj.setResponse(Response.UPDATE_PRODUCT_STOCK_IN_FACILITY_SUCCESS);
		} catch (SQLException e) {
			obj.setResponse(Response.UPDATE_PRODUCT_STOCK_IN_FACILITY_FAILED);
		}
	}
	/**
	 * This method retrieves the details of the regional manager for a specified region.
	 *
	 * @param obj MissionPack object containing the region for which to retrieve the regional manager's details.
	 * @param con Connection to the database.
	 */
	public static void checkDetailsOfRegionalManager(MissionPack obj, Connection con) {
		String region = (String) obj.getInformation();
		ArrayList<String> details = new ArrayList<>();
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(
					"SELECT ekrut.users.email, ekrut.users.phoneNumber FROM ekrut.users WHERE ekrut.users.region = ? AND ekrut.users.role='RegionalManager'");
			ps.setString(1, region);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				details.add(rs.getString("email"));
				details.add(rs.getString("phoneNumber"));
			}
			obj.setInformation(details);
			obj.setResponse(Response.CHECK_DETAILS_OF_REGIONAL_MANAGER_SUCCESS);
		} catch (SQLException e) {
			obj.setResponse(Response.CHECK_DETAILS_OF_REGIONAL_MANAGER_FAILED);
		}
	}
	/**
	 * This method retrieves the delivery report for a specified month and year.
	 *
	 * @param obj MissionPack object containing the month and year for which to retrieve the delivery report.
	 * @param con Connection to the database.
	 */
	public static void getDeliveriesReport(MissionPack obj, Connection con) {
		ArrayList<String> reportDetails = (ArrayList<String>) obj.getInformation();
		String month = reportDetails.get(0), year = reportDetails.get(1);
		HashMap<String, ArrayList<String>> mapData = new HashMap<>();
		int numOfTotalDeliveries = 0;
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(
					"SELECT SUM(ekrut.monthly_delivery_reports.numOfTotalDeliveries) FROM ekrut.monthly_delivery_reports  WHERE ekrut.monthly_delivery_reports.month = ? AND ekrut.monthly_delivery_reports.year = ?");
			ps.setString(1, month);
			ps.setString(2, year);
			ResultSet rs = ps.executeQuery();
			boolean hasNext = rs.next();
			if (!hasNext)
				obj.setResponse(Response.GET_MONTHLY_DELIVERIES_REPORT_FAILED);
			else {
				numOfTotalDeliveries = rs.getInt("SUM(ekrut.monthly_delivery_reports.numOfTotalDeliveries)");
				mapData.put("totalDeliveries", new ArrayList<String>());
				mapData.get("totalDeliveries").add(String.valueOf(numOfTotalDeliveries));
				mapData.put("AvgDeliveries", new ArrayList<String>());
				mapData.get("AvgDeliveries").add(Float.toString((float) (numOfTotalDeliveries / (31.0))));
				ps = con.prepareStatement(
						"SELECT ekrut.monthly_delivery_reports.numOfTotalDeliveries, ekrut.monthly_delivery_reports.region FROM ekrut.monthly_delivery_reports WHERE ekrut.monthly_delivery_reports.month = ? AND ekrut.monthly_delivery_reports.year = ?");
				ps.setString(1, month);
				ps.setString(2, year);
				rs = ps.executeQuery();
				hasNext = rs.next();
				if (!hasNext)
					obj.setResponse(Response.GET_MONTHLY_DELIVERIES_REPORT_FAILED);
				else {
					while (hasNext) {
						String region = rs.getString("region");
						int numOfDeliveries = rs.getInt("numOfTotalDeliveries");
						mapData.put(region, new ArrayList<String>());
						mapData.get(region).add(String.valueOf(numOfDeliveries));
						hasNext = rs.next();
					}
					ps = con.prepareStatement(
							"SELECT ekrut.monthly_delivery_reports.bestTime, ekrut.monthly_delivery_reports.bestSeller FROM ekrut.monthly_delivery_reports WHERE ekrut.monthly_delivery_reports.month = ? AND ekrut.monthly_delivery_reports.year = ? AND ekrut.monthly_delivery_reports.region='UAE'");
					ps.setString(1, month);
					ps.setString(2, year);
					rs = ps.executeQuery();
					hasNext = rs.next();
					if (!hasNext)
						obj.setResponse(Response.GET_MONTHLY_DELIVERIES_REPORT_FAILED);
					else {
						while (hasNext) {
							String bestTime = rs.getString("bestTime");
							String bestSeller = rs.getString("bestSeller");
							mapData.get("UAE").add(bestTime);
							mapData.get("UAE").add(bestSeller);
							hasNext = rs.next();
						}
						obj.setInformation(mapData);
						obj.setResponse(Response.GET_MONTHLY_DELIVERIES_REPORT_SUCCESS);
					}
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Statement for getting Monthly Incomes Report has failed!");
			obj.setResponse(Response.GET_MONTHLY_DELIVERIES_REPORT_FAILED);
		}
	}
	/**
	 * This method generates a monthly stock report for a specified month, year and facility.
	 *
	 * @param reportDetails  an ArrayList containing the month, year and facility for which to generate the report.
	 * @param con Connection to the database.
	 */
	public static void generateMonthlyStockReport(ArrayList<String> reportDetails, Connection con) {
		String month = reportDetails.get(0), year = reportDetails.get(1), facility = reportDetails.get(2);
		HashMap<String, Integer> map = new HashMap<>();
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(
					"SELECT ekrut.product_stock.productName, ekrut.product_stock.quantity FROM ekrut.product_stock WHERE ekrut.product_stock.facility = ? ");
			ps.setString(1, facility);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				map.put(rs.getString("productName"), rs.getInt("quantity"));
			}

			for (Map.Entry<String, Integer> currentCel : map.entrySet()) {
				ps = con.prepareStatement(
						"INSERT INTO ekrut.monthly_stock_reports (ProductName, numOfProductInStock, Facility ,month ,year) VALUES (?,?,?,?,?);");
				ps.setString(1, currentCel.getKey());
				ps.setInt(2, currentCel.getValue());
				ps.setString(3, facility);
				ps.setString(4, month);
				ps.setString(5, year);
				ps.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	/**
	 * This method generates a monthly order report for a specified month, year and facility.
	 *
	 * @param reportDetails an ArrayList containing the month, year and facility for which to generate the report.
	 * @param con Connection to the database.
	 */
	public static void generateMonthlyOrderReport(ArrayList<String> reportDetails, Connection con) {
		String month = reportDetails.get(0), year = reportDetails.get(1), facility = reportDetails.get(2);
		String region = Util.getRegionFromFacilities(facility);
		int numberOfOrders = 0;
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(
					"SELECT COUNT(ekrut.orders.orderDetails) FROM ekrut.orders WHERE ekrut.orders.facility = ? AND month = ? AND year = ?");
			ps.setString(1, facility);
			ps.setString(2, month);
			ps.setString(3, year);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				numberOfOrders = rs.getInt("COUNT(ekrut.orders.orderDetails)");
			}
			ps = con.prepareStatement(
					"INSERT INTO ekrut.monthly_orders_reports (numOfTotalOrders, store, region ,month ,year) VALUES (?,?,?,?,?);");
			ps.setInt(1, numberOfOrders);
			ps.setString(2, facility);
			ps.setString(3, region);
			ps.setString(4, month);
			ps.setString(5, year);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	/**
	 * This method generates a monthly customer report for a specified month, year and facility.
	 *
	 * @param reportDetails an ArrayList containing the month, year and facility for which to generate the report.
	 * @param con Connection to the database.
	 */
	public static void generateMonthlyCustomerReport(ArrayList<String> reportDetails, Connection con) {
		String month = reportDetails.get(0), year = reportDetails.get(1), facility = reportDetails.get(2);
		String region = Util.getRegionFromFacilities(facility);
		HashMap<Integer, Integer> map = new HashMap<>();
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(
					"SELECT ekrut.orders.clientID, COUNT(ekrut.orders.orderDetails) FROM ekrut.orders WHERE ekrut.orders.month = ? AND ekrut.orders.year = ? AND ekrut.orders.facility = ? GROUP BY ekrut.orders.clientID;");
			ps.setString(1, month);
			ps.setString(2, year);
			ps.setString(3, facility);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				map.put(Integer.valueOf(rs.getString("clientID")) % 551 + 1,
						rs.getInt("COUNT(ekrut.orders.orderDetails)"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		for (Map.Entry<Integer, Integer> currentCel : map.entrySet()) {
			try {
				ps = con.prepareStatement(
						"INSERT INTO ekrut.monthly_customer_reports (clientID, numOfOrders, Region ,month ,year) VALUES (?,?,?,?,?);");
				ps.setInt(1, currentCel.getKey());
				ps.setInt(2, currentCel.getValue());
				ps.setString(3, region);
				ps.setString(4, month);
				ps.setString(5, year);
				ps.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	/**
	 * This method updates the order details, facility, month, year, client id and config in the database.
	 *
	 * @param obj MissionPack object containing the order details, facility, month, year, client id, and config
	 * @param con Connection to the database.
	 */
	public static void updateorder(MissionPack obj, Connection con) {
		Object[] obji = (Object[]) obj.getInformation();
		String orderDetails = (String) obji[0];
		String facility = (String) obji[1];
		String month = (String) obji[2];
		String year = (String) obji[3];
		String clientId = (String) obji[4];
		String config = (String) obji[5];
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement(
					"INSERT INTO ekrut.orders (orderDetails,facility,month,year,clientID,config) VALUES (?,?,?,?,?,?);");
			ps.setString(1, orderDetails);
			ps.setString(2, facility);
			ps.setString(3, month);
			ps.setString(4, year);
			ps.setString(5, clientId);
			ps.setString(6, config);
			ps.executeUpdate();
			obj.setResponse(Response.ORDER_UPDATED);
		} catch (Exception exception) {
			exception.printStackTrace();
			obj.setResponse(Response.ORDER_FAILED);
		}
	}
}
