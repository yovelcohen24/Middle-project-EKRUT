package server;

import java.io.IOException;
import java.sql.SQLException;

import common_class.MissionPack;
import common_enums.ClientStatus;
import entities.DatabaseConnector;
import ocsf.server.ConnectionToClient;
/**
 * The ServerMissionAnalyze class is responsible for handling different types of missions that are sent by the client.
 * The class uses a QueryExecutor to execute these missions and update the database accordingly.
 *
 * @author Elroei
 */

public class ServerMissionAnalyze {
	private static QueryExecutor query= new QueryExecutor(); 
	@SuppressWarnings("incomplete-switch")
	public static void MissionsAnalyze(MissionPack obj, ConnectionToClient client) throws SQLException, IOException {
		switch (obj.getMission()) {
		

		case SEND_CONNECTION_DETAILS: {
			QueryExecutor.updateClientList(obj, client, ClientStatus.CONNECTED);
			break;
		}

		case SEND_DISCONNECTION_DETAILS: {
			QueryExecutor.updateClientList(obj, client, ClientStatus.DISCONNECTED);
			break;
		}

		case IDENTIFY_USER: {
			QueryExecutor.identifyUser(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}
		case ADD_CUSTOMER_DATA: {
			QueryExecutor.AddingNewCustomer(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}
		case FROM_CUSTOMER_TO_SUBSCRIBER: {
			QueryExecutor.changeToSubscriber(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}

		case GET_MONTHLY_CUSTOMER_REPORT: {
			QueryExecutor.getCustomerReport(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}

		case GET_MONTHLY_ORDERS_REPORT: {
			QueryExecutor.getOrdersReport(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}

		case GET_MONTHLY_STOCK_REPORT: {
			QueryExecutor.getStockReport(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}

		case LOG_OUT: {
			QueryExecutor.logOut(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;

		}

		case CREATE_LOCAL_ORDER: {
			query.CREATE_LOCAL_ORDER(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}

		case CREATE_REMOTE_ORDER: {
			query.CREATE_REMOTE_ORDER(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}

		case GET_PAYMENT_DATA: {
			QueryExecutor.GET_PAYMENT_DATA(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}

		case IMPORT_DATA: {
			QueryExecutor.ImportUsersData(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}

		case UPDATE_STOCK: {
			QueryExecutor.UpdateStock(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;

		}
		case FIND_USER_IN_DATA: {
			QueryExecutor.findUser(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}
		case REFRESH_DELIVERY: {

			QueryExecutor.refreshDelivery(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}
		case CHANGE_STATUS: {
			QueryExecutor.changeStatus(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}
		case APPROVE_DELIVERY: {
			QueryExecutor.approveDelivery(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}
		case REFRESH_DELIVERY_TO_STATUS: {

			QueryExecutor.refreshDeliveryToStatus(obj,
					DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}
		case GET_REQUESTED_TO_BE_COSTOMERS: {
			QueryExecutor.GET_REQUESTED_TO_BE_COSTOMERS(obj,
					DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}

		case APPROVE_TO_BE_CUSTOMER: {
			QueryExecutor.APPROVED_TO_BE_COSTOMERS(obj,
					DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}
		case EKT_LOGIN: {
			QueryExecutor.EktLogin(obj,
					DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}
		
		case FIND_SUBSCRIBER_NUMBERS: {
			QueryExecutor.FindSubscriberNumbers(obj,
					DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}
		case REFRESH_SALES_TABLE: {
			QueryExecutor.refreshSalesTable(obj,
					DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}
		case RUN_SALE: {
			QueryExecutor.runSales(obj,
					DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}
		case DEFINE_TEMPLATE: {
			QueryExecutor.defineTemplate(obj,
					DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}

		case REFRESH_DELIVERY_APPROVAL: {
			QueryExecutor.refreshDeliveryApproval(obj,
					DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}

		case APPROVE_DELIVERY_FROM_CUSTOMER_SIDE: {
			QueryExecutor.approveDeliveryFromCustomerSide(obj,
					DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}

		case GET_SALES: {
			QueryExecutor.GET_SALES(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}

		case REFRESH_PICKUP: {
			QueryExecutor.REFRESH_PICKUP(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}

		case PICKUP_ORDER: {
			QueryExecutor.PICKUP_ORDER(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}

		case ADD_BILL: {
			QueryExecutor.ADD_BILL(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;

		}

		case CHECK_LOGGED_IN: {
			QueryExecutor.CHECK_LOGGED_IN(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}
		case SET_CONFIG_FACILITY: {
			QueryExecutor.setFacility(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}

		case EXTRA_DETAILS_FOR_CUSTOMER_REPORT: {
			QueryExecutor.getExtraDetailsForCustomerReport(obj,
					DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}

		case EXTRA_DETAILS_FOR_ORDER_REPORT: {
			QueryExecutor.getExtraDetailsForOrderReport(obj,
					DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}
		case EXTRA_DETAILS_FOR_STOCK_REPORT: {
			QueryExecutor.getExtraDetailsForStockReport(obj,
					DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}

		case CHECK_THRES_HOLD_INVENTORY: {
			QueryExecutor.ThresholdInventory(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}
		case UPDATE_STATUS_THRES_HOLD_INVENTORY: {
			QueryExecutor.UpdateThresholdInventory(obj,
					DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}
		case PICK_THRESHOLD_INVENTORY_VALUE: {
			QueryExecutor.pickAThresholdInventoryValue(obj,
					DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}

		case UPDATE_MINIMUM_THRESHOLD_INVENTORY_VALUE: {
			QueryExecutor.UpdateMinTreshold(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}

		case CHECK_PRODUCTS_NEED_TO_BE_UPDATE_STOCK: {
			QueryExecutor.checkItemsToUpdateInventory(obj,
					DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}
		case UPDATE_PRODUCT_STOCK_IN_FACILITY: {
			QueryExecutor.UpdateInventory(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}

		case CHECK_DETAILS_OF_REGIONAL_MANAGER: {
			QueryExecutor.checkDetailsOfRegionalManager(obj,
					DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}
		case GET_MONTHLY_DELIVERIES_REPORT: {
			QueryExecutor.getDeliveriesReport(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}
		
		case UPDATE_ORDER: {
			QueryExecutor.updateorder(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}
		case CHECK_LOGGED_IN_BY_ID: {
			QueryExecutor.CHECK_LOGGED_IN_BY_ID(obj, DatabaseConnector.getDatabaseConnectorInstance().getConnection());
			break;
		}
		}

	}
}
