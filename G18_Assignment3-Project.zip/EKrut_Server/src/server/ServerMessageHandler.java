package server;

import java.io.IOException;

import common_class.MissionPack;
import common_enums.ClientStatus;
import entities.ConnectedClient;
import entities.DatabaseConnector;
import javafx.collections.ObservableList;
import ocsf.server.ConnectionToClient;

public class ServerMessageHandler {
	/**
	 * The response the server make
	 */
	/**
	 *
	 * 
	 * @author Maayan
	 *         This class creates a singleton instance of
	 *         ServerMessageHandler. The class has a private static variable
	 *         "messageHandler" of type ServerMessageHandler and a private
	 *         constructor. The class also has a public static method called
	 *         "getMessageHandlerInstance" that creates and returns the singleton
	 *         instance of the ServerMessageHandler. If the messageHandler variable
	 *         is null, a new ServerMessageHandler object is created and assigned to
	 *         the messageHandler variable. The method then returns the
	 *         messageHandler object.
	 */
	private static ServerMessageHandler messageHandler = null;

	private ServerMessageHandler() {
	}

	public static ServerMessageHandler getMessageHandlerInstance() {
		if (messageHandler == null) {
			messageHandler = new ServerMessageHandler();
		}
		return messageHandler;
	}

	/**
	 *
	 * 
	 * @author Maayan
	 *         This method handles incoming messages from clients and
	 *         processes them accordingly. The method takes in an object 'msg' and a
	 *         'client' object which represents the connection to the client that
	 *         sent the message. The method first casts the incoming 'msg' object to
	 *         a 'MissionPack' object, which is assumed to be the expected type of
	 *         message. Then it prints a message to the console indicating that a
	 *         message was received and from which client. Next, it calls a method
	 *         from the 'DatabaseConnector' class to parse the mission and handle
	 *         the data. If an IOException is thrown during this process, it is
	 *         caught and the stack trace is printed. Finally, the method sends the
	 *         'mission' object back to the client using the 'sendToClient' method
	 *         of the 'client' object. If an IOException is thrown during this
	 *         process, it is caught and the stack trace is printed.
	 */

	public void handleMessages(Object msg, ConnectionToClient client) {
		final MissionPack mission = (MissionPack) msg;
		System.out.println("Message received: " + mission + " from " + client);
		try {
			DatabaseConnector.parsingToData(mission, client);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			System.out.println(mission);
			client.sendToClient(mission);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 *
	 * 
	 * @author Maayan
	 * 		   This static method updates the client list of connected
	 *         clients in the 'ServerConfiguration' class. The method takes in a
	 *         'client' object, which represents the connection to the client that
	 *         needs to be updated, and a 'connectionStatus' enumeration indicating
	 *         the status of the client's connection. The method first retrieves the
	 *         current client list from the 'ServerConfiguration' class. It then
	 *         iterates through the list, searching for the client with the same IP
	 *         address as the one passed in as an argument. If a match is found, the
	 *         method removes that client from the list. Next, the method adds a new
	 *         'ConnectedClient' object to the list, with the IP address, hostname,
	 *         and connection status of the 'client' argument. Finally, the updated
	 *         client list is set back in the 'ServerConfiguration' class.
	 */
	static void updateClientList(ConnectionToClient client, ClientStatus connectionStatus) {
		ObservableList<ConnectedClient> clientList = ServerConfiguration.getClientList();

		for (int i = 0; i < clientList.size(); i++) {

			if (clientList.get(i).getIp().equals(client.getInetAddress().getHostAddress()))
				clientList.remove(i);
		}

		clientList.add(new ConnectedClient(client.getInetAddress().getHostAddress(),
				client.getInetAddress().getHostName(), connectionStatus));
		ServerConfiguration.setClientList(clientList);
	}

}
