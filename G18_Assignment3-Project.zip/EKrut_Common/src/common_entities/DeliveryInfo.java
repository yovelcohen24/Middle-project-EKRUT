package common_entities;

import java.io.Serializable;

/**
*
* 
* DeliveryInfo class that implements Serializable interface.
* It stores delivery information such as phone number, number of deliveries, address and email.
*  @author Nataly
*/
public class DeliveryInfo implements Serializable{

	private static final long serialVersionUID = 1L;
	/**
	    * Overrides the toString method to return a string representation of the DeliveryInfo object.
	    * @return a string representation of the DeliveryInfo object.
	    */
@Override
	public String toString() {
		return "DeliveryInfo [phoneNumber=" + phoneNumber + ", numberOfDelivery=" + numberOfDelivery + ", address="
				+ address + ", email=" + email + "]";
	}

private String phoneNumber, address, email;
private int  numberOfDelivery;



/**
 * Returns the number of deliveries.
 * @return the number of deliveries.
 */
public int getNumberOfDelivery() {
	return numberOfDelivery;
}
/**
 * Sets the number of deliveries.
 * @param numberOfDelivery the number of deliveries.
 */
public void setNumberOfDelivery(int numberOfDelivery) {
	this.numberOfDelivery = numberOfDelivery;
}
/**
 * Returns the phone number.
 * @return the phone number.
 */
public String getPhoneNumber() {
	return phoneNumber;
}
/**
 * Sets the phone number.
 * @param phoneNumber the phone number.
 */
public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
}

/**
 * Returns the address.
 * @return the address.
 */

public String getAddress() {
	return address;
}
/**
 * Sets the address.
 * @param address the address.
 */
public void setAddress(String address) {
	this.address = address;
}
/**
 * Returns the email.
 * @return the email.
 */
public String getEmail() {
	return email;
}
/**
 * Sets the email.
 * @param email the email.
 */
public void setEmail(String email) {
	this.email = email;
}
/**
 * Creates a new DeliveryInfo object with the given phone number, number of deliveries, address and email.
 * @param phoneNumber the phone number.
 * @param numberOfDelivery the number of deliveries.
 * @param address the address.
 * @param email the email.
 */
public DeliveryInfo(String phoneNumber, int numberOfDelivery, String address, String email) {
	super();
	this.phoneNumber = phoneNumber;
	this.numberOfDelivery = numberOfDelivery;
	this.address = address;
	this.email = email;
}

}
