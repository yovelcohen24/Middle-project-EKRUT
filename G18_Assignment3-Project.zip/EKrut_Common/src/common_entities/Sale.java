package common_entities;

import java.io.Serializable;
import java.util.Arrays;

/**
* 
* 
* Sale class that implements Serializable interface.
* It stores sale information such as indices, discount, and description.
* 
* @author Eyal
*/
@SuppressWarnings("serial")
public class Sale implements Serializable {
	int[] indices;
	double discount;
	String description;
	 /**
	    * Creates a new Sale object with the given indices, discount and description.
	    * @param indices a string of comma-separated integers representing the indices of the items on sale.
	    * @param discount the discount of the sale.
	    * @param description the description of the sale.
	    */
	public Sale(String indices, double discount, String description) {
		super();
		int index = 0;
		String[] indicesAsStrings = indices.split(",");
		this.indices = new int[indicesAsStrings.length];
		for (String str : indicesAsStrings) {
			this.indices[index] = Integer.parseInt(str);
			index++;
		}
		this.discount = discount;
		this.description = description;
	}
	 /**
	    * Returns the indices of the items on sale.
	    * @return the indices of the items on sale.
	    */
	public int[] getIndices() {
		return indices;
	}
	/**
	    * Sets the indices of the items on sale.
	    * @param indices the indices of the items on sale.
	    */
	public void setIndices(int[] indices) {
		this.indices = indices;
	}
	/**
	    * Returns the discount of the sale.
	    * @return the discount of the sale.
	    */
	public double getDiscount() {
		return discount;
	}
	    /**
	    * Sets the discount of the sale.
	    * @param discount the discount of the sale.
	    */
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	/**
	    * Returns the description of the sale.
	    * @return the description of the sale.
	    */
	public String getDescription() {
		return description;
	}
	    /**
	    * Sets the description of the sale.
	    * @param description the description of the sale.
	    */
	public void setDescription(String description) {
		this.description = description;
	}
	   /**
	    * Overrides the toString method to return a string representation of the Sale object.
	    * @return a string representation of the Sale object.
	    */
	@Override
	public String toString() {
		return "Sale [indices=" + Arrays.toString(indices) + ", discount=" + discount + ", description=" + description
				+ "]";
	}

}
