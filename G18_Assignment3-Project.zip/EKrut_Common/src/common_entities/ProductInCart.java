package common_entities;

import java.io.Serializable;
/**
* ProductInCart class
* 
* 
*
* This class represents a product in a cart with the following properties:
*  - product: the name of the product
*  - amount: the amount of the product in the cart
*  - price: the price of the product
*  - totalPrice: the total price of the product in the cart
*  
*  @author Elroi
*/
@SuppressWarnings("serial")
public class ProductInCart implements Serializable, Comparable<ProductInCart> {

	private String product;
	private int amount;
	private double price;
	private double totalPrice;
	/**
	* Create a new ProductInCart object with the given properties
	* 
	* @param productName the name of the product
	* @param amount the amount of the product in the cart
	* @param price the price of the product
	*/
	public ProductInCart(String productName, int amount, double price) {
		int temp;
		this.product = productName;
		this.amount = amount;
		price=price*100;
		temp=(int)price;
		price=temp/100.0;
		this.price = price;
		totalPrice = amount * price;
	}
	/**
	* Get the name of the product
	* 
	* @return name of the product
	*/
	public String getProduct() {
		return product;
	}
	/**
	* Set the name of the product
	* 
	* @param product the name of the product
	*/
	public void setProduct(String product) {
		this.product = product;
	}
	/**
	* Get the amount of the product in the cart
	* 
	* @return amount of the product in the cart
	*/
	public int getAmount() {
		return amount;
	}
	/**
	* Set the amount of the product in the cart
	* 
	* @param amount the amount of the product in the cart
	*/
	public void setAmount(int amount) {
		this.amount = amount;
	}
	/**
	* Get the price of the product
	* 
	* @return price of the product
	*/
	public double getPrice() {
		return price;
	}
	/**
	* Set the price of the product
	* 
	* @param originalPrices the price of the product
	*/
	public void setPrice(double originalPrices) {
		int temp;
		originalPrices=originalPrices*100;
		temp=(int)originalPrices;
		originalPrices=temp/100.0;
		this.price = originalPrices;
	}
	/**
	* Get the total price of the product in the cart
	* 
	* @return total price of the product in the cart
	*/
	public double getTotalPrice() {
		return totalPrice;
	}
	/**
	* Set the total price of the product in the cart
	* 
	* @param originalPrices the total price of the product in the cart
	*/
	public void setTotalPrice(double originalPrices) {
		this.totalPrice = originalPrices;
	}
	/**
	* Returns a string representation of the ProductInCart object.
	* 
	* @return A string in the format "product amount totalPrice"
	*/
	public String toString() {
		return product + " " + " " + amount + " " + totalPrice;
	}
	/**
	* Compares this ProductInCart object to another based on price.
	* 
	* @param o The ProductInCart object to compare to
	* @return -1 if this object's price is greater, 1 if it is less, 0 if they are equal
	*/
	@Override
	public int compareTo(ProductInCart o) {
	       if (this.price > o.getPrice()) 
	            return -1;
	        else if (this.price < o.getPrice())
	            return 1;
	        else 
	            return 0;
	}
}
