package common_entities;

import java.io.Serializable;
/**
* ProductInStock class 
* 
* 
*
* This class represents a product in stock with the following properties:
*  - productName: the name of the product
*  - amount: the amount of the product in stock
*  - file: binary file associated with the product
*  - facility: the facility where the product is located
*  
*  @author Eyal
*/
@SuppressWarnings("serial")
public class ProductInStock implements Serializable {

	private String productName;
	private int amount;
	private byte[] file;
	private String facility;
	/**
	* Get the facility where the product is located
	* 
	* @return facility where the product is located
	*/
	public String getFacility() {
		return facility;
	}

	/**
	* Set the facility where the product is located
	* 
	* @param facility the facility where the product is located
	*/
	public void setFacility(String facility) {
		this.facility = facility;
	}
	/**
	* Get a string representation of the product in stock
	* 
	* @return a string representation of the product in stock
	*/
	@Override
	public String toString() {
		return "ProductName: " + productName + "\t|\tAmount: " + amount + "\t|\tFacility: " + facility + "\n";
	}
	/**
	* Create a new ProductInStock object with the given properties
	* 
	* @param facility the facility where the product is located
	* @param productName the name of the product
	* @param amount the amount of the product in stock
	*/
	public ProductInStock(String facility, String productName, int amount) {
		super();
		this.facility = facility;
		this.productName = productName;
		this.amount = amount;
	}
	/**
	* Create a new ProductInStock object with the given properties
	* 
	* @param productName the name of the product
	* @param amount the amount of the product in stock
	* @param file binary file associated with the product
	*/
	public ProductInStock(String productName, int amount, byte[] file) {
		this.productName = productName;
		this.amount = amount;
		this.file = file;

	}
	/**
	* Get the binary file associated with the product
	* 
	* @return binary file associated with the product
	*/
	public byte[] getFile() {
		return file;
	}
	/**
	* Set the binary file associated with the product
	* 
	* @param file binary file associated with the product
	*/
	public void setFile(byte[] file) {
		this.file = file;
	}
	/**
	* Get the name of the product
	* 
	* @return name of the product
	*/
	public String getProductName() {
		return productName;
	}
	/**
	* Set the name of the product
	* 
	* @param productName the name of the product
	*/
	public void setProductName(String productName) {
		this.productName = productName;
	}
	/**
	* Get the amount
	* 
	* @return amount
	*/
	public int getAmount() {
		return amount;
	}
	/**
	* Set the amount
	* 
	* @param amount the amount
	*/
	public void setAmount(int amount) {
		this.amount = amount;
	}

}
