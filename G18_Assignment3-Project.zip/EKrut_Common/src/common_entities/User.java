package common_entities;

import java.io.Serializable;
/**
* 
* 
* User class that implements Serializable interface.
* It stores user information such as username, first name, last name, email, and store name.
* 
* @author Yovel
*/
@SuppressWarnings("serial")
public class User implements Serializable{
	private String username;
	private String firstName;
	private String lastName;
	private String email;
	private String storeName;
	/**
	    * Creates a new User object with the given username, first name, last name, email, and store name.
	    * @param username the username.
	    * @param firstName the first name.
	    * @param lastName the last name.
	    * @param email the email.
	    * @param storeName the store name.
	    */
	public User(String username, String firstName, String lastName, String email, String storeName) {
		super();
		this.username = username;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.storeName = storeName;
	}
	    /**
	    * Returns the username.
	    * @return the username.
	    */
	public String getUsername() {
		return username;
	}
	   /**
	    * Sets the username.
	    * @param username the username.
	    */
	public void setUsername(String username) {
		this.username = username;
	}
	   /**
	    * Returns the first name.
	    * @return the first name.
	    */
	public String getFirstName() {
		return firstName;
	}

    /**
    * Sets the first name.
    * @param firstName the first name.
    */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	    /**
	    * Returns the last name.
	    * @return the last name.
	    */
	public String getLastName() {
		return lastName;
	}

    /**
    * Sets the last name.
    * @param lastName the last name.
    */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	    /**
	    * Returns the email.
	    * @return the email.
	    */
	public String getEmail() {
		return email;
	}

    /**
    * Sets the email.
    * @param email the email.
    */
	public void setEmail(String email) {
		this.email = email;
	}

    /**
    * Returns the store name.
    * @return the store name.
    */
	public String getStoreName() {
		return storeName;
	}
	    /**
	    * Sets the store name.
	    * @param storeName the store name.
	    */
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

}
