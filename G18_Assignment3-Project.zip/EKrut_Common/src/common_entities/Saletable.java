package common_entities;

import java.io.Serializable;
/**
* 
* 
* Saletable class that implements Serializable interface.
* It stores sale information such as product name, description, sale code and region.
* 
* @author Maayan
*/
public class Saletable implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	private String productName, description;
	private int  saleCode;
	private String  region;
	/**
	    * Overrides the toString method to return a string representation of the Saletable object.
	    * @return a string representation of the Saletable object.
	    */
	@Override
	public String toString() {
		return "saletable [" + "saleCode = " + saleCode + ", productName = " + productName + ", description = " + description  
				+ "]";
	}
	/**
	    * Returns the product name.
	    * @return the product name.
	    */
	public String getProductName() {
		return productName;
	}
	   /**
	    * Sets the product name.
	    * @param productName the product name.
	    */
	public void setProductName(String productName) {
		this.productName = productName;
	}
	   /**
	    * Returns the description.
	    * @return the description.
	    */
	public String getDescription() {
		return description;
	}
	   /**
	    * Sets the description.
	    * @param description the description.
	    */
	public void setDescription(String description) {
		this.description = description;
	}
	   /**
	    * Returns the sale code.
	    * @return the sale code.
	    */
	public int getSaleCode() {
		return saleCode;
	}
	    /**
	    * Sets the sale code.
	    * @param saleCode the sale code.
	    */
	public void setSaleCode(int saleCode) {
		this.saleCode = saleCode;
	}
	    /**
	    * Creates a new Saletable object with the given sale code, product name and description.
	    * @param saleCode the sale code.
	    * @param productName the product name.
	    * @param description the description.
	    */
	public Saletable(int saleCode, String productName,String description) {
		super();
		this.productName = productName;
		this.description = description;
		this.saleCode = saleCode;
	}

    /**
    * Returns the region.
    * @return the region.
    */
	public String getRegion() {
		return region;
	}
	    /**
	    * Sets the region.
	    * @param region2
	    */
	public void setRegion(String region2) {
		this.region = region2;
		
	}
}
