package common_entities;

import java.io.Serializable;

/**
* PickupInfo class, representing the pickup information for an order.
* 
* @author Yovel
*/
@SuppressWarnings("serial")
public class PickupInfo implements Serializable {
	/**
	* Returns a string representation of the PickupInfo object.
	* 
	* @return String
	*/
	@Override
	public String toString() {
		return "PickupInfo [orderNum=" + orderNum + ", facility=" + facility + "]";
	}

	private int orderNum;
	private String facility;
	/**
	* Constructs a new PickupInfo object with the given order number and facility.
	* 
	* @param orderNum The order number associated with this pickup
	* @param facility The facility at which the order can be picked up
	*/
	public PickupInfo(int orderNum, String facility) {
		super();
		this.orderNum = orderNum;
		this.facility = facility;
	}
	/**
	* Gets the order number associated with this pickup
	* 
	* @return The order number
	*/
	public int getOrderNum() {
		return orderNum;
	}
	/**
	* Sets the order number associated with this pickup
	* 
	* @param orderNum The order number
	*/
	public void setOrderNum(int orderNum) {
		this.orderNum = orderNum;
	}
	/**
	* Gets the facility at which the order can be picked up
	* 
	* @return The facility
	*/
	public String getFacility() {
		return facility;
	}
	/**
	* Sets the facility at which the order can be picked up
	* 
	* @param facility The facility
	*/
	public void setFacility(String facility) {
		this.facility = facility;
	}

}
