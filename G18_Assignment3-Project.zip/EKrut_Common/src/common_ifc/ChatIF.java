package common_ifc;
/**
* 
* Package: common_ifc
* Interface: ChatIF
* Description:
* This interface defines a method for displaying a string, called "display".
* 
* @author Nataly
*/
public interface ChatIF
{

    /**
    * Method signature for displaying a string
    * @param str - the string to be displayed
    */
    void display(final String str);
}