package common_class;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * The class Time has a static method that related to time calculations
 * 
 * @author Maayan
 */

public class Time {
	/**
	 * getCurrentMonthAndYear() returns the current month and year in arraylist only
	 * if it's after the 30th of the month
	 * 
	 * @return ArrayList that holds currrent month in cell 1 and current year in
	 *         cell 0
	 */
	public static ArrayList<String> getCurrentMonthAndYearOnlyIfItIsTheEndOfTheMonth() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
		LocalDateTime now = LocalDateTime.now();
		String str = dtf.format(now);
		String[] dateStrings = str.split("/");
		if (Integer.valueOf(dateStrings[2]) >= 30) {
			return new ArrayList<String>(Arrays.asList(dateStrings[1], dateStrings[0]));
		}
		return null;
	}
}
