package common_class;

import java.util.ArrayList;

import common_enums.Facility;
import common_enums.Region;
/**
 * Util class that contains various utility methods.
 *
 * This class provides methods for calculating delivery time, getting facilities in a region, and getting the region of a facility.
 * @author Maayan
 */
public class Util {
	private static final double droneAvailabilityInHours = 24;
	private static final double distancFromOperationsCenterInHours = 120;
	private static final double droneSpeedInHours = 20;
	private static final double loadingDeliveryTimeInHours = 0.5;
	
	/**
	 * Returns the total delivery time for an order.
	 *
	 * @return the total delivery time for an order in hours
	 * @author Maayan
	 */
	public  static int totalDeliveryTime() {
		return (int) (droneAvailabilityInHours + (distancFromOperationsCenterInHours / droneSpeedInHours) + loadingDeliveryTimeInHours);
	}
	
	
	/**
	 * Returns a list of facilities in a given region.
	 *
	 * @param region the region to get facilities for
	 * @return a list of facilities in the given region
	 * @author Maayan
	 */
	public static ArrayList<String> getFacilitiesInTheRegion(Region region) {
		ArrayList<String> facilities = new ArrayList<>();
		switch (region) {
		case SOUTH:
			facilities.add(Facility.BEER_SHEVA.getFacility());
			facilities.add(Facility.EILAT.getFacility());
			break;

		case UAE:
			facilities.add(Facility.ABU_DHABI.getFacility());
			facilities.add(Facility.DUBAI.getFacility());
			break;

		case NORTH:
			facilities.add(Facility.TIRAT_HACARMEL.getFacility());
			facilities.add(Facility.KIRYAT_MOTZKIN.getFacility());
			break;
		}
		return facilities;
	}
	/**
	 * Returns the region of a given facility.
	 *
	 * @param facility the facility to get region for
	 * @return the region of the given facility
	 * @author Maayan
	 */
	public static String getRegionFromFacilities(String facility) {
		String retVal = null;
		switch (facility) {
		case "ABU_DHABI":
		case "DUBAI":
			retVal = "UAE";
			break;

		case "EILAT":
		case "BEER_SHEVA":
			retVal = "SOUTH";
			break;

		case "KIRYAT_MOTZKIN":
		case "TIRAT_HACARMEL":
			retVal = "NORTH";
			break;
		}
		return retVal;
	}
}
