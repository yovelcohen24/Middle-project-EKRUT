package common_class;

import java.io.Serializable;

import common_enums.Mission;
import common_enums.Response;

/**
 * MissionPack class, representing a package of a mission, response and extra
 * information.
 * 
 * @author Eyal
 */
@SuppressWarnings("serial")
public class MissionPack implements Serializable {
	private Mission mission;
	private Response response;
	private Object information;

	/**
	 * Construct a new MissionPack object with the given mission, response and
	 * information.
	 * 
	 * @param mission     The mission
	 * @param response    The response of the mission
	 * @param information The extra information regarding the mission
	 */
	public MissionPack(Mission mission, Response response, Object information) {

		this.mission = mission;
		this.response = response;
		this.information = information;
	}

	/**
	 * Get the mission of the MissionPack object
	 * 
	 * @return The mission
	 */
	public Mission getMission() {
		return mission;
	}

	/**
	 * Set the mission of the MissionPack object
	 * 
	 * @param mission The mission
	 */
	public void setMission(Mission mission) {
		this.mission = mission;
	}

	/**
	 * Get the response of the MissionPack object
	 * 
	 * @return The response
	 */
	public Response getResponse() {
		return response;
	}

	/**
	 * Set the response of the MissionPack object
	 * 
	 * @param response The response
	 */
	public void setResponse(Response response) {
		this.response = response;
	}

	/**
	 * Get the extra information of the MissionPack object
	 * 
	 * @return The extra information
	 */
	public Object getInformation() {
		return information;
	}

	/**
	 * Set the extra information of the MissionPack object
	 * 
	 * @param information The extra information
	 */
	public void setInformation(Object information) {
		this.information = information;
	}

	/**
	 * Returns a string representation of the MissionPack object.
	 * 
	 * @return String
	 */
	@Override
	public String toString() {
		return "You try to : " + getMission() + "  " + "The response is : " + getResponse();
	}
}