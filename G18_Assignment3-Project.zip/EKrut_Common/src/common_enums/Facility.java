package common_enums;
/**
 * 
 * 
 * Enum: Facility
 * 
 * Description:
 * This enumeration represents a set of predefined constant values for different facilities,
 * each constant is associated with a string representation and a serial number.
 * 
 * @author Yovel
 */
public enum Facility {
	/** Enumeration constant for the EILAT facility */
    EILAT("EILAT", 0),
    /** Enumeration constant for the ABU_DHABI facility */
    ABU_DHABI("ABU_DHABI", 1), 
    /** Enumeration constant for the KIRYAT_MOTZKIN facility */
    KIRYAT_MOTZKIN("KIRYAT_MOTZKIN", 2),
    /** Enumeration constant for the TIRAT_HACARMEL facility */
    TIRAT_HACARMEL("TIRAT_HACARMEL", 3), 
    /** Enumeration constant for the BEER_SHEVA facility */
    BEER_SHEVA("BEER_SHEVA", 4), 
    /** Enumeration constant for the DUBAI facility */
    DUBAI("DUBAI", 5);

    /** The string representation of the facility */
    private final String facility;

    /**
    * Constructor for the enumeration
    * @param facility - the string representation of the facility
    * @param serialNumber - the serial number of the facility
    */
    private Facility(final String facility, final int serialNumber) {
        this.facility = facility;
    }

    /**
    * Returns the string representation of the facility
    * @return the facility as a string
    */
    public String getFacility() {
        return facility;
    }

}
