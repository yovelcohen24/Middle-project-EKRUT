package common_enums;
/**
* 
* 
* Enum: ClientStatus
* 
* Description:
* This enumeration represents the possible statuses of a client, either connected or disconnected,
* each constant is associated with a string representation and a serial number.
* 
* @author Eyal
*/
public enum ClientStatus {
	 /** Enumeration constant for a connected client */
	CONNECTED("Connected", 0), 
	/** Enumeration constant for a disconnected client */
	DISCONNECTED("Disconnected", 1);
	 /** The string representation of the client's status */
	private ClientStatus(final String mission, final int serialNumber) {
	}
}
