package common_enums;
/**
* 
* 
* Enum: Region
* 
* Description:
* This enumeration represents a set of predefined constant values for different regions,
* each constant is associated with a string representation and a serial number.
* 
* @author Elroi
*/
public enum Region {
	 /** Enumeration constant for the South region */
    SOUTH("SOUTH", 0), 
    /** Enumeration constant for the North region */
    NORTH("NORTH", 1), 
    /** Enumeration constant for the UAE region */
    UAE("UAE", 2);

    /** The string representation of the region */
    private String region;

    /**
    * Constructor for the enumeration
    * @param region - the string representation of the region
    * @param serialNumber - the serial number of the region
    */
    private Region(final String region, final int serialNumber) {
        this.region = region;
    }

    /**
    * Returns the string representation of the region
    * @return the string representation of the region
    */
    public String toString() {
        return region;
    }
}
